-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2025 at 11:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `status` enum('Present','Absent','Late') NOT NULL DEFAULT 'Present',
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`attendance_id`, `student_id`, `subject_id`, `attendance_date`, `time_in`, `status`, `recorded_by`, `created_at`) VALUES
(1, 1, 1, '2025-10-11', '08:00:00', 'Present', 1, '2025-10-11 14:11:24'),
(2, 2, 1, '2025-10-11', '08:05:00', 'Late', 1, '2025-10-11 14:11:24'),
(3, 3, 1, '2025-10-11', '08:00:00', 'Present', 1, '2025-10-11 14:11:24'),
(4, 1, 2, '2025-10-11', '09:00:00', 'Present', 2, '2025-10-11 14:11:24'),
(5, 2, 2, '2025-10-11', '09:00:00', 'Present', 2, '2025-10-11 14:11:24'),
(6, 3, 2, '2025-10-11', NULL, 'Absent', 2, '2025-10-11 14:11:24'),
(7, 2, 2, '2025-10-12', '17:06:49', 'Present', 2, '2025-10-11 18:10:43');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_number` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `grade_level` varchar(10) NOT NULL,
  `section` varchar(20) NOT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `user_id`, `student_number`, `first_name`, `last_name`, `middle_name`, `grade_level`, `section`, `qr_code`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 5, 'S001', 'Alices', 'Johnson', 'asdasd', 'Grade 11', 'Section A', 'QR_S001', 1, '2025-10-11 14:11:24', '2025-10-11 17:00:00'),
(2, 6, 'S002', 'Bob', 'Smith', 'Jazzy', 'Grade 11', 'Section A', 'QR_STUDENT_002', 1, '2025-10-11 14:11:24', '2025-10-12 08:27:51'),
(3, 7, 'S003', 'Charlie', 'Brown', NULL, 'Grade 11', 'Section B', 'QR_STUDENT_003', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(4, 8, 'student001', 'das', 'dasd', 'das', 'Grade 12', 'Section B', 'QR_student001', 1, '2025-10-11 15:33:16', '2025-10-11 16:42:16');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `strand` enum('STEM','HUMSS','ABM','TVL','General') NOT NULL,
  `grade_level` varchar(10) NOT NULL,
  `units` decimal(3,1) DEFAULT 1.0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_code`, `subject_name`, `description`, `strand`, `grade_level`, `units`, `is_active`, `created_at`) VALUES
(1, 'MATH101', 'Mathematics', 'Basic Mathematics', 'General', 'Grade 11', 1.0, 1, '2025-10-11 14:11:24'),
(2, 'ENG101', 'English', 'English Language', 'General', 'Grade 11', 1.0, 1, '2025-10-11 14:11:24'),
(3, 'SCI101', 'Science', 'General Science', 'General', 'Grade 11', 1.0, 1, '2025-10-11 14:11:24'),
(4, 'MATH201', 'Advanced Mathematics', 'Advanced Mathematics for STEM', 'STEM', 'Grade 12', 1.5, 1, '2025-10-11 14:11:24'),
(5, 'ENG201', 'Advanced English', 'Advanced English for HUMSS', 'HUMSS', 'Grade 12', 1.5, 1, '2025-10-11 14:11:24');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `teacher_number` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `employment_status` enum('Active','Inactive','On Leave') DEFAULT 'Active',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `user_id`, `teacher_number`, `first_name`, `last_name`, `middle_name`, `department`, `specialization`, `employment_status`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 2, 'T001', 'John', 'Mathematics Teacher', NULL, 'Mathematics', 'Algebra and Calculus', 'Active', 0, '2025-10-11 14:11:24', '2025-10-11 14:41:57'),
(2, 3, 'T002', 'Jane', 'English Teacher', NULL, 'English', 'Literature and Composition', 'Active', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(3, 4, 'T003', 'Bob', 'Science Teacher', 'rwrerer', 'Science', 'Physics and Chemistry', 'Active', 1, '2025-10-11 14:11:24', '2025-10-11 14:42:20');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_assignments`
--

CREATE TABLE `teacher_assignments` (
  `assignment_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section` varchar(20) NOT NULL,
  `grade_level` varchar(10) NOT NULL,
  `academic_year` varchar(10) NOT NULL,
  `semester` enum('1st','2nd') DEFAULT '1st',
  `schedule_days` varchar(20) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `room_number` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher_assignments`
--

INSERT INTO `teacher_assignments` (`assignment_id`, `teacher_id`, `subject_id`, `section`, `grade_level`, `academic_year`, `semester`, `schedule_days`, `start_time`, `end_time`, `room_number`, `is_active`, `created_at`) VALUES
(1, 1, 1, 'Section A', 'Grade 11', '2024-2025', '1st', 'Mon,Wed,Fri', '08:00:00', '09:00:00', 'Room 101', 0, '2025-10-11 14:11:24'),
(2, 1, 1, 'Section B', 'Grade 11', '2024-2025', '1st', 'Tue,Thu', '08:00:00', '09:00:00', 'Room 102', 0, '2025-10-11 14:11:24'),
(3, 2, 2, 'Section A', 'Grade 11', '2024-2025', '1st', 'Mon,Wed', '09:00:00', '10:00:00', 'Room 201', 1, '2025-10-11 14:11:24'),
(4, 2, 2, 'Section B', 'Grade 11', '2024-2025', '1st', 'Tue,Thu', '09:00:00', '10:00:00', 'Room 202', 1, '2025-10-11 14:11:24'),
(5, 3, 3, 'Section A', 'Grade 11', '2024-2025', '1st', 'Fri', '10:00:00', '11:00:00', 'Lab 301', 1, '2025-10-11 14:11:24'),
(6, 3, 3, 'Section B', 'Grade 11', '2024-2025', '1st', 'Wed', '10:00:00', '11:00:00', 'Lab 302', 1, '2025-10-11 14:11:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `user_type` enum('student','teacher','admin') NOT NULL DEFAULT 'student',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `user_type`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin123', 'System Administrator', 'admin', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(2, 'teacher1', 'teacher123', 'John Mathematics Teacher', 'teacher', 1, '2025-10-11 14:11:24', '2025-10-11 16:29:45'),
(3, 'teacher2', 'teacher123', 'Jane English Teacher', 'teacher', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(4, 'teacher3', 'teacher123', 'Bob Science Teacher', 'teacher', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(5, 'student1', 'student123', 'Alices Johnson', 'student', 1, '2025-10-11 14:11:24', '2025-10-11 17:00:00'),
(6, 'student2', 'student123', 'Bob Smith', 'student', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(7, 'student3', 'student123', 'Charlie Brown', 'student', 1, '2025-10-11 14:11:24', '2025-10-11 14:11:24'),
(8, 'student', '123456', 'das dasd', 'student', 1, '2025-10-11 15:33:16', '2025-10-11 15:33:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `unique_attendance` (`student_id`,`subject_id`,`attendance_date`),
  ADD KEY `recorded_by` (`recorded_by`),
  ADD KEY `idx_attendance_student_date` (`student_id`,`attendance_date`),
  ADD KEY `idx_attendance_subject_date` (`subject_id`,`attendance_date`),
  ADD KEY `idx_attendance_status` (`status`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD UNIQUE KEY `subject_code` (`subject_code`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `teacher_number` (`teacher_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `idx_teacher_assignments_teacher` (`teacher_id`),
  ADD KEY `idx_teacher_assignments_section` (`section`,`grade_level`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD CONSTRAINT `attendance_records_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_records_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_records_ibfk_3` FOREIGN KEY (`recorded_by`) REFERENCES `teachers` (`teacher_id`) ON DELETE SET NULL;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `teacher_assignments`
--
ALTER TABLE `teacher_assignments`
  ADD CONSTRAINT `teacher_assignments_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `teacher_assignments_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
