package student;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Student Attendance History Form - View student's attendance records
 * Demonstrates OOP concepts: Encapsulation, Inheritance, and Data Structures
 */
public class StudentAttendanceHistoryForm extends JFrame {
    
    // Encapsulation: Private fields
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    private int studentId;
    private String studentFullName;
    private List<AttendanceRecord> attendanceHistory; // Data Structure: List for attendance records
    
    // UI Components
    private JTable attendanceTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton closeButton;
    private JLabel statsLabel;
    
    /**
     * Inner class to represent attendance record (Data Structure)
     */
    public static class AttendanceRecord {
        private String attendanceDate;
        private String subjectName;
        private String status;
        private String timeIn;
        private String remarks;
        
        public AttendanceRecord(String attendanceDate, String subjectName, String status, String timeIn, String remarks) {
            this.attendanceDate = attendanceDate;
            this.subjectName = subjectName;
            this.status = status;
            this.timeIn = timeIn;
            this.remarks = remarks;
        }
        
        // Getters
        public String getAttendanceDate() { return attendanceDate; }
        public String getSubjectName() { return subjectName; }
        public String getStatus() { return status; }
        public String getTimeIn() { return timeIn; }
        public String getRemarks() { return remarks; }
    }
    
    /**
     * Constructor
     * @param studentId Student ID
     * @param studentFullName Student full name
     */
    public StudentAttendanceHistoryForm(int studentId, String studentFullName) {
        this.studentId = studentId;
        this.studentFullName = studentFullName;
        this.attendanceHistory = new ArrayList<>(); // Data Structure initialization
        
        initComponents();
        setupEventHandlers();
        loadAttendanceHistory();
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Attendance History - " + studentFullName);
        setResizable(true);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(800, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Attendance History");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Stats panel
        JPanel statsPanel = new JPanel();
        statsPanel.setBackground(new Color(240, 240, 240));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        statsLabel = new JLabel("Loading statistics...");
        statsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        statsPanel.add(statsLabel);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Create table model
        String[] columnNames = {"Date", "Subject", "Status", "Time In"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        attendanceTable = new JTable(tableModel);
        attendanceTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        attendanceTable.setRowHeight(25);
        attendanceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        attendanceTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        attendanceTable.getTableHeader().setBackground(new Color(200, 200, 200));
        
        // Set column widths
        attendanceTable.getColumnModel().getColumn(0).setPreferredWidth(100); // Date
        attendanceTable.getColumnModel().getColumn(1).setPreferredWidth(150); // Subject
        attendanceTable.getColumnModel().getColumn(2).setPreferredWidth(80);  // Status
        attendanceTable.getColumnModel().getColumn(3).setPreferredWidth(80);  // Time In
        
        JScrollPane scrollPane = new JScrollPane(attendanceTable);
        scrollPane.setPreferredSize(new Dimension(750, 400));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(new Color(240, 240, 240));
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(0, 0, 128));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        refreshButton.setPreferredSize(new Dimension(120, 35));
        
        closeButton = new JButton("Close");
        closeButton.setBackground(new Color(80, 80, 80));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(statsPanel, BorderLayout.CENTER);
        add(tablePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers
     */
    private void setupEventHandlers() {
        refreshButton.addActionListener(e -> refreshButtonActionPerformed(e));
        closeButton.addActionListener(e -> closeButtonActionPerformed(e));
    }
    
    /**
     * Load attendance history from database
     */
    private void loadAttendanceHistory() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Clear existing data
                attendanceHistory.clear();
                tableModel.setRowCount(0);
                
                // Query to get attendance records with subject information
                String query = "SELECT ar.attendance_date, s.subject_name, ar.status, ar.time_in " +
                              "FROM attendance_records ar " +
                              "JOIN subjects s ON ar.subject_id = s.subject_id " +
                              "WHERE ar.student_id = ? " +
                              "ORDER BY ar.attendance_date DESC, s.subject_name";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                
                // Load data into List and Table (Data Structures)
                while (rs.next()) {
                    String date = rs.getDate("attendance_date").toString();
                    String subject = rs.getString("subject_name");
                    String status = rs.getString("status");
                    String timeIn = rs.getTime("time_in") != null ? rs.getTime("time_in").toString() : "";
                    
                    // Add to List (Data Structure)
                    AttendanceRecord record = new AttendanceRecord(date, subject, status, timeIn, "");
                    attendanceHistory.add(record);
                    
                    // Add to Table (Data Structure)
                    Object[] rowData = {date, subject, status, timeIn};
                    tableModel.addRow(rowData);
                }
                
                rs.close();
                stmt.close();
                
                // Load and display statistics
                loadAttendanceStatistics();
                
                System.out.println("✅ Attendance history loaded successfully. Records: " + attendanceHistory.size());
            }
        } catch (Exception e) {
            System.err.println("❌ Error loading attendance history: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading attendance history: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Load attendance statistics
     */
    private void loadAttendanceStatistics() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Get attendance statistics
                String statsQuery = "SELECT COUNT(*) as total, " +
                                  "SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present, " +
                                  "SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent, " +
                                  "SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) as late " +
                                  "FROM attendance_records WHERE student_id = ?";
                
                PreparedStatement stmt = conn.prepareStatement(statsQuery);
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    int total = rs.getInt("total");
                    int present = rs.getInt("present");
                    int absent = rs.getInt("absent");
                    int late = rs.getInt("late");
                    
                    String statsText = String.format(
                        "Total Records: %d | Present: %d | Absent: %d | Late: %d | Attendance Rate: %.1f%%",
                        total, present, absent, late, 
                        total > 0 ? (double)(present + late) / total * 100 : 0
                    );
                    
                    statsLabel.setText(statsText);
                }
                
                rs.close();
                stmt.close();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading attendance statistics: " + e.getMessage());
            statsLabel.setText("Error loading statistics");
        }
    }
    
    // Event Handlers
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadAttendanceHistory();
        JOptionPane.showMessageDialog(this, "Data refreshed successfully!", 
                                    "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void closeButtonActionPerformed(ActionEvent evt) {
        this.dispose();
    }
    
    /**
     * Get attendance history (for external access)
     * @return List of attendance records
     */
    public List<AttendanceRecord> getAttendanceHistory() {
        return new ArrayList<>(attendanceHistory); // Return copy to maintain encapsulation
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentAttendanceHistoryForm historyForm = new StudentAttendanceHistoryForm(1, "John Doe");
            historyForm.setVisible(true);
        });
    }
}
