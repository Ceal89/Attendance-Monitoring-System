package student;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

/**
 * Student Profile Form - View and edit student profile information
 * Demonstrates OOP concepts: Encapsulation, Inheritance, and Data Structures
 */
public class StudentProfileForm extends JFrame {
    
    // Encapsulation: Private fields
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    private int studentId;
    private String studentFullName;
    
    // UI Components
    private JTextField studentNumberField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField middleNameField;
    private JTextField gradeLevelField;
    private JTextField sectionField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton updateButton;
    private JButton cancelButton;
    private JButton refreshButton;
    
    /**
     * Constructor
     * @param studentId Student ID
     * @param studentFullName Student full name
     */
    public StudentProfileForm(int studentId, String studentFullName) {
        this.studentId = studentId;
        this.studentFullName = studentFullName;
        
        initComponents();
        setupEventHandlers();
        loadStudentData();
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Student Profile - " + studentFullName);
        setResizable(false);
        setSize(600, 700);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(600, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Student Profile");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Student Number
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Student Number *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        studentNumberField = new JTextField(20);
        studentNumberField.setEditable(false);
        formPanel.add(studentNumberField, gbc);
        
        // First Name
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("First Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Last Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField, gbc);
        
        // Middle Name
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Middle Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        middleNameField = new JTextField(20);
        formPanel.add(middleNameField, gbc);
        
        // Grade Level
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Grade Level *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gradeLevelField = new JTextField(20);
        gradeLevelField.setEditable(false);
        formPanel.add(gradeLevelField, gbc);
        
        // Section
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Section *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        sectionField = new JTextField(20);
        sectionField.setEditable(false);
        formPanel.add(sectionField, gbc);
        
        // Username
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Username *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 7; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Password (leave blank to keep current):"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 8; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(20);
        formPanel.add(confirmPasswordField, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(0, 0, 128));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        refreshButton.setPreferredSize(new Dimension(120, 35));
        
        updateButton = new JButton("Update Profile");
        updateButton.setBackground(PRIMARY_COLOR);
        updateButton.setForeground(Color.WHITE);
        updateButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        updateButton.setPreferredSize(new Dimension(120, 35));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(80, 80, 80));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers
     */
    private void setupEventHandlers() {
        refreshButton.addActionListener(e -> refreshButtonActionPerformed(e));
        updateButton.addActionListener(e -> updateButtonActionPerformed(e));
        cancelButton.addActionListener(e -> cancelButtonActionPerformed(e));
    }
    
    /**
     * Load student data from database
     */
    private void loadStudentData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Get student information
                String studentQuery = "SELECT s.student_number, s.first_name, s.last_name, s.middle_name, " +
                                    "s.grade_level, s.section, u.username " +
                                    "FROM students s " +
                                    "JOIN users u ON s.user_id = u.user_id " +
                                    "WHERE s.student_id = ?";
                
                PreparedStatement stmt = conn.prepareStatement(studentQuery);
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    studentNumberField.setText(rs.getString("student_number"));
                    firstNameField.setText(rs.getString("first_name"));
                    lastNameField.setText(rs.getString("last_name"));
                    middleNameField.setText(rs.getString("middle_name"));
                    gradeLevelField.setText(rs.getString("grade_level"));
                    sectionField.setText(rs.getString("section"));
                    usernameField.setText(rs.getString("username"));
                }
                
                rs.close();
                stmt.close();
                
                System.out.println("✅ Student profile data loaded successfully");
            }
        } catch (Exception e) {
            System.err.println("❌ Error loading student data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading student data: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Update student profile
     */
    private void updateStudent() {
        // Validate input
        if (firstNameField.getText().trim().isEmpty() || 
            lastNameField.getText().trim().isEmpty() || 
            usernameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please fill in all required fields!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate passwords if provided
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        if (!password.isEmpty()) {
            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, 
                    "Passwords do not match!", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                confirmPasswordField.requestFocus();
                return;
            }
            
            if (password.length() < 6) {
                JOptionPane.showMessageDialog(this, 
                    "Password must be at least 6 characters long", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                passwordField.requestFocus();
                return;
            }
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);
            
            // Update user information
            String userQuery;
            PreparedStatement userStmt;
            
            if (!password.isEmpty()) {
                userQuery = "UPDATE users SET username = ?, password = ?, full_name = ? WHERE user_id = (SELECT user_id FROM students WHERE student_id = ?)";
                userStmt = conn.prepareStatement(userQuery);
                userStmt.setString(1, usernameField.getText().trim());
                userStmt.setString(2, password);
                userStmt.setString(3, firstNameField.getText().trim() + " " + lastNameField.getText().trim());
                userStmt.setInt(4, studentId);
            } else {
                userQuery = "UPDATE users SET username = ?, full_name = ? WHERE user_id = (SELECT user_id FROM students WHERE student_id = ?)";
                userStmt = conn.prepareStatement(userQuery);
                userStmt.setString(1, usernameField.getText().trim());
                userStmt.setString(2, firstNameField.getText().trim() + " " + lastNameField.getText().trim());
                userStmt.setInt(3, studentId);
            }
            
            int userResult = userStmt.executeUpdate();
            userStmt.close();
            
            // Update student information
            String studentQuery = "UPDATE students SET first_name = ?, last_name = ?, middle_name = ? WHERE student_id = ?";
            PreparedStatement studentStmt = conn.prepareStatement(studentQuery);
            studentStmt.setString(1, firstNameField.getText().trim());
            studentStmt.setString(2, lastNameField.getText().trim());
            studentStmt.setString(3, middleNameField.getText().trim());
            studentStmt.setInt(4, studentId);
            
            int studentResult = studentStmt.executeUpdate();
            studentStmt.close();
            
            conn.commit();
            
            if (userResult > 0 && studentResult > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Profile updated successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Clear password fields
                passwordField.setText("");
                confirmPasswordField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Failed to update profile!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (Exception e) {
            try {
                Connection conn = DatabaseConnection.getConnection();
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {}
            
            System.err.println("❌ Error updating profile: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error updating profile: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Event Handlers
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadStudentData();
        JOptionPane.showMessageDialog(this, "Data refreshed successfully!", 
                                    "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void updateButtonActionPerformed(ActionEvent evt) {
        updateStudent();
    }
    
    private void cancelButtonActionPerformed(ActionEvent evt) {
        this.dispose();
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentProfileForm profileForm = new StudentProfileForm(1, "John Doe");
            profileForm.setVisible(true);
        });
    }
}
