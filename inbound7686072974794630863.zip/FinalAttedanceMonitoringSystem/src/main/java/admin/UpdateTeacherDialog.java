package admin;

import common.DatabaseConnection;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/**
 * UpdateTeacherDialog - Dialog for updating teacher information
 * Demonstrates Object-Oriented Programming principles
 */
public class UpdateTeacherDialog extends JDialog {
    
    // UI Components - Encapsulation
    private JComboBox<String> teacherCombo;
    private JTextField teacherNumberField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField middleNameField;
    private JTextField departmentField;
    private JTextField specializationField;
    private JComboBox<String> employmentStatusCombo;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton updateButton;
    private JButton cancelButton;
    private JButton loadButton;
    
  
    private List<TeacherData> teachers;
    private int currentTeacherId;
    
    /**
     * TeacherData class - Demonstrates Encapsulation and Data Structure
     */
    private static class TeacherData {
        private int teacherId;
        private String teacherNumber;
        private String fullName;
        private String department;
        
        public TeacherData(int teacherId, String teacherNumber, String fullName, String department) {
            this.teacherId = teacherId;
            this.teacherNumber = teacherNumber;
            this.fullName = fullName;
            this.department = department;
        }
        
        @Override
        public String toString() {
            return teacherNumber + " - " + fullName + " (" + department + ")";
        }
        
        // Getters - Encapsulation
        public int getTeacherId() { return teacherId; }
    }
    
    /**
     * Constructor - Demonstrates Encapsulation and Polymorphism
     * @param parent Parent AdminDashboard window
     */
    public UpdateTeacherDialog(AdminDashboard parent) {
        super(parent, "Update Teacher", true);
 
        this.teachers = new ArrayList<>();
        this.currentTeacherId = -1;
        
        initComponents();
        setupEventHandlers();
        loadTeachers();
        
        setSize(600, 700);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    /**
     * Initialize UI components - Demonstrates Encapsulation
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 33, 0));
        headerPanel.setPreferredSize(new Dimension(600, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Update Teacher");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Teacher Selection
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Teacher *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        teacherCombo = new JComboBox<>();
        teacherCombo.setPreferredSize(new Dimension(300, 30));
        formPanel.add(teacherCombo, gbc);
        
        // Load Button
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        loadButton = new JButton("Load Teacher");
        loadButton.setBackground(new Color(33, 150, 33));
        loadButton.setForeground(Color.WHITE);
        loadButton.setFocusPainted(false);
        formPanel.add(loadButton, gbc);
        
        // Teacher Number
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Teacher Number *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        teacherNumberField = new JTextField(20);
        formPanel.add(teacherNumberField, gbc);
        
        // First Name
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("First Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Last Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField, gbc);
        
        // Middle Name
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Middle Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        middleNameField = new JTextField(20);
        formPanel.add(middleNameField, gbc);
        
        // Department
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Department *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        departmentField = new JTextField(20);
        formPanel.add(departmentField, gbc);
        
        // Specialization
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Specialization:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        specializationField = new JTextField(20);
        formPanel.add(specializationField, gbc);
        
        // Employment Status
        gbc.gridx = 0; gbc.gridy = 7; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Employment Status *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        employmentStatusCombo = new JComboBox<>(new String[]{"Active", "Inactive", "On Leave"});
        employmentStatusCombo.setSelectedIndex(0);
        formPanel.add(employmentStatusCombo, gbc);
        
        // Username
        gbc.gridx = 0; gbc.gridy = 8; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Username *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 9; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Password (leave blank to keep current):"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 10; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(20);
        formPanel.add(confirmPasswordField, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        updateButton = new JButton("Update Teacher");
        updateButton.setBackground(new Color(33, 33, 0));
        updateButton.setForeground(Color.WHITE);
        updateButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        updateButton.setPreferredSize(new Dimension(120, 35));
        updateButton.setEnabled(false);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(80, 80, 80));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    
    /**
     * Setup event handlers - Demonstrates Event-Driven Programming
     */
    private void setupEventHandlers() {
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadTeacherButtonActionPerformed(e);
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTeacherButtonActionPerformed(e);
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonActionPerformed(e);
            }
        });
    }
    
    /**
     * Load teachers from database - Demonstrates Database Operations
     */
    private void loadTeachers() {
        teachers.clear();
        teacherCombo.removeAllItems();
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT t.teacher_id, t.user_id, t.teacher_number, t.first_name, t.last_name, t.middle_name, " +
                          "t.department, t.specialization, t.employment_status, u.username " +
                          "FROM teachers t " +
                          "JOIN users u ON t.user_id = u.user_id " +
                          "WHERE t.is_active = 1 " +
                          "ORDER BY t.teacher_number";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
                if (rs.getString("middle_name") != null && !rs.getString("middle_name").trim().isEmpty()) {
                    fullName = rs.getString("first_name") + " " + rs.getString("middle_name") + " " + rs.getString("last_name");
                }
                
                TeacherData teacher = new TeacherData(
                    rs.getInt("teacher_id"),
                    rs.getString("teacher_number"),
                    fullName,
                    rs.getString("department")
                );
                
                teachers.add(teacher);
                teacherCombo.addItem(teacher.toString());
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading teachers: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading teachers: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Handle Load Teacher button click - Demonstrates Data Loading
     */
    private void loadTeacherButtonActionPerformed(ActionEvent evt) {
        int selectedIndex = teacherCombo.getSelectedIndex();
        if (selectedIndex < 0 || selectedIndex >= teachers.size()) {
            JOptionPane.showMessageDialog(this, 
                "Please select a teacher to load", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        TeacherData selectedTeacher = teachers.get(selectedIndex);
        currentTeacherId = selectedTeacher.getTeacherId();
        
        // Load teacher details
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT t.teacher_number, t.first_name, t.last_name, t.middle_name, t.department, " +
                          "t.specialization, t.employment_status, u.username " +
                          "FROM teachers t " +
                          "JOIN users u ON t.user_id = u.user_id " +
                          "WHERE t.teacher_id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, currentTeacherId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                teacherNumberField.setText(rs.getString("teacher_number"));
                firstNameField.setText(rs.getString("first_name"));
                lastNameField.setText(rs.getString("last_name"));
                middleNameField.setText(rs.getString("middle_name"));
                departmentField.setText(rs.getString("department"));
                specializationField.setText(rs.getString("specialization"));
                usernameField.setText(rs.getString("username"));
                
                // Set employment status
                String status = rs.getString("employment_status");
                for (int i = 0; i < employmentStatusCombo.getItemCount(); i++) {
                    if (employmentStatusCombo.getItemAt(i).equals(status)) {
                        employmentStatusCombo.setSelectedIndex(i);
                        break;
                    }
                }
                
                // Clear password fields
                passwordField.setText("");
                confirmPasswordField.setText("");
                
                updateButton.setEnabled(true);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading teacher details: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading teacher details: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Handle Update Teacher button click - Demonstrates Data Validation and Database Operations
     */
    private void updateTeacherButtonActionPerformed(ActionEvent evt) {
        // Validate input fields
        if (!validateInput()) {
            return;
        }
        
        // Validate passwords if provided
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        if (!password.isEmpty() && !confirmPassword.isEmpty()) {
            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, 
                    "Passwords do not match!", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (password.length() < 6) {
                JOptionPane.showMessageDialog(this, 
                    "Password must be at least 6 characters long!", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // Start transaction
            
            try {
                // Update teacher record
                String teacherQuery = "UPDATE teachers SET teacher_number = ?, first_name = ?, last_name = ?, middle_name = ?, " +
                                    "department = ?, specialization = ?, employment_status = ? WHERE teacher_id = ?";
                PreparedStatement teacherStmt = conn.prepareStatement(teacherQuery);
                
                teacherStmt.setString(1, teacherNumberField.getText().trim());
                teacherStmt.setString(2, firstNameField.getText().trim());
                teacherStmt.setString(3, lastNameField.getText().trim());
                teacherStmt.setString(4, middleNameField.getText().trim());
                teacherStmt.setString(5, departmentField.getText().trim());
                teacherStmt.setString(6, specializationField.getText().trim());
                teacherStmt.setString(7, (String) employmentStatusCombo.getSelectedItem());
                teacherStmt.setInt(8, currentTeacherId);
                
                int teacherResult = teacherStmt.executeUpdate();
                teacherStmt.close();
                
                if (teacherResult == 0) {
                    throw new SQLException("Failed to update teacher record");
                }
                
                // Update user record
                String userQuery;
                PreparedStatement userStmt;
                
                if (!password.isEmpty()) {
                    // Update username and password
                    userQuery = "UPDATE users SET username = ?, password = ?, full_name = ? WHERE user_id = (SELECT user_id FROM teachers WHERE teacher_id = ?)";
                    userStmt = conn.prepareStatement(userQuery);
                    String fullName = firstNameField.getText().trim() + " " + lastNameField.getText().trim();
                    userStmt.setString(1, usernameField.getText().trim());
                    userStmt.setString(2, password); // In production, hash the password
                    userStmt.setString(3, fullName);
                    userStmt.setInt(4, currentTeacherId);
                } else {
                    // Update username only
                    userQuery = "UPDATE users SET username = ?, full_name = ? WHERE user_id = (SELECT user_id FROM teachers WHERE teacher_id = ?)";
                    userStmt = conn.prepareStatement(userQuery);
                    String fullName = firstNameField.getText().trim() + " " + lastNameField.getText().trim();
                    userStmt.setString(1, usernameField.getText().trim());
                    userStmt.setString(2, fullName);
                    userStmt.setInt(3, currentTeacherId);
                }
                
                userStmt.executeUpdate();
                userStmt.close();
                
                // Commit transaction
                conn.commit();
                
                JOptionPane.showMessageDialog(this, 
                    "Teacher updated successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh the list
                loadTeachers();
                clearForm();
                updateButton.setEnabled(false);
                
            } catch (SQLException e) {
                // Rollback transaction on error
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
                conn.close();
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error updating teacher: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error updating teacher: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Validate input fields - Demonstrates Input Validation
     */
    private boolean validateInput() {
        if (teacherNumberField.getText().trim().isEmpty()) {
            showValidationError("Teacher Number is required");
            teacherNumberField.requestFocus();
            return false;
        }
        
        if (firstNameField.getText().trim().isEmpty()) {
            showValidationError("First Name is required");
            firstNameField.requestFocus();
            return false;
        }
        
        if (lastNameField.getText().trim().isEmpty()) {
            showValidationError("Last Name is required");
            lastNameField.requestFocus();
            return false;
        }
        
        if (departmentField.getText().trim().isEmpty()) {
            showValidationError("Department is required");
            departmentField.requestFocus();
            return false;
        }
        
        if (usernameField.getText().trim().isEmpty()) {
            showValidationError("Username is required");
            usernameField.requestFocus();
            return false;
        }
        
        return true;
    }
    
    /**
     * Show validation error message - Demonstrates Error Handling
     */
    private void showValidationError(String message) {
        JOptionPane.showMessageDialog(this, 
            message, 
            "Validation Error", 
            JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Clear all form fields - Demonstrates Utility Methods
     */
    private void clearForm() {
        teacherNumberField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        middleNameField.setText("");
        departmentField.setText("");
        specializationField.setText("");
        employmentStatusCombo.setSelectedIndex(0);
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        currentTeacherId = -1;
    }
    
    /**
     * Handle Cancel button click - Demonstrates Event Handling
     */
    private void cancelButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
}
