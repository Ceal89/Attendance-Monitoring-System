package admin;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * RemoveTeacherDialog - Dialog for removing teachers with table view
 */
public class RemoveTeacherDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // UI Components
    private JTable teachersTable;
    private DefaultTableModel tableModel;
    private JTextArea reasonArea;
    private JButton removeButton;
    private JButton refreshButton;
    private JButton cancelButton;
    
    // Table columns
    private static final String[] COLUMN_NAMES = {
        "Teacher ID", "Teacher Number", "Full Name", "Department", "Specialization", "Employment Stat.", "Username", "Created At"
    };
    
    public RemoveTeacherDialog(AdminDashboard parent) {
        super(parent, "Remove Teacher", true);
        
        initComponents();
        setupEventHandlers();
        loadTeachers();
        
        setSize(900, 600);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(900, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Remove Teacher");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        tablePanel.setBackground(Color.WHITE);
        
        // Add title and instructions for table
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel tableTitleLabel = new JLabel("Teachers List");
        tableTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableTitleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        
        JLabel instructionLabel = new JLabel("Select a teacher from the table below to remove:");
        instructionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        instructionLabel.setForeground(new Color(100, 100, 100));
        
        titlePanel.add(tableTitleLabel, BorderLayout.NORTH);
        titlePanel.add(instructionLabel, BorderLayout.SOUTH);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        tablePanel.add(titlePanel, BorderLayout.NORTH);
        
        // Initialize table model
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        teachersTable = new JTable(tableModel);
        teachersTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        teachersTable.setRowHeight(25);
        teachersTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        teachersTable.getColumnModel().getColumn(0).setPreferredWidth(80);   // Teacher ID
        teachersTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // Teacher Number
        teachersTable.getColumnModel().getColumn(2).setPreferredWidth(150);  // Full Name
        teachersTable.getColumnModel().getColumn(3).setPreferredWidth(120);  // Department
        teachersTable.getColumnModel().getColumn(4).setPreferredWidth(150);  // Specialization
        teachersTable.getColumnModel().getColumn(5).setPreferredWidth(120);  // Employment Stat.
        teachersTable.getColumnModel().getColumn(6).setPreferredWidth(100);  // Username
        teachersTable.getColumnModel().getColumn(7).setPreferredWidth(150);  // Created At
        
        JScrollPane scrollPane = new JScrollPane(teachersTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Reason panel
        JPanel reasonPanel = new JPanel(new BorderLayout());
        reasonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        reasonPanel.setBackground(Color.WHITE);
        
        JLabel reasonLabel = new JLabel("Reason for Removal:");
        reasonLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        reasonPanel.add(reasonLabel, BorderLayout.NORTH);
        
        reasonArea = new JTextArea(3, 50);
        reasonArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reasonArea.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        reasonPanel.add(new JScrollPane(reasonArea), BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(33, 150, 243));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(100, 35));
        
        removeButton = new JButton("Remove Teacher");
        removeButton.setBackground(new Color(244, 67, 54));
        removeButton.setForeground(Color.WHITE);
        removeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeButton.setPreferredSize(new Dimension(140, 35));
        removeButton.setEnabled(false);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(158, 158, 158));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cancelButton.setPreferredSize(new Dimension(100, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(cancelButton);
        
        // Create main content panel
        JPanel mainContentPanel = new JPanel(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.add(tablePanel, BorderLayout.CENTER);
        mainContentPanel.add(reasonPanel, BorderLayout.SOUTH);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(mainContentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadTeachers();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeTeacher();
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        // Enable/disable remove button based on selection
        teachersTable.getSelectionModel().addListSelectionListener(e -> {
            boolean hasSelection = teachersTable.getSelectedRow() >= 0;
            removeButton.setEnabled(hasSelection);
        });
    }
    
    private void loadTeachers() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database. Please check your database connection.", 
                    "Database Connection Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String query = "SELECT t.teacher_id, t.teacher_number, t.first_name, t.last_name, t.middle_name, " +
                          "t.department, t.specialization, t.employment_status, u.username, t.created_at " +
                          "FROM teachers t " +
                          "LEFT JOIN users u ON t.user_id = u.user_id " +
                          "WHERE t.is_active = 1 ORDER BY t.teacher_number";
            
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                
                while (rs.next()) {
                    String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
                    if (rs.getString("middle_name") != null && !rs.getString("middle_name").trim().isEmpty()) {
                        fullName = rs.getString("first_name") + " " + rs.getString("middle_name") + " " + rs.getString("last_name");
                    }
                    
                    Object[] row = {
                        rs.getInt("teacher_id"),
                        rs.getString("teacher_number"),
                        fullName,
                        rs.getString("department"),
                        rs.getString("specialization"),
                        rs.getString("employment_status"),
                        rs.getString("username"),
                        rs.getTimestamp("created_at")
                    };
                    
                    tableModel.addRow(row);
                }
                
                System.out.println("✅ Loaded " + tableModel.getRowCount() + " teachers successfully");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading teachers: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error loading teachers: " + e.getMessage(),
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void removeTeacher() {
        int selectedRow = teachersTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a teacher to remove", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get teacher information
        int teacherId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String teacherNumber = (String) tableModel.getValueAt(selectedRow, 1);
        String fullName = (String) tableModel.getValueAt(selectedRow, 2);
        String reason = reasonArea.getText().trim();
        
        if (reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please provide a reason for removal", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Confirm removal
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove this teacher?\n\n" +
            "Teacher Number: " + teacherNumber + "\n" +
            "Name: " + fullName + "\n" +
            "Reason: " + reason + "\n\n" +
            "This action will deactivate the teacher account!",
            "Confirm Teacher Removal",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (choice == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                if (conn == null) {
                    JOptionPane.showMessageDialog(this, 
                        "Cannot connect to database", 
                        "Database Error", 
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                conn.setAutoCommit(false);
                
                try {
                    // Soft delete teacher
                    String teacherQuery = "UPDATE teachers SET is_active = 0 WHERE teacher_id = ?";
                    try (PreparedStatement teacherStmt = conn.prepareStatement(teacherQuery)) {
                        teacherStmt.setInt(1, teacherId);
                        int teacherResult = teacherStmt.executeUpdate();
                        
                        if (teacherResult == 0) {
                            throw new SQLException("Failed to remove teacher");
                        }
                    }
                    
                    // Deactivate user account
                    String userQuery = "UPDATE users SET is_active = 0 WHERE user_id = (SELECT user_id FROM teachers WHERE teacher_id = ?)";
                    try (PreparedStatement userStmt = conn.prepareStatement(userQuery)) {
                        userStmt.setInt(1, teacherId);
                        userStmt.executeUpdate();
                    }
                    
                    conn.commit();
                    
                    JOptionPane.showMessageDialog(this, 
                        "Teacher removed successfully!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Refresh the table
                    loadTeachers();
                    reasonArea.setText("");
                    removeButton.setEnabled(false);
                    
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
                
            } catch (SQLException e) {
                System.err.println("❌ Error removing teacher: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Error removing teacher: " + e.getMessage(),
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}