package admin;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * RemoveSubjectDialog - Dialog for removing subjects with table view
 */
public class RemoveSubjectDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // UI Components
    private JTable subjectsTable;
    private DefaultTableModel tableModel;
    private JTextArea reasonArea;
    private JButton removeButton;
    private JButton refreshButton;
    private JButton cancelButton;
    
    // Table columns
    private static final String[] COLUMN_NAMES = {
        "Subject ID", "Subject Code", "Subject Name", "Strand", "Grade Level", "Units", "Created At"
    };
    
    public RemoveSubjectDialog(AdminDashboard parent) {
        super(parent, "Remove Subject", true);
        
        initComponents();
        setupEventHandlers();
        loadSubjects();
        
        setSize(900, 600);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(900, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Remove Subject");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        tablePanel.setBackground(Color.WHITE);
        
        // Add title and instructions for table
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel tableTitleLabel = new JLabel("Subjects List");
        tableTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableTitleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        
        JLabel instructionLabel = new JLabel("Select a subject from the table below to remove:");
        instructionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        instructionLabel.setForeground(new Color(100, 100, 100));
        
        titlePanel.add(tableTitleLabel, BorderLayout.NORTH);
        titlePanel.add(instructionLabel, BorderLayout.SOUTH);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        tablePanel.add(titlePanel, BorderLayout.NORTH);
        
        // Initialize table model
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        subjectsTable = new JTable(tableModel);
        subjectsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        subjectsTable.setRowHeight(25);
        subjectsTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        subjectsTable.getColumnModel().getColumn(0).setPreferredWidth(80);   // Subject ID
        subjectsTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // Subject Code
        subjectsTable.getColumnModel().getColumn(2).setPreferredWidth(200);  // Subject Name
        subjectsTable.getColumnModel().getColumn(3).setPreferredWidth(100);  // Strand
        subjectsTable.getColumnModel().getColumn(4).setPreferredWidth(100);  // Grade Level
        subjectsTable.getColumnModel().getColumn(5).setPreferredWidth(80);   // Units
        subjectsTable.getColumnModel().getColumn(6).setPreferredWidth(150);  // Created At
        
        JScrollPane scrollPane = new JScrollPane(subjectsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Reason panel
        JPanel reasonPanel = new JPanel(new BorderLayout());
        reasonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        reasonPanel.setBackground(Color.WHITE);
        
        JLabel reasonLabel = new JLabel("Reason for Removal:");
        reasonLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        reasonPanel.add(reasonLabel, BorderLayout.NORTH);
        
        reasonArea = new JTextArea(3, 50);
        reasonArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reasonArea.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        reasonPanel.add(new JScrollPane(reasonArea), BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(33, 150, 243));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(100, 35));
        
        removeButton = new JButton("Remove Subject");
        removeButton.setBackground(new Color(244, 67, 54));
        removeButton.setForeground(Color.WHITE);
        removeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeButton.setPreferredSize(new Dimension(140, 35));
        removeButton.setEnabled(false);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(158, 158, 158));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cancelButton.setPreferredSize(new Dimension(100, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(cancelButton);
        
        // Create main content panel
        JPanel mainContentPanel = new JPanel(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.add(tablePanel, BorderLayout.CENTER);
        mainContentPanel.add(reasonPanel, BorderLayout.SOUTH);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(mainContentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadSubjects();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeSubject();
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        // Enable/disable remove button based on selection
        subjectsTable.getSelectionModel().addListSelectionListener(e -> {
            boolean hasSelection = subjectsTable.getSelectedRow() >= 0;
            removeButton.setEnabled(hasSelection);
        });
    }
    
    private void loadSubjects() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database. Please check your database connection.", 
                    "Database Connection Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String query = "SELECT subject_id, subject_code, subject_name, strand, grade_level, units, created_at " +
                          "FROM subjects WHERE is_active = 1 ORDER BY subject_code";
            
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                
                while (rs.next()) {
                    Object[] row = {
                        rs.getInt("subject_id"),
                        rs.getString("subject_code"),
                        rs.getString("subject_name"),
                        rs.getString("strand"),
                        rs.getString("grade_level"),
                        rs.getBigDecimal("units"),
                        rs.getTimestamp("created_at")
                    };
                    
                    tableModel.addRow(row);
                }
                
                System.out.println("✅ Loaded " + tableModel.getRowCount() + " subjects successfully");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading subjects: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error loading subjects: " + e.getMessage(),
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void removeSubject() {
        int selectedRow = subjectsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a subject to remove", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get subject information
        int subjectId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String subjectCode = (String) tableModel.getValueAt(selectedRow, 1);
        String subjectName = (String) tableModel.getValueAt(selectedRow, 2);
        String reason = reasonArea.getText().trim();
        
        if (reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please provide a reason for removal", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Check if subject has active teacher assignments
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database", 
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String checkQuery = "SELECT COUNT(*) as assignment_count FROM teacher_assignments " +
                              "WHERE subject_id = ? AND is_active = 1";
            
            try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
                checkStmt.setInt(1, subjectId);
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt("assignment_count") > 0) {
                        int choice = JOptionPane.showConfirmDialog(this,
                            "This subject has active teacher assignments.\n\n" +
                            "Removing it will also deactivate all related assignments.\n\n" +
                            "Are you sure you want to continue?",
                            "Active Assignments Warning",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                        
                        if (choice != JOptionPane.YES_OPTION) {
                            return;
                        }
                    }
                }
            }
            
            // Confirm removal
            int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to remove this subject?\n\n" +
                "Subject Code: " + subjectCode + "\n" +
                "Subject Name: " + subjectName + "\n" +
                "Reason: " + reason + "\n\n" +
                "This action will deactivate the subject!",
                "Confirm Subject Removal",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
            
            if (choice == JOptionPane.YES_OPTION) {
                conn.setAutoCommit(false);
                
                try {
                    // Soft delete subject
                    String subjectQuery = "UPDATE subjects SET is_active = 0 WHERE subject_id = ?";
                    try (PreparedStatement subjectStmt = conn.prepareStatement(subjectQuery)) {
                        subjectStmt.setInt(1, subjectId);
                        int subjectResult = subjectStmt.executeUpdate();
                        
                        if (subjectResult == 0) {
                            throw new SQLException("Failed to remove subject");
                        }
                    }
                    
                    // Deactivate related teacher assignments
                    String assignmentQuery = "UPDATE teacher_assignments SET is_active = 0 WHERE subject_id = ?";
                    try (PreparedStatement assignmentStmt = conn.prepareStatement(assignmentQuery)) {
                        assignmentStmt.setInt(1, subjectId);
                        assignmentStmt.executeUpdate();
                    }
                    
                    conn.commit();
                    
                    JOptionPane.showMessageDialog(this, 
                        "Subject removed successfully!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Refresh the table
                    loadSubjects();
                    reasonArea.setText("");
                    removeButton.setEnabled(false);
                    
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error removing subject: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error removing subject: " + e.getMessage(),
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
}