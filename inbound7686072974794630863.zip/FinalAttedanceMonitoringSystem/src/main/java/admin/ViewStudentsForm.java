package admin;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Simple View Students Form
 * Displays all students in a table format
 */
public class ViewStudentsForm extends JFrame {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // UI Components
    private JTable studentsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton closeButton;
    
    public ViewStudentsForm() {
        System.out.println("🔄 ViewStudentsForm constructor started");
        try {
            initComponents();
            System.out.println("✅ Components initialized");
            setupEventHandlers();
            System.out.println("✅ Event handlers setup");
            loadStudentsData();
            System.out.println("✅ ViewStudentsForm constructor completed successfully");
        } catch (Exception e) {
            System.err.println("❌ Error in ViewStudentsForm constructor: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Error initializing View Students form: " + e.getMessage(),
                "Initialization Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void initComponents() {
        System.out.println("🔄 Initializing ViewStudentsForm components...");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("View All Students");
        setSize(900, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        System.out.println("✅ Basic JFrame setup completed");
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(900, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Student Directory");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Table panel
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Create table
        String[] columnNames = {
            "Student ID", "Student Number", "First Name", "Last Name", "Middle Name",
            "Grade Level", "Section", "Username", "QR Code", "Status"
        };
        
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        studentsTable = new JTable(tableModel);
        studentsTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        studentsTable.setRowHeight(25);
        studentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentsTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        studentsTable.getTableHeader().setBackground(PRIMARY_COLOR);
        studentsTable.getTableHeader().setForeground(Color.WHITE);
        
        // Set column widths
        studentsTable.getColumnModel().getColumn(0).setPreferredWidth(80);  // Student ID
        studentsTable.getColumnModel().getColumn(1).setPreferredWidth(100); // Student Number
        studentsTable.getColumnModel().getColumn(2).setPreferredWidth(120); // First Name
        studentsTable.getColumnModel().getColumn(3).setPreferredWidth(120); // Last Name
        studentsTable.getColumnModel().getColumn(4).setPreferredWidth(120); // Middle Name
        studentsTable.getColumnModel().getColumn(5).setPreferredWidth(80);  // Grade Level
        studentsTable.getColumnModel().getColumn(6).setPreferredWidth(80);  // Section
        studentsTable.getColumnModel().getColumn(7).setPreferredWidth(100); // Username
        studentsTable.getColumnModel().getColumn(8).setPreferredWidth(150); // QR Code
        studentsTable.getColumnModel().getColumn(9).setPreferredWidth(80);  // Status
        
        JScrollPane scrollPane = new JScrollPane(studentsTable);
        scrollPane.setBorder(BorderFactory.createLoweredBevelBorder());
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(PRIMARY_COLOR);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        refreshButton.setPreferredSize(new Dimension(120, 35));
        
        closeButton = new JButton("Close");
        closeButton.setBackground(Color.GRAY);
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        closeButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        
        // Stats panel
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        statsPanel.setBackground(Color.WHITE);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel statsLabel = new JLabel("Total Students: 0");
        statsLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        statsLabel.setForeground(PRIMARY_COLOR);
        statsPanel.add(statsLabel);
        
        // Combine stats and button panels
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(statsPanel, BorderLayout.NORTH);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadStudentsData();
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
    
    private void loadStudentsData() {
        System.out.println("🔄 Loading students data...");
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database. Please check your database connection.", 
                    "Database Connection Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String query = "SELECT s.student_id, s.student_number, s.first_name, s.last_name, " +
                          "s.middle_name, s.grade_level, s.section, u.username, s.qr_code, " +
                          "CASE WHEN s.is_active = 1 THEN 'Active' ELSE 'Inactive' END as status " +
                          "FROM students s " +
                          "LEFT JOIN users u ON s.user_id = u.user_id " +
                          "ORDER BY s.student_number";
            
            System.out.println("📝 Executing query: " + query);
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            // Clear existing data
            tableModel.setRowCount(0);
            
            int totalStudents = 0;
            while (rs.next()) {
                Object[] row = {
                    rs.getInt("student_id"),
                    rs.getString("student_number"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("middle_name"),
                    rs.getString("grade_level"),
                    rs.getString("section"),
                    rs.getString("username"),
                    rs.getString("qr_code"),
                    rs.getString("status")
                };
                tableModel.addRow(row);
                totalStudents++;
            }
            
            // Update stats label
            updateStatsLabel(totalStudents);
            
            rs.close();
            stmt.close();
            
            System.out.println("✅ Loaded " + totalStudents + " students successfully");
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading students data: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error loading students data: " + e.getMessage() + "\n\n" +
                "Please ensure:\n" +
                "1. Database is running\n" +
                "2. Tables exist (students, users)\n" +
                "3. Database connection is configured correctly", 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateStatsLabel(int totalStudents) {
        // Find and update the stats label
        try {
            JPanel bottomPanel = (JPanel) getContentPane().getComponent(2);
            JPanel statsPanel = (JPanel) bottomPanel.getComponent(0);
            JLabel statsLabel = (JLabel) statsPanel.getComponent(0);
            statsLabel.setText("Total Students: " + totalStudents);
        } catch (Exception e) {
            System.err.println("Warning: Could not update stats label: " + e.getMessage());
        }
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ViewStudentsForm form = new ViewStudentsForm();
            form.setVisible(true);
        });
    }
}
