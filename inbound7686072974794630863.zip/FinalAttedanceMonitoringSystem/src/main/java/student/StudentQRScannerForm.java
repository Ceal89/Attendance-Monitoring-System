package student;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

// ZXing imports for QR code scanning
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.RGBLuminanceSource;

// Webcam capture imports
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Student QR Code Scanner Form
 * Demonstrates QR Code scanning using camera and attendance marking
 */
public class StudentQRScannerForm extends JDialog {
    
    // UI Components
    private JPanel headerPanel;
    private JPanel contentPanel;
    private JPanel buttonPanel;
    
    // Camera and QR Scanner components
    private Webcam webcam;
    private WebcamPanel webcamPanel;
    private JLabel statusLabel;
    private JLabel sessionInfoLabel;
    private JLabel cameraStatusLabel;
    private JPanel cameraPanel;
    private JLabel cameraPlaceholder;
    
    // Action buttons
    private JButton startCameraButton;
    private JButton stopCameraButton;
    private JButton closeButton;
    
    // QR Code scanning components
    private MultiFormatReader qrReader;
    private ScheduledExecutorService cameraExecutor;
    private boolean isScanning;
    
    // Data
    private int studentId;
    private String studentFullName;
    
    /**
     * Constructor
     * @param parent Parent frame
     * @param studentId Student ID
     * @param studentFullName Student full name
     */
    public StudentQRScannerForm(Frame parent, int studentId, String studentFullName) {
        super(parent, "QR Code Scanner - " + studentFullName, true);
        this.studentId = studentId;
        this.studentFullName = studentFullName;
        this.isScanning = false;
        
        initComponents();
        setupEventHandlers();
        initQRReader();
        
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    /**
     * Initialize UI components
     * Demonstrates UI Component initialization with camera support
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setSize(800, 700);
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setPreferredSize(new Dimension(0, 60));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("QR Code Attendance Scanner");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Content Panel
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Instructions Panel
        JPanel instructionsPanel = new JPanel(new BorderLayout());
        instructionsPanel.setBorder(BorderFactory.createTitledBorder("Instructions"));
        
        JTextArea instructionsText = new JTextArea(4, 50);
        instructionsText.setEditable(false);
        instructionsText.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        instructionsText.setBackground(contentPanel.getBackground());
        instructionsText.setText(
            "HOW TO SCAN QR CODE:\n\n" +
            "1. Click 'Start Camera' to activate your webcam\n" +
            "2. Point your camera at the QR code displayed by your teacher\n" +
            "3. The system will automatically detect and scan the QR code\n" +
            "4. Your attendance will be marked automatically\n\n" +
            "Note: Make sure your camera has permission to access the webcam."
        );
        instructionsPanel.add(instructionsText, BorderLayout.CENTER);
        
        contentPanel.add(instructionsPanel, BorderLayout.NORTH);
        
        // Camera Panel
        cameraPanel = new JPanel(new BorderLayout());
        cameraPanel.setBorder(BorderFactory.createTitledBorder("Camera View"));
        
        // Initialize webcam panel placeholder (will be set up when camera starts)
        webcamPanel = null; // Will be created when camera starts
        cameraPlaceholder = new JLabel("Camera will start here", SwingConstants.CENTER);
        cameraPlaceholder.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cameraPlaceholder.setForeground(Color.GRAY);
        cameraPlaceholder.setPreferredSize(new Dimension(320, 240));
        cameraPanel.add(cameraPlaceholder, BorderLayout.CENTER);
        
        // Camera status label
        cameraStatusLabel = new JLabel("Camera not started - Click 'Start Camera' to begin");
        cameraStatusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        cameraStatusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cameraStatusLabel.setForeground(Color.GRAY);
        cameraPanel.add(cameraStatusLabel, BorderLayout.SOUTH);
        
        contentPanel.add(cameraPanel, BorderLayout.CENTER);
        
        // Status Panel
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createTitledBorder("Status"));
        
        statusLabel = new JLabel("Ready to start camera");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(Color.BLACK);
        statusLabel.setHorizontalAlignment(SwingConstants.LEFT);
        statusPanel.add(statusLabel, BorderLayout.NORTH);
        
        sessionInfoLabel = new JLabel("");
        sessionInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sessionInfoLabel.setForeground(Color.GRAY);
        sessionInfoLabel.setHorizontalAlignment(SwingConstants.LEFT);
        statusPanel.add(sessionInfoLabel, BorderLayout.CENTER);
        
        contentPanel.add(statusPanel, BorderLayout.SOUTH);
        
        add(contentPanel, BorderLayout.CENTER);
        
        // Button Panel
        buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        startCameraButton = new JButton("Start Camera");
        startCameraButton.setBackground(new Color(0, 128, 0));
        startCameraButton.setForeground(Color.WHITE);
        startCameraButton.setPreferredSize(new Dimension(120, 35));
        buttonPanel.add(startCameraButton);
        
        stopCameraButton = new JButton("Stop Camera");
        stopCameraButton.setBackground(new Color(220, 53, 69));
        stopCameraButton.setForeground(Color.WHITE);
        stopCameraButton.setPreferredSize(new Dimension(120, 35));
        stopCameraButton.setEnabled(false);
        buttonPanel.add(stopCameraButton);
        
        closeButton = new JButton("Close");
        closeButton.setPreferredSize(new Dimension(80, 35));
        buttonPanel.add(closeButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers
     * Demonstrates Event Handling
     */
    private void setupEventHandlers() {
        startCameraButton.addActionListener(e -> startCameraButtonActionPerformed(e));
        stopCameraButton.addActionListener(e -> stopCameraButtonActionPerformed(e));
        closeButton.addActionListener(e -> closeButtonActionPerformed(e));
    }
    
    /**
     * Initialize QR code reader
     */
    private void initQRReader() {
        qrReader = new MultiFormatReader();
        Map<DecodeHintType, Object> hints = new java.util.HashMap<>();
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, java.util.Arrays.asList(
            com.google.zxing.BarcodeFormat.QR_CODE
        ));
        qrReader.setHints(hints);
    }
    
    /**
     * Start camera button action
     */
    private void startCameraButtonActionPerformed(ActionEvent evt) {
        try {
            // Get default webcam
            webcam = Webcam.getDefault();
            if (webcam == null) {
                updateStatus("No camera found. Please check your camera connection.", Color.RED);
                return;
            }
            
            // Set webcam resolution
            webcam.setViewSize(WebcamResolution.QVGA.getSize());
            
            // Start webcam
            webcam.open();
            
            // Update UI - Create new webcam panel with the webcam
            webcamPanel = new WebcamPanel(webcam);
            webcamPanel.setFPSDisplayed(true);
            webcamPanel.setDisplayDebugInfo(false);
            webcamPanel.setMirrored(true);
            
            // Replace the placeholder with the actual webcam panel
            cameraPanel.removeAll();
            cameraPanel.add(webcamPanel, BorderLayout.CENTER);
            cameraPanel.add(cameraStatusLabel, BorderLayout.SOUTH);
            cameraPanel.revalidate();
            cameraPanel.repaint();
            
            webcamPanel.start();
            
            startCameraButton.setEnabled(false);
            stopCameraButton.setEnabled(true);
            
            updateStatus("Camera started. Point camera at QR code to scan.", Color.BLUE);
            cameraStatusLabel.setText("Camera active - Scanning for QR codes...");
            cameraStatusLabel.setForeground(new Color(0, 128, 0));
            
            // Start QR code scanning
            startQRCodeScanning();
            
        } catch (Exception e) {
            System.err.println("❌ Error starting camera: " + e.getMessage());
            updateStatus("Error starting camera: " + e.getMessage(), Color.RED);
        }
    }
    
    /**
     * Stop camera button action
     */
    private void stopCameraButtonActionPerformed(ActionEvent evt) {
        stopQRCodeScanning();
        stopCamera();
    }
    
    /**
     * Close button action
     */
    private void closeButtonActionPerformed(ActionEvent evt) {
        stopQRCodeScanning();
        stopCamera();
        dispose();
    }
    
    /**
     * Start QR code scanning
     */
    private void startQRCodeScanning() {
        isScanning = true;
        cameraExecutor = Executors.newSingleThreadScheduledExecutor();
        
        cameraExecutor.scheduleAtFixedRate(() -> {
            if (isScanning && webcam != null && webcam.isOpen()) {
                try {
                    BufferedImage image = webcam.getImage();
                    if (image != null) {
                        String qrData = scanQRCode(image);
                        if (qrData != null && !qrData.isEmpty()) {
                            SwingUtilities.invokeLater(() -> processQRCode(qrData));
                        }
                    }
                } catch (Exception e) {
                    // Silently handle scanning errors to avoid spam
                }
            }
        }, 0, 500, TimeUnit.MILLISECONDS); // Scan every 500ms
    }
    
    /**
     * Stop QR code scanning
     */
    private void stopQRCodeScanning() {
        isScanning = false;
        if (cameraExecutor != null && !cameraExecutor.isShutdown()) {
            cameraExecutor.shutdown();
        }
    }
    
    /**
     * Stop camera
     */
    private void stopCamera() {
        try {
            if (webcam != null && webcam.isOpen()) {
                webcam.close();
            }
            if (webcamPanel != null) {
                webcamPanel.stop();
                webcamPanel = null;
            }
            
            // Restore placeholder
            cameraPanel.removeAll();
            cameraPanel.add(cameraPlaceholder, BorderLayout.CENTER);
            cameraPanel.add(cameraStatusLabel, BorderLayout.SOUTH);
            cameraPanel.revalidate();
            cameraPanel.repaint();
            
            startCameraButton.setEnabled(true);
            stopCameraButton.setEnabled(false);
            
            updateStatus("Camera stopped.", Color.BLACK);
            cameraStatusLabel.setText("Camera stopped");
            cameraStatusLabel.setForeground(Color.GRAY);
            
        } catch (Exception e) {
            System.err.println("❌ Error stopping camera: " + e.getMessage());
        }
    }
    
    /**
     * Scan QR code from image
     */
    private String scanQRCode(BufferedImage image) {
        try {
            int width = image.getWidth();
            int height = image.getHeight();
            int[] pixels = new int[width * height];
            image.getRGB(0, 0, width, height, pixels, 0, width);
            
            RGBLuminanceSource source = new RGBLuminanceSource(width, height, pixels);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            
            Result result = qrReader.decodeWithState(bitmap);
            return result.getText();
            
        } catch (Exception e) {
            // No QR code found in this frame
            return null;
        }
    }
    
    /**
     * Process scanned QR code
     */
    private void processQRCode(String qrData) {
        updateStatus("QR code detected! Processing...", Color.BLUE);
        
        // Parse QR code data
        QRCodeData parsedData = parseQRCodeData(qrData);
        if (parsedData == null) {
            updateStatus("Invalid QR code format.", Color.RED);
            return;
        }
        
        // Validate QR code
        if (!validateQRCode(parsedData)) {
            updateStatus("Invalid or expired QR code.", Color.RED);
            return;
        }
        
        // Mark attendance
        boolean success = markAttendance(parsedData);
        if (success) {
            updateStatus("Attendance marked successfully!", Color.GREEN);
            sessionInfoLabel.setText(String.format("Session: %s | Teacher: %s | Time: %s", 
                                                  parsedData.getSessionId().substring(0, 8),
                                                  parsedData.getTeacherName(),
                                                  LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
            
            // Stop scanning after successful attendance
            stopQRCodeScanning();
            stopCamera();
            
            // Show success message
            JOptionPane.showMessageDialog(this, 
                "Attendance marked successfully!\nYou can now close this window.",
                "Attendance Confirmed", JOptionPane.INFORMATION_MESSAGE);
                
        } else {
            updateStatus("Failed to mark attendance. Please try again.", Color.RED);
        }
    }
    
    /**
     * Parse QR code data
     * Demonstrates String parsing and data extraction
     */
    private QRCodeData parseQRCodeData(String qrData) {
        try {
            QRCodeData data = new QRCodeData();
            
            // Parse each line of QR code data
            String[] lines = qrData.split("\n");
            for (String line : lines) {
                if (line.contains(":")) {
                    String[] parts = line.split(":", 2);
                    String key = parts[0].trim();
                    String value = parts[1].trim();
                    
                    switch (key) {
                        case "SESSION_ID":
                            data.setSessionId(value);
                            break;
                        case "TEACHER_ID":
                            data.setTeacherId(Integer.parseInt(value));
                            break;
                        case "SUBJECT_ID":
                            data.setSubjectId(Integer.parseInt(value));
                            break;
                        case "SECTION":
                            data.setSection(value);
                            break;
                        case "DATE":
                            data.setDate(value);
                            break;
                        case "TEACHER":
                            data.setTeacherName(value);
                            break;
                        case "QR_TYPE":
                            data.setQrType(value);
                            break;
                    }
                }
            }
            
            return data;
        } catch (Exception e) {
            System.err.println("❌ Error parsing QR code data: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Validate QR code
     */
    private boolean validateQRCode(QRCodeData data) {
        // Check if QR code is for student attendance
        if (!"STUDENT_ATTENDANCE".equals(data.getQrType())) {
            return false;
        }
        
        // Check if date is today
        String today = LocalDate.now().toString();
        if (!today.equals(data.getDate())) {
            return false;
        }
        
        // Check if all required fields are present
        return data.getSessionId() != null && 
               data.getTeacherId() > 0 && 
               data.getSubjectId() > 0 && 
               data.getSection() != null;
    }
    
    /**
     * Mark attendance in database
     */
    private boolean markAttendance(QRCodeData data) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            if (conn == null) {
                return false;
            }
            
            conn.setAutoCommit(false);
            
            // Check if attendance already exists
            String checkQuery = "SELECT attendance_id FROM attendance_records " +
                               "WHERE student_id = ? AND subject_id = ? AND attendance_date = CURDATE()";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setInt(1, studentId);
            checkStmt.setInt(2, data.getSubjectId());
            
            boolean attendanceExists = checkStmt.executeQuery().next();
            checkStmt.close();
            
            String query;
            if (attendanceExists) {
                // Update existing attendance
                query = "UPDATE attendance_records SET " +
                       "status = 'Present', time_in = CURTIME(), recorded_by = ? " +
                       "WHERE student_id = ? AND subject_id = ? AND attendance_date = CURDATE()";
            } else {
                // Insert new attendance
                query = "INSERT INTO attendance_records " +
                       "(student_id, subject_id, attendance_date, time_in, status, recorded_by) " +
                       "VALUES (?, ?, CURDATE(), CURTIME(), 'Present', ?)";
            }
            
            PreparedStatement stmt = conn.prepareStatement(query);
            if (attendanceExists) {
                stmt.setInt(1, data.getTeacherId());
                stmt.setInt(2, studentId);
                stmt.setInt(3, data.getSubjectId());
            } else {
                stmt.setInt(1, studentId);
                stmt.setInt(2, data.getSubjectId());
                stmt.setInt(3, data.getTeacherId());
            }
            
            int result = stmt.executeUpdate();
            stmt.close();
            
            if (result > 0) {
                conn.commit();
                System.out.println("✅ Student " + studentFullName + " marked attendance via QR code");
                return true;
            } else {
                conn.rollback();
                return false;
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error marking attendance: " + e.getMessage());
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("❌ Error during rollback: " + rollbackEx.getMessage());
            }
            return false;
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.err.println("❌ Error closing connection: " + e.getMessage());
            }
        }
    }
    
    /**
     * Update status label
     */
    private void updateStatus(String message, Color color) {
        statusLabel.setText(message);
        statusLabel.setForeground(color);
        SwingUtilities.invokeLater(() -> {
            statusLabel.repaint();
        });
    }
    
    /**
     * QR Code Data class
     * Demonstrates Encapsulation
     */
    private static class QRCodeData {
        private String sessionId;
        private int teacherId;
        private int subjectId;
        private String section;
        private String date;
        private String teacherName;
        private String qrType;
        
        // Getters and Setters
        public String getSessionId() { return sessionId; }
        public void setSessionId(String sessionId) { this.sessionId = sessionId; }
        
        public int getTeacherId() { return teacherId; }
        public void setTeacherId(int teacherId) { this.teacherId = teacherId; }
        
        public int getSubjectId() { return subjectId; }
        public void setSubjectId(int subjectId) { this.subjectId = subjectId; }
        
        public String getSection() { return section; }
        public void setSection(String section) { this.section = section; }
        
        public String getDate() { return date; }
        public void setDate(String date) { this.date = date; }
        
        
        public String getTeacherName() { return teacherName; }
        public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
        
        public String getQrType() { return qrType; }
        public void setQrType(String qrType) { this.qrType = qrType; }
    }
}
