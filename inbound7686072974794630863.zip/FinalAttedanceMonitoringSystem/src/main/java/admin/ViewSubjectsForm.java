package admin;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * View Subjects Form
 * Displays all subjects in a table format
 */
public class ViewSubjectsForm extends JFrame {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    private JTable subjectsTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton closeButton;
    
    // Panels
    private JPanel headerPanel;
    private JPanel tablePanel;
    private JPanel buttonPanel;
    
  
    
    public ViewSubjectsForm() {
        super("View Subjects");
        
        initComponents();
        setupEventHandlers();
        loadSubjectsData();
        
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
    private void initComponents() {
        // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
        setLayout(new BorderLayout());
        
        // Header panel
        headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("View Subjects");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Table panel
        tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        tablePanel.setBackground(Color.WHITE);
        
        // Create table model
        String[] columnNames = {"Subject Code", "Subject Name", "Description", "Strand", "Grade Level", "Units", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        subjectsTable = new JTable(tableModel);
        subjectsTable.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subjectsTable.setRowHeight(25);
        subjectsTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        subjectsTable.getTableHeader().setBackground(PRIMARY_COLOR);
        subjectsTable.getTableHeader().setForeground(Color.WHITE);
        subjectsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(subjectsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        add(tablePanel, BorderLayout.CENTER);
        
        // Button panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(0, 128, 0));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFocusPainted(false);
        refreshButton.setPreferredSize(new Dimension(100, 35));
        
        closeButton = new JButton("Close");
        closeButton.setBackground(new Color(128, 128, 128));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setPreferredSize(new Dimension(100, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
        // </editor-fold>//GEN-END:initComponents
    }
    
    private void setupEventHandlers() {
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshButtonActionPerformed(e);
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeButtonActionPerformed(e);
            }
        });
    }
    
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadSubjectsData();
    }
    
    private void closeButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
    
    private void loadSubjectsData() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT subject_code, subject_name, description, strand, grade_level, units, " +
                              "CASE WHEN is_active = 1 THEN 'Active' ELSE 'Inactive' END as status " +
                              "FROM subjects ORDER BY strand, grade_level, subject_code";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();
                
                while (rs.next()) {
                    Object[] row = {
                        rs.getString("subject_code"),
                        rs.getString("subject_name"),
                        rs.getString("description"),
                        rs.getString("strand"),
                        rs.getString("grade_level"),
                        rs.getDouble("units"),
                        rs.getString("status")
                    };
                    tableModel.addRow(row);
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Subjects data loaded successfully");
            } else {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading subjects data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading subjects: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
