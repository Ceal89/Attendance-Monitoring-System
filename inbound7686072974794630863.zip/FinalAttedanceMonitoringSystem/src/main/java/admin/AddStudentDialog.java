package admin;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Simple Add Student Dialog
 * Allows admin to add new students to the system
 */
public class AddStudentDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // Form fields
    private JTextField studentNumberField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField middleNameField;
    private JComboBox<String> gradeLevelCombo;
    private JTextField sectionField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    
    // Buttons
    private JButton addButton;
    private JButton cancelButton;
    
    // Parent reference
    private AdminDashboard parent;
    
    public AddStudentDialog(AdminDashboard parent) {
        super(parent, "Add New Student", true);
        this.parent = parent;
        
        initComponents();
        setupEventHandlers();
        
        setSize(500, 600);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(500, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Add New Student");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Student Number
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Student Number *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        studentNumberField = new JTextField(20);
        formPanel.add(studentNumberField, gbc);
        
        // First Name
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("First Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Last Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField, gbc);
        
        // Middle Name
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Middle Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        middleNameField = new JTextField(20);
        formPanel.add(middleNameField, gbc);
        
        // Grade Level
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Grade Level *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gradeLevelCombo = new JComboBox<>(new String[]{"Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"});
        formPanel.add(gradeLevelCombo, gbc);
        
        // Section
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Section *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        sectionField = new JTextField(20);
        formPanel.add(sectionField, gbc);
        
        // Username
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Username *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 7; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Password *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 8; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Confirm Password *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(20);
        formPanel.add(confirmPasswordField, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        addButton = new JButton("Add Student");
        addButton.setBackground(PRIMARY_COLOR);
        addButton.setForeground(Color.WHITE);
        addButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        addButton.setPreferredSize(new Dimension(120, 35));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(Color.GRAY);
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(addButton);
        buttonPanel.add(cancelButton);
        
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addStudent();
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
    
    private void addStudent() {
        // Validate required fields
        if (studentNumberField.getText().trim().isEmpty() ||
            firstNameField.getText().trim().isEmpty() ||
            lastNameField.getText().trim().isEmpty() ||
            sectionField.getText().trim().isEmpty() ||
            usernameField.getText().trim().isEmpty() ||
            passwordField.getPassword().length == 0 ||
            confirmPasswordField.getPassword().length == 0) {
            
            JOptionPane.showMessageDialog(this, 
                "Please fill in all required fields (*)", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate passwords match
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, 
                "Passwords do not match!", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            confirmPasswordField.requestFocus();
            return;
        }
        
        if (password.length() < 6) {
            JOptionPane.showMessageDialog(this, 
                "Password must be at least 6 characters long", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            passwordField.requestFocus();
            return;
        }
        
        Connection conn = null;
        try {
            System.out.println("🔄 Attempting to connect to database...");
            conn = DatabaseConnection.getConnection();
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database. Please check your database connection.", 
                    "Database Connection Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            System.out.println("✅ Database connection successful");
            
            // Check if student number already exists
            String checkStudentQuery = "SELECT COUNT(*) FROM students WHERE student_number = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkStudentQuery);
            checkStmt.setString(1, studentNumberField.getText().trim());
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Student number already exists!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if username already exists
            String checkUserQuery = "SELECT COUNT(*) FROM users WHERE username = ?";
            PreparedStatement checkUserStmt = conn.prepareStatement(checkUserQuery);
            checkUserStmt.setString(1, usernameField.getText().trim());
            ResultSet userRs = checkUserStmt.executeQuery();
            
            if (userRs.next() && userRs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Username already exists!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Start transaction
            conn.setAutoCommit(false);
            
            // Insert user first
            System.out.println("🔄 Inserting user record...");
            String userQuery = "INSERT INTO users (username, password, full_name, user_type, is_active) VALUES (?, ?, ?, 'student', 1)";
            PreparedStatement userStmt = conn.prepareStatement(userQuery, Statement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, usernameField.getText().trim());
            userStmt.setString(2, new String(passwordField.getPassword()));
            userStmt.setString(3, firstNameField.getText().trim() + " " + lastNameField.getText().trim());
            
            int userResult = userStmt.executeUpdate();
            System.out.println("✅ User insertion result: " + userResult);
            
            ResultSet generatedKeys = userStmt.getGeneratedKeys();
            int userId = -1;
            if (generatedKeys.next()) {
                userId = generatedKeys.getInt(1);
            }
            
            // Insert student
            System.out.println("🔄 Inserting student record with user_id: " + userId);
            String studentQuery = "INSERT INTO students (user_id, student_number, first_name, last_name, middle_name, grade_level, section, qr_code, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)";
            PreparedStatement studentStmt = conn.prepareStatement(studentQuery);
            studentStmt.setInt(1, userId);
            studentStmt.setString(2, studentNumberField.getText().trim());
            studentStmt.setString(3, firstNameField.getText().trim());
            studentStmt.setString(4, lastNameField.getText().trim());
            studentStmt.setString(5, middleNameField.getText().trim());
            studentStmt.setString(6, (String) gradeLevelCombo.getSelectedItem());
            studentStmt.setString(7, sectionField.getText().trim());
            studentStmt.setString(8, "QR_" + studentNumberField.getText().trim());
            
            int studentResult = studentStmt.executeUpdate();
            System.out.println("✅ Student insertion result: " + studentResult);
            
            // Commit transaction
            conn.commit();
            
            JOptionPane.showMessageDialog(this, 
                "Student added successfully!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Clear form
            clearForm();
            
            // Refresh parent dashboard if needed
            if (parent != null) {
                parent.loadDashboardData();
            }
            
        } catch (SQLException e) {
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            
            JOptionPane.showMessageDialog(this, 
                "Error adding student: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void clearForm() {
        studentNumberField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        middleNameField.setText("");
        gradeLevelCombo.setSelectedIndex(0);
        sectionField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
    }
}
