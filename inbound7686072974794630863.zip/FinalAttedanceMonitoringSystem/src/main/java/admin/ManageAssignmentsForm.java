package admin;

import common.DatabaseConnection;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * ManageAssignmentsForm - Form for managing teacher assignments to subjects and sections
 * Demonstrates Object-Oriented Programming principles
 */
public class ManageAssignmentsForm extends JFrame {
    
    // UI Components - Encapsulation
    private JTable assignmentsTable;
    private DefaultTableModel tableModel;
    private JButton addAssignmentButton;
    private JButton editAssignmentButton;
    private JButton removeAssignmentButton;
    private JButton refreshButton;
    private JButton closeButton;
    private JLabel statusLabel;
    
    
    // Table columns
    private static final String[] COLUMN_NAMES = {
        "Assignment ID", "Teacher", "Subject", "Section", "Grade Level", 
        "Academic Year", "Semester", "Schedule", "Time", "Room", "Status"
    };
    
    /**
     * Constructor - Demonstrates Encapsulation and Polymorphism
     */
    public ManageAssignmentsForm() {
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        
        setTitle("Manage Teacher Assignments");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        loadAssignments();
    }
    
    /**
     * Initialize UI components - Demonstrates Encapsulation
     */
    private void initializeComponents() {
        // Initialize table model
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        assignmentsTable = new JTable(tableModel);
        assignmentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        assignmentsTable.setRowHeight(25);
        assignmentsTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        assignmentsTable.getColumnModel().getColumn(0).setPreferredWidth(100);  // Assignment ID
        assignmentsTable.getColumnModel().getColumn(1).setPreferredWidth(150);  // Teacher
        assignmentsTable.getColumnModel().getColumn(2).setPreferredWidth(120);  // Subject
        assignmentsTable.getColumnModel().getColumn(3).setPreferredWidth(100);  // Section
        assignmentsTable.getColumnModel().getColumn(4).setPreferredWidth(100);  // Grade Level
        assignmentsTable.getColumnModel().getColumn(5).setPreferredWidth(100);  // Academic Year
        assignmentsTable.getColumnModel().getColumn(6).setPreferredWidth(80);   // Semester
        assignmentsTable.getColumnModel().getColumn(7).setPreferredWidth(120);  // Schedule
        assignmentsTable.getColumnModel().getColumn(8).setPreferredWidth(120);  // Time
        assignmentsTable.getColumnModel().getColumn(9).setPreferredWidth(100);  // Room
        assignmentsTable.getColumnModel().getColumn(10).setPreferredWidth(80);  // Status
        
        addAssignmentButton = new JButton("Add Assignment");
        addAssignmentButton.setBackground(new Color(76, 175, 80));
        addAssignmentButton.setForeground(Color.WHITE);
        addAssignmentButton.setFocusPainted(false);
        
        editAssignmentButton = new JButton("Edit Assignment");
        editAssignmentButton.setBackground(new Color(255, 152, 0));
        editAssignmentButton.setForeground(Color.WHITE);
        editAssignmentButton.setFocusPainted(false);
        editAssignmentButton.setEnabled(false);
        
        removeAssignmentButton = new JButton("Remove Assignment");
        removeAssignmentButton.setBackground(new Color(244, 67, 54));
        removeAssignmentButton.setForeground(Color.WHITE);
        removeAssignmentButton.setFocusPainted(false);
        removeAssignmentButton.setEnabled(false);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(33, 150, 243));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFocusPainted(false);
        
        closeButton = new JButton("Close");
        closeButton.setBackground(new Color(158, 158, 158));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        
        statusLabel = new JLabel("Loading assignments...");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(100, 100, 100));
        
    }
    
    /**
     * Setup form layout - Demonstrates UI Design
     */
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Header
        JLabel headerLabel = new JLabel("Teacher Assignments Management", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(headerLabel, BorderLayout.NORTH);
        
        // Main content panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Table panel
        JScrollPane scrollPane = new JScrollPane(assignmentsTable);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 20, 10, 20),
            BorderFactory.createLineBorder(new Color(200, 200, 200))
        ));
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        buttonPanel.add(addAssignmentButton);
        buttonPanel.add(editAssignmentButton);
        buttonPanel.add(removeAssignmentButton);
        buttonPanel.add(Box.createHorizontalStrut(20));
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel, BorderLayout.CENTER);
        
        // Bottom panel with status
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        bottomPanel.add(statusLabel, BorderLayout.WEST);
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers - Demonstrates Event-Driven Programming
     */
    private void setupEventHandlers() {
        addAssignmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addAssignmentButtonActionPerformed(e);
            }
        });
        
        editAssignmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editAssignmentButtonActionPerformed(e);
            }
        });
        
        removeAssignmentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeAssignmentButtonActionPerformed(e);
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshButtonActionPerformed(e);
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeButtonActionPerformed(e);
            }
        });
        
        assignmentsTable.getSelectionModel().addListSelectionListener(e -> {
            boolean hasSelection = assignmentsTable.getSelectedRow() >= 0;
            editAssignmentButton.setEnabled(hasSelection);
            removeAssignmentButton.setEnabled(hasSelection);
        });
    }
    
    /**
     * Load assignments from database - Demonstrates Database Operations
     */
    private void loadAssignments() {
        statusLabel.setText("Loading assignments...");
        
        // Clear existing data
        tableModel.setRowCount(0);
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT ta.assignment_id, " +
                          "CONCAT(t.first_name, ' ', t.last_name) as teacher_name, " +
                          "s.subject_name, ta.section, ta.grade_level, ta.academic_year, " +
                          "ta.semester, ta.schedule_days, ta.start_time, ta.end_time, " +
                          "ta.room_number, ta.is_active " +
                          "FROM teacher_assignments ta " +
                          "JOIN teachers t ON ta.teacher_id = t.teacher_id " +
                          "JOIN subjects s ON ta.subject_id = s.subject_id " +
                          "ORDER BY ta.academic_year DESC, ta.semester, t.last_name, s.subject_name";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            int count = 0;
            while (rs.next()) {
                // Format time display
                String startTime = rs.getString("start_time");
                String endTime = rs.getString("end_time");
                String timeDisplay = "N/A";
                if (startTime != null && endTime != null) {
                    timeDisplay = startTime.substring(0, 5) + " - " + endTime.substring(0, 5);
                }
                
                // Format status
                String status = rs.getBoolean("is_active") ? "Active" : "Inactive";
                
                // Add row to table
                Object[] row = {
                    rs.getInt("assignment_id"),
                    rs.getString("teacher_name"),
                    rs.getString("subject_name"),
                    rs.getString("section"),
                    rs.getString("grade_level"),
                    rs.getString("academic_year"),
                    rs.getString("semester"),
                    rs.getString("schedule_days") != null ? rs.getString("schedule_days") : "N/A",
                    timeDisplay,
                    rs.getString("room_number") != null ? rs.getString("room_number") : "N/A",
                    status
                };
                
                tableModel.addRow(row);
                count++;
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
            statusLabel.setText("Loaded " + count + " assignments");
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading assignments: " + e.getMessage());
            statusLabel.setText("Error loading assignments");
            JOptionPane.showMessageDialog(this, 
                "Error loading assignments: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Handle Add Assignment button click - Demonstrates Event Handling
     */
    private void addAssignmentButtonActionPerformed(ActionEvent evt) {
        showAssignmentDialog(null);
    }
    
    /**
     * Handle Edit Assignment button click - Demonstrates Event Handling
     */
    private void editAssignmentButtonActionPerformed(ActionEvent evt) {
        int selectedRow = assignmentsTable.getSelectedRow();
        if (selectedRow >= 0) {
            Object assignmentId = tableModel.getValueAt(selectedRow, 0);
            showAssignmentDialog((Integer) assignmentId);
        }
    }
    
    /**
     * Handle Remove Assignment button click - Demonstrates Event Handling
     */
    private void removeAssignmentButtonActionPerformed(ActionEvent evt) {
        int selectedRow = assignmentsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select an assignment to remove", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        Object assignmentId = tableModel.getValueAt(selectedRow, 0);
        String teacherName = (String) tableModel.getValueAt(selectedRow, 1);
        String subjectName = (String) tableModel.getValueAt(selectedRow, 2);
        String section = (String) tableModel.getValueAt(selectedRow, 3);
        
        // Confirm removal
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove this assignment?\n\n" +
            "Teacher: " + teacherName + "\n" +
            "Subject: " + subjectName + "\n" +
            "Section: " + section + "\n\n" +
            "This action cannot be undone!",
            "Confirm Assignment Removal",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (choice == JOptionPane.YES_OPTION) {
            removeAssignment((Integer) assignmentId);
        }
    }
    
    /**
     * Handle Refresh button click - Demonstrates Event Handling
     */
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadAssignments();
        System.out.println("Assignments list refreshed");
    }
    
    /**
     * Handle Close button click - Demonstrates Event Handling
     */
    private void closeButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
    
    /**
     * Show assignment dialog - Demonstrates Dialog Management
     */
    private void showAssignmentDialog(Integer assignmentId) {
        // Create and show assignment dialog
        AssignmentDialog dialog = new AssignmentDialog(this, assignmentId);
        dialog.setVisible(true);
        
        // Refresh table after dialog closes
        loadAssignments();
    }
    
    /**
     * Remove assignment - Demonstrates Database Operations
     */
    private void removeAssignment(int assignmentId) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "UPDATE teacher_assignments SET is_active = 0 WHERE assignment_id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, assignmentId);
            
            int result = stmt.executeUpdate();
            stmt.close();
            conn.close();
            
            if (result > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Assignment removed successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                loadAssignments();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Failed to remove assignment", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error removing assignment: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error removing assignment: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Get assignment count - Demonstrates Data Analysis
     */
    public int getAssignmentCount() {
        return tableModel.getRowCount();
    }
}
