package admin;

import common.DatabaseConnection;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

/**
 * AssignmentDialog - Dialog for adding/editing teacher assignments
 * Demonstrates Object-Oriented Programming principles
 */
public class AssignmentDialog extends JDialog {
    
    // UI Components - Encapsulation
    private JComboBox<String> teacherCombo;
    private JComboBox<String> subjectCombo;
    private JTextField sectionField;
    private JTextField gradeLevelField;
    private JTextField academicYearField;
    private JComboBox<String> semesterCombo;
    private JTextField scheduleDaysField;
    private JTextField startTimeField;
    private JTextField endTimeField;
    private JTextField roomNumberField;
    private JButton saveButton;
    private JButton cancelButton;
    

    private Integer assignmentId;
    private boolean isEditMode;
    
    /**
     * Constructor - Demonstrates Encapsulation and Polymorphism
     * @param parent Parent ManageAssignmentsForm window
     * @param assignmentId Assignment ID for edit mode (null for add mode)
     */
    public AssignmentDialog(ManageAssignmentsForm parent, Integer assignmentId) {
        super(parent, assignmentId == null ? "Add Assignment" : "Edit Assignment", true);
    
        this.assignmentId = assignmentId;
        this.isEditMode = assignmentId != null;
        
        initComponents();
        setupEventHandlers();
        loadData();
        
        if (isEditMode) {
            loadAssignmentData();
        }
        
        setSize(500, 600);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    /**
     * Initialize UI components - Demonstrates Encapsulation
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 33, 0));
        headerPanel.setPreferredSize(new Dimension(500, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel(isEditMode ? "Edit Assignment" : "Add Assignment");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Teacher Selection
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Teacher *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        teacherCombo = new JComboBox<>();
        formPanel.add(teacherCombo, gbc);
        
        // Subject Selection
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Subject *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        subjectCombo = new JComboBox<>();
        formPanel.add(subjectCombo, gbc);
        
        // Section
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Section *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        sectionField = new JTextField(20);
        formPanel.add(sectionField, gbc);
        
        // Grade Level
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Grade Level *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gradeLevelField = new JTextField(20);
        formPanel.add(gradeLevelField, gbc);
        
        // Academic Year
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Academic Year *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        academicYearField = new JTextField(20);
        formPanel.add(academicYearField, gbc);
        
        // Semester
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Semester *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        semesterCombo = new JComboBox<>(new String[]{"1st Semester", "2nd Semester"});
        semesterCombo.setSelectedIndex(0);
        formPanel.add(semesterCombo, gbc);
        
        // Schedule Days
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Schedule Days *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        scheduleDaysField = new JTextField(20);
        formPanel.add(scheduleDaysField, gbc);
        
        // Start Time
        gbc.gridx = 0; gbc.gridy = 7; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Start Time *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        startTimeField = new JTextField(20);
        formPanel.add(startTimeField, gbc);
        
        // End Time
        gbc.gridx = 0; gbc.gridy = 8; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("End Time *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        endTimeField = new JTextField(20);
        formPanel.add(endTimeField, gbc);
        
        // Room Number
        gbc.gridx = 0; gbc.gridy = 9; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Room Number *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        roomNumberField = new JTextField(20);
        formPanel.add(roomNumberField, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        saveButton = new JButton(isEditMode ? "Update Assignment" : "Save Assignment");
        saveButton.setBackground(new Color(33, 33, 0));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        saveButton.setPreferredSize(new Dimension(120, 35));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(80, 80, 80));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    
    /**
     * Setup event handlers - Demonstrates Event-Driven Programming
     */
    private void setupEventHandlers() {
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveButtonActionPerformed(e);
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonActionPerformed(e);
            }
        });
    }
    
    /**
     * Load teachers and subjects data - Demonstrates Database Operations
     */
    private void loadData() {
        loadTeachers();
        loadSubjects();
        
        // Set default academic year
        if (academicYearField.getText().trim().isEmpty()) {
            academicYearField.setText("2024-2025");
        }
    }
    
    /**
     * Load teachers into combo box - Demonstrates Database Operations
     */
    private void loadTeachers() {
        teacherCombo.removeAllItems();
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT t.teacher_id, t.first_name, t.last_name " +
                          "FROM teachers t " +
                          "WHERE t.is_active = 1 " +
                          "ORDER BY t.last_name, t.first_name";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String teacherName = rs.getString("first_name") + " " + rs.getString("last_name");
                teacherCombo.addItem(teacherName);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading teachers: " + e.getMessage());
        }
    }
    
    /**
     * Load subjects into combo box - Demonstrates Database Operations
     */
    private void loadSubjects() {
        subjectCombo.removeAllItems();
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT subject_name FROM subjects WHERE is_active = 1 ORDER BY subject_name";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                subjectCombo.addItem(rs.getString("subject_name"));
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading subjects: " + e.getMessage());
        }
    }
    
    /**
     * Load assignment data for editing - Demonstrates Database Operations
     */
    private void loadAssignmentData() {
        if (!isEditMode) return;
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            String query = "SELECT ta.teacher_id, s.subject_name, ta.section, ta.grade_level, " +
                          "ta.academic_year, ta.semester, ta.schedule_days, ta.start_time, " +
                          "ta.end_time, ta.room_number " +
                          "FROM teacher_assignments ta " +
                          "JOIN subjects s ON ta.subject_id = s.subject_id " +
                          "WHERE ta.assignment_id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, assignmentId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Set teacher (find by teacher_id)
                int teacherId = rs.getInt("teacher_id");
                String teacherQuery = "SELECT CONCAT(first_name, ' ', last_name) as teacher_name " +
                                     "FROM teachers WHERE teacher_id = ?";
                PreparedStatement teacherStmt = conn.prepareStatement(teacherQuery);
                teacherStmt.setInt(1, teacherId);
                ResultSet teacherRs = teacherStmt.executeQuery();
                
                if (teacherRs.next()) {
                    String teacherName = teacherRs.getString("teacher_name");
                    for (int i = 0; i < teacherCombo.getItemCount(); i++) {
                        if (teacherCombo.getItemAt(i).equals(teacherName)) {
                            teacherCombo.setSelectedIndex(i);
                            break;
                        }
                    }
                }
                teacherRs.close();
                teacherStmt.close();
                
                // Set subject
                String subjectName = rs.getString("subject_name");
                for (int i = 0; i < subjectCombo.getItemCount(); i++) {
                    if (subjectCombo.getItemAt(i).equals(subjectName)) {
                        subjectCombo.setSelectedIndex(i);
                        break;
                    }
                }
                
                // Set other fields
                sectionField.setText(rs.getString("section"));
                gradeLevelField.setText(rs.getString("grade_level"));
                academicYearField.setText(rs.getString("academic_year"));
                
                String semester = rs.getString("semester");
                for (int i = 0; i < semesterCombo.getItemCount(); i++) {
                    if (semesterCombo.getItemAt(i).equals(semester)) {
                        semesterCombo.setSelectedIndex(i);
                        break;
                    }
                }
                
                scheduleDaysField.setText(rs.getString("schedule_days"));
                
                // Set times
                if (rs.getString("start_time") != null) {
                    startTimeField.setText(rs.getString("start_time").substring(0, 5));
                }
                if (rs.getString("end_time") != null) {
                    endTimeField.setText(rs.getString("end_time").substring(0, 5));
                }
                
                roomNumberField.setText(rs.getString("room_number"));
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading assignment data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading assignment data: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Handle Save button click - Demonstrates Data Validation and Database Operations
     */
    private void saveButtonActionPerformed(ActionEvent evt) {
        // Validate input fields
        if (!validateInput()) {
            return;
        }
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            
            if (isEditMode) {
                updateAssignment(conn);
            } else {
                addAssignment(conn);
            }
            
            JOptionPane.showMessageDialog(this, 
                isEditMode ? "Assignment updated successfully!" : "Assignment added successfully!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            dispose();
            
        } catch (SQLException e) {
            System.err.println("❌ Error saving assignment: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error saving assignment: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Add new assignment - Demonstrates Database Operations
     */
    private void addAssignment(Connection conn) throws SQLException {
        // Get teacher_id and subject_id
        int teacherId = getTeacherId((String) teacherCombo.getSelectedItem());
        int subjectId = getSubjectId((String) subjectCombo.getSelectedItem());
        
        String query = "INSERT INTO teacher_assignments (teacher_id, subject_id, section, grade_level, " +
                      "academic_year, semester, schedule_days, start_time, end_time, room_number, is_active) " +
                      "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, teacherId);
        stmt.setInt(2, subjectId);
        stmt.setString(3, sectionField.getText().trim());
        stmt.setString(4, gradeLevelField.getText().trim());
        stmt.setString(5, academicYearField.getText().trim());
        stmt.setString(6, (String) semesterCombo.getSelectedItem());
        stmt.setString(7, scheduleDaysField.getText().trim());
        stmt.setString(8, startTimeField.getText().trim() + ":00");
        stmt.setString(9, endTimeField.getText().trim() + ":00");
        stmt.setString(10, roomNumberField.getText().trim());
        
        stmt.executeUpdate();
        stmt.close();
    }
    
    /**
     * Update existing assignment - Demonstrates Database Operations
     */
    private void updateAssignment(Connection conn) throws SQLException {
        // Get teacher_id and subject_id
        int teacherId = getTeacherId((String) teacherCombo.getSelectedItem());
        int subjectId = getSubjectId((String) subjectCombo.getSelectedItem());
        
        String query = "UPDATE teacher_assignments SET teacher_id = ?, subject_id = ?, section = ?, " +
                      "grade_level = ?, academic_year = ?, semester = ?, schedule_days = ?, " +
                      "start_time = ?, end_time = ?, room_number = ? WHERE assignment_id = ?";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, teacherId);
        stmt.setInt(2, subjectId);
        stmt.setString(3, sectionField.getText().trim());
        stmt.setString(4, gradeLevelField.getText().trim());
        stmt.setString(5, academicYearField.getText().trim());
        stmt.setString(6, (String) semesterCombo.getSelectedItem());
        stmt.setString(7, scheduleDaysField.getText().trim());
        stmt.setString(8, startTimeField.getText().trim() + ":00");
        stmt.setString(9, endTimeField.getText().trim() + ":00");
        stmt.setString(10, roomNumberField.getText().trim());
        stmt.setInt(11, assignmentId);
        
        stmt.executeUpdate();
        stmt.close();
    }
    
    /**
     * Get teacher ID by name - Demonstrates Database Operations
     */
    private int getTeacherId(String teacherName) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT teacher_id FROM teachers WHERE CONCAT(first_name, ' ', last_name) = ? AND is_active = 1";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, teacherName);
        ResultSet rs = stmt.executeQuery();
        
        int teacherId = 0;
        if (rs.next()) {
            teacherId = rs.getInt("teacher_id");
        }
        
        rs.close();
        stmt.close();
        conn.close();
        
        return teacherId;
    }
    
    /**
     * Get subject ID by name - Demonstrates Database Operations
     */
    private int getSubjectId(String subjectName) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT subject_id FROM subjects WHERE subject_name = ? AND is_active = 1";
        
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, subjectName);
        ResultSet rs = stmt.executeQuery();
        
        int subjectId = 0;
        if (rs.next()) {
            subjectId = rs.getInt("subject_id");
        }
        
        rs.close();
        stmt.close();
        conn.close();
        
        return subjectId;
    }
    
    /**
     * Validate input fields - Demonstrates Input Validation
     */
    private boolean validateInput() {
        if (teacherCombo.getSelectedItem() == null) {
            showValidationError("Please select a teacher");
            teacherCombo.requestFocus();
            return false;
        }
        
        if (subjectCombo.getSelectedItem() == null) {
            showValidationError("Please select a subject");
            subjectCombo.requestFocus();
            return false;
        }
        
        if (sectionField.getText().trim().isEmpty()) {
            showValidationError("Section is required");
            sectionField.requestFocus();
            return false;
        }
        
        if (gradeLevelField.getText().trim().isEmpty()) {
            showValidationError("Grade Level is required");
            gradeLevelField.requestFocus();
            return false;
        }
        
        if (academicYearField.getText().trim().isEmpty()) {
            showValidationError("Academic Year is required");
            academicYearField.requestFocus();
            return false;
        }
        
        return true;
    }
    
    /**
     * Show validation error message - Demonstrates Error Handling
     */
    private void showValidationError(String message) {
        JOptionPane.showMessageDialog(this, 
            message, 
            "Validation Error", 
            JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Handle Cancel button click - Demonstrates Event Handling
     */
    private void cancelButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
}
