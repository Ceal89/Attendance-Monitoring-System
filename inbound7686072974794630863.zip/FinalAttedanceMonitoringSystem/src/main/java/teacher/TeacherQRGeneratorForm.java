package teacher;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

// ZXing imports for QR code generation
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * Teacher QR Code Generator Form
 * Demonstrates QR Code generation and real-time attendance tracking
 */
public class TeacherQRGeneratorForm extends JDialog {
    
    // UI Components
    private JPanel headerPanel;
    private JPanel contentPanel;
    private JPanel buttonPanel;
    
    // QR Code components
    private JLabel qrCodeLabel;
    private JTextArea qrDataTextArea;
    private JLabel sessionInfoLabel;
    
    // Class selection components
    private JComboBox<String> sectionComboBox;
    private JComboBox<String> subjectComboBox;
    private JButton generateQRButton;
    private JButton startSessionButton;
    private JButton stopSessionButton;
    private JButton closeButton;
    
    // Attendance tracking table
    private JTable attendanceTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    
    // Data structures
    private List<StudentAttendance> studentAttendanceList;
    private int teacherId;
    private String teacherFullName;
    private String currentSection;
    private int currentSubjectId;
    private String currentSessionId;
    private Timer refreshTimer;
    private boolean sessionActive;
    
    /**
     * Constructor
     * @param parent Parent frame
     * @param teacherId Teacher ID
     * @param teacherFullName Teacher full name
     */
    public TeacherQRGeneratorForm(Frame parent, int teacherId, String teacherFullName) {
        super(parent, "QR Code Attendance Generator", true);
        this.teacherId = teacherId;
        this.teacherFullName = teacherFullName;
        this.studentAttendanceList = new ArrayList<>();
        this.sessionActive = false;
        
        initComponents();
        setupEventHandlers();
        loadTeacherSections();
        
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    /**
     * Initialize UI components
     * Demonstrates UI Component initialization
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setSize(1200, 800);
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 53, 69));
        headerPanel.setPreferredSize(new Dimension(0, 60));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("QR Code Attendance Generator");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Content Panel
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Top Panel - Class Selection and QR Code
        JPanel topPanel = new JPanel(new BorderLayout());
        
        // Class Selection Panel
        JPanel classSelectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        classSelectionPanel.setBorder(BorderFactory.createTitledBorder("Select Class"));
        
        classSelectionPanel.add(new JLabel("Section:"));
        sectionComboBox = new JComboBox<>();
        sectionComboBox.setPreferredSize(new Dimension(200, 30));
        classSelectionPanel.add(sectionComboBox);
        
        classSelectionPanel.add(new JLabel("Subject:"));
        subjectComboBox = new JComboBox<>();
        subjectComboBox.setPreferredSize(new Dimension(200, 30));
        classSelectionPanel.add(subjectComboBox);
        
        generateQRButton = new JButton("Generate QR Code");
        generateQRButton.setBackground(new Color(0, 128, 0));
        generateQRButton.setForeground(Color.WHITE);
        generateQRButton.setPreferredSize(new Dimension(150, 30));
        classSelectionPanel.add(generateQRButton);
        
        topPanel.add(classSelectionPanel, BorderLayout.NORTH);
        
        // QR Code Panel
        JPanel qrPanel = new JPanel(new BorderLayout());
        qrPanel.setBorder(BorderFactory.createTitledBorder("QR Code"));
        qrPanel.setPreferredSize(new Dimension(300, 400));
        
        // QR Code Display
        qrCodeLabel = new JLabel();
        qrCodeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        qrCodeLabel.setVerticalAlignment(SwingConstants.CENTER);
        qrCodeLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        qrCodeLabel.setPreferredSize(new Dimension(250, 250));
        qrCodeLabel.setText("Generate QR Code First");
        qrPanel.add(qrCodeLabel, BorderLayout.CENTER);
        
        // QR Data Display
        qrDataTextArea = new JTextArea(6, 25);
        qrDataTextArea.setEditable(false);
        qrDataTextArea.setFont(new Font("Monospaced", Font.PLAIN, 10));
        qrDataTextArea.setText("QR Code data will appear here...");
        qrPanel.add(new JScrollPane(qrDataTextArea), BorderLayout.SOUTH);
        
        topPanel.add(qrPanel, BorderLayout.CENTER);
        
        // Session Control Panel
        JPanel sessionPanel = new JPanel(new FlowLayout());
        sessionPanel.setBorder(BorderFactory.createTitledBorder("Session Control"));
        
        sessionInfoLabel = new JLabel("No active session");
        sessionInfoLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sessionPanel.add(sessionInfoLabel);
        
        startSessionButton = new JButton("Start Attendance Session");
        startSessionButton.setBackground(new Color(0, 128, 0));
        startSessionButton.setForeground(Color.WHITE);
        startSessionButton.setEnabled(false);
        sessionPanel.add(startSessionButton);
        
        stopSessionButton = new JButton("Stop Session");
        stopSessionButton.setBackground(new Color(220, 53, 69));
        stopSessionButton.setForeground(Color.WHITE);
        stopSessionButton.setEnabled(false);
        sessionPanel.add(stopSessionButton);
        
        topPanel.add(sessionPanel, BorderLayout.SOUTH);
        
        contentPanel.add(topPanel, BorderLayout.NORTH);
        
        // Attendance Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Real-time Attendance Tracking"));
        
        String[] columnNames = {"Student #", "Student Name", "Status", "Time In", "Method"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Read-only table
            }
        };
        
        attendanceTable = new JTable(tableModel);
        attendanceTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        attendanceTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        attendanceTable.getColumnModel().getColumn(0).setPreferredWidth(100); // Student #
        attendanceTable.getColumnModel().getColumn(1).setPreferredWidth(200); // Student Name
        attendanceTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Status
        attendanceTable.getColumnModel().getColumn(3).setPreferredWidth(120); // Time In
        attendanceTable.getColumnModel().getColumn(4).setPreferredWidth(100); // Method
        
        scrollPane = new JScrollPane(attendanceTable);
        scrollPane.setPreferredSize(new Dimension(0, 250));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        
        add(contentPanel, BorderLayout.CENTER);
        
        // Button Panel
        buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        closeButton = new JButton("Close");
        closeButton.setPreferredSize(new Dimension(100, 35));
        buttonPanel.add(closeButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers
     * Demonstrates Event Handling
     */
    private void setupEventHandlers() {
        sectionComboBox.addActionListener(e -> sectionSelectionChanged());
        subjectComboBox.addActionListener(e -> subjectSelectionChanged());
        generateQRButton.addActionListener(e -> generateQRButtonActionPerformed(e));
        startSessionButton.addActionListener(e -> startSessionButtonActionPerformed(e));
        stopSessionButton.addActionListener(e -> stopSessionButtonActionPerformed(e));
        closeButton.addActionListener(e -> dispose());
    }
    
    /**
     * Load teacher's assigned sections
     * Demonstrates Data Structure: List usage
     */
    private void loadTeacherSections() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT DISTINCT ta.section as section_name, ta.grade_level " +
                              "FROM teacher_assignments ta " +
                              "WHERE ta.teacher_id = ? AND ta.is_active = 1 " +
                              "ORDER BY ta.section";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                ResultSet rs = stmt.executeQuery();
                
                sectionComboBox.removeAllItems();
                sectionComboBox.addItem("Select Section");
                
                while (rs.next()) {
                    String sectionName = rs.getString("section_name") + " - Grade " + rs.getString("grade_level");
                    sectionComboBox.addItem(sectionName);
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Loaded teacher sections for QR generator");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading teacher sections: " + e.getMessage());
        }
    }
    
    /**
     * Handle section selection change
     */
    private void sectionSelectionChanged() {
        String selectedSection = (String) sectionComboBox.getSelectedItem();
        if (selectedSection != null && !selectedSection.equals("Select Section")) {
            // Extract section name from formatted text
            currentSection = selectedSection.split(" - ")[0];
            loadSectionSubjects();
        }
    }
    
    /**
     * Load subjects for selected section
     */
    private void loadSectionSubjects() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT ta.subject_id, s.subject_name " +
                              "FROM teacher_assignments ta " +
                              "JOIN subjects s ON ta.subject_id = s.subject_id " +
                              "WHERE ta.teacher_id = ? AND ta.section = ? AND ta.is_active = 1 " +
                              "ORDER BY s.subject_name";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                stmt.setString(2, currentSection);
                ResultSet rs = stmt.executeQuery();
                
                subjectComboBox.removeAllItems();
                subjectComboBox.addItem("Select Subject");
                
                while (rs.next()) {
                    subjectComboBox.addItem(rs.getString("subject_name") + "|" + rs.getInt("subject_id"));
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Loaded subjects for QR generator");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading section subjects: " + e.getMessage());
        }
    }
    
    /**
     * Handle subject selection change
     */
    private void subjectSelectionChanged() {
        String selectedSubject = (String) subjectComboBox.getSelectedItem();
        if (selectedSubject != null && !selectedSubject.equals("Select Subject")) {
            String[] parts = selectedSubject.split("\\|");
            if (parts.length == 2) {
                currentSubjectId = Integer.parseInt(parts[1]);
                generateQRButton.setEnabled(true);
                loadStudents();
            }
        }
    }
    
    /**
     * Load students for the selected section
     */
    private void loadStudents() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT s.student_id, s.student_number, " +
                              "CONCAT(s.first_name, ' ', COALESCE(s.middle_name, ''), ' ', s.last_name) as full_name " +
                              "FROM students s " +
                              "WHERE s.section = ? AND s.is_active = 1 " +
                              "ORDER BY s.last_name, s.first_name";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, currentSection);
                ResultSet rs = stmt.executeQuery();
                
                studentAttendanceList.clear();
                tableModel.setRowCount(0);
                
                while (rs.next()) {
                    StudentAttendance student = new StudentAttendance(
                        rs.getInt("student_id"),
                        rs.getString("student_number"),
                        rs.getString("full_name").replace("  ", " ").trim(),
                        "Absent", // Default status
                        "Not Checked In", // Default time
                        "QR Code" // Default method
                    );
                    
                    studentAttendanceList.add(student);
                    
                    // Add to table model
                    Object[] rowData = {
                        student.getStudentNumber(),
                        student.getStudentName(),
                        student.getStatus(),
                        student.getTimeIn(),
                        student.getAttendanceMethod()
                    };
                    tableModel.addRow(rowData);
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Loaded " + studentAttendanceList.size() + " students for QR attendance");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading students: " + e.getMessage());
        }
    }
    
    /**
     * Generate QR Code button action
     */
    private void generateQRButtonActionPerformed(ActionEvent evt) {
        if (currentSection == null || currentSubjectId <= 0) {
            JOptionPane.showMessageDialog(this, "Please select both section and subject first.",
                                        "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Generate unique session ID
        currentSessionId = UUID.randomUUID().toString();
        
        // Create QR code data
        String qrData = createQRCodeData();
        qrDataTextArea.setText(qrData);
        
        // Generate QR code image (placeholder)
        generateQRCodeImage(qrData);
        
        startSessionButton.setEnabled(true);
        
        JOptionPane.showMessageDialog(this, 
            "QR Code generated successfully!\nClick 'Start Attendance Session' to begin.",
            "QR Code Ready", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Create QR code data string
     */
    private String createQRCodeData() {
        String currentDate = LocalDate.now().toString();
        String currentTime = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        
        StringBuilder qrData = new StringBuilder();
        qrData.append("ATTENDANCE_QR\n");
        qrData.append("SESSION_ID:").append(currentSessionId).append("\n");
        qrData.append("TEACHER_ID:").append(teacherId).append("\n");
        qrData.append("SUBJECT_ID:").append(currentSubjectId).append("\n");
        qrData.append("SECTION:").append(currentSection).append("\n");
        qrData.append("DATE:").append(currentDate).append("\n");
        qrData.append("TIME:").append(currentTime).append("\n");
        qrData.append("TEACHER:").append(teacherFullName).append("\n");
        qrData.append("QR_TYPE:STUDENT_ATTENDANCE");
        
        return qrData.toString();
    }
    
    /**
     * Generate QR code image using ZXing library
     */
    private void generateQRCodeImage(String qrData) {
        try {
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            
            // Set QR code hints
            java.util.Map<EncodeHintType, Object> hints = new java.util.HashMap<>();
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.MARGIN, 1);
            
            // Generate QR code matrix
            BitMatrix bitMatrix = qrCodeWriter.encode(qrData, BarcodeFormat.QR_CODE, 250, 250, hints);
            
            // Convert BitMatrix to BufferedImage
            BufferedImage qrImage = new BufferedImage(250, 250, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = qrImage.createGraphics();
            
            // Fill with white background
            g2d.setColor(Color.WHITE);
            g2d.fillRect(0, 0, 250, 250);
            
            // Draw QR code pattern
            g2d.setColor(Color.BLACK);
            for (int x = 0; x < 250; x++) {
                for (int y = 0; y < 250; y++) {
                    if (bitMatrix.get(x, y)) {
                        g2d.fillRect(x, y, 1, 1);
                    }
                }
            }
            
            g2d.dispose();
            
            qrCodeLabel.setIcon(new ImageIcon(qrImage));
            qrCodeLabel.setText("");
            
            System.out.println("✅ QR code generated successfully");
            
        } catch (WriterException e) {
            System.err.println("❌ Error generating QR code: " + e.getMessage());
            
            // Fallback to placeholder image
            createPlaceholderQRImage();
        }
    }
    
    /**
     * Create placeholder QR code image as fallback
     */
    private void createPlaceholderQRImage() {
        BufferedImage qrImage = new BufferedImage(250, 250, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = qrImage.createGraphics();
        
        // Fill with white background
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, 250, 250);
        
        // Draw simple pattern
        g2d.setColor(Color.BLACK);
        for (int i = 0; i < 250; i += 10) {
            for (int j = 0; j < 250; j += 10) {
                if ((i + j) % 20 < 10) {
                    g2d.fillRect(i, j, 8, 8);
                }
            }
        }
        
        // Add text overlay
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        g2d.drawString("QR Code", 90, 130);
        g2d.setFont(new Font("Arial", Font.PLAIN, 10));
        g2d.drawString("Scan to Mark", 85, 150);
        g2d.drawString("Attendance", 85, 165);
        
        g2d.dispose();
        
        qrCodeLabel.setIcon(new ImageIcon(qrImage));
        qrCodeLabel.setText("");
    }
    
    /**
     * Start attendance session
     */
    private void startSessionButtonActionPerformed(ActionEvent evt) {
        if (currentSessionId == null) {
            JOptionPane.showMessageDialog(this, "Please generate QR code first.",
                                        "QR Code Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        sessionActive = true;
        startSessionButton.setEnabled(false);
        stopSessionButton.setEnabled(true);
        
        // Update session info
        String sessionInfo = String.format("Active Session - %s | %s | %s", 
                                          currentSection, 
                                          getCurrentSubjectName(),
                                          LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
        sessionInfoLabel.setText(sessionInfo);
        sessionInfoLabel.setForeground(new Color(0, 128, 0));
        
        // Start refresh timer for real-time updates
        startRefreshTimer();
        
        JOptionPane.showMessageDialog(this, 
            "Attendance session started!\nStudents can now scan the QR code to mark attendance.",
            "Session Started", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Stop attendance session
     */
    private void stopSessionButtonActionPerformed(ActionEvent evt) {
        sessionActive = false;
        startSessionButton.setEnabled(true);
        stopSessionButton.setEnabled(false);
        
        // Stop refresh timer
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
        
        // Update session info
        sessionInfoLabel.setText("Session Stopped");
        sessionInfoLabel.setForeground(Color.RED);
        
        // Save final attendance to database
        saveAttendanceToDatabase();
        
        JOptionPane.showMessageDialog(this, 
            "Attendance session stopped and saved to database.",
            "Session Stopped", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Start refresh timer for real-time updates
     */
    private void startRefreshTimer() {
        refreshTimer = new Timer(2000, new ActionListener() { // Refresh every 2 seconds
            @Override
            public void actionPerformed(ActionEvent e) {
                if (sessionActive) {
                    refreshAttendanceData();
                }
            }
        });
        refreshTimer.start();
    }
    
    /**
     * Refresh attendance data from database
     */
    private void refreshAttendanceData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT ar.student_id, ar.status, ar.time_in " +
                              "FROM attendance_records ar " +
                              "WHERE ar.subject_id = ? AND ar.attendance_date = CURDATE() " +
                              "AND ar.recorded_by = ?";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, currentSubjectId);
                stmt.setInt(2, teacherId);
                ResultSet rs = stmt.executeQuery();
                
                // Update attendance list and table
                while (rs.next()) {
                    int studentId = rs.getInt("student_id");
                    String status = rs.getString("status");
                    String timeIn = rs.getTime("time_in").toString();
                    
                    // Find and update student in list
                    for (int i = 0; i < studentAttendanceList.size(); i++) {
                        StudentAttendance student = studentAttendanceList.get(i);
                        if (student.getStudentId() == studentId) {
                            student.setStatus(status);
                            student.setTimeIn(timeIn);
                            student.setAttendanceMethod("QR Code");
                            
                            // Update table
                            tableModel.setValueAt(status, i, 2);
                            tableModel.setValueAt(timeIn, i, 3);
                            tableModel.setValueAt("QR Code", i, 4);
                            break;
                        }
                    }
                }
                
                rs.close();
                stmt.close();
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error refreshing attendance data: " + e.getMessage());
        }
    }
    
    /**
     * Save attendance to database
     */
    private void saveAttendanceToDatabase() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                conn.setAutoCommit(false);
                
                String query = "INSERT INTO attendance_records " +
                              "(student_id, subject_id, attendance_date, time_in, status, recorded_by) " +
                              "VALUES (?, ?, CURDATE(), CURTIME(), ?, ?) " +
                              "ON DUPLICATE KEY UPDATE " +
                              "time_in = VALUES(time_in), status = VALUES(status)";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                
                for (StudentAttendance student : studentAttendanceList) {
                    if (!"Absent".equals(student.getStatus())) {
                        stmt.setInt(1, student.getStudentId());
                        stmt.setInt(2, currentSubjectId);
                        stmt.setString(3, student.getStatus());
                        stmt.setInt(4, teacherId);
                        stmt.addBatch();
                    }
                }
                
                stmt.executeBatch();
                conn.commit();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Attendance saved to database");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error saving attendance: " + e.getMessage());
        }
    }
    
    /**
     * Get current subject name
     */
    private String getCurrentSubjectName() {
        String selectedSubject = (String) subjectComboBox.getSelectedItem();
        if (selectedSubject != null && selectedSubject.contains("|")) {
            return selectedSubject.split("\\|")[0];
        }
        return "Unknown Subject";
    }
    
    /**
     * Student Attendance data class
     * Demonstrates Encapsulation
     */
    public static class StudentAttendance {
        private int studentId;
        private String studentNumber;
        private String studentName;
        private String status;
        private String timeIn;
        private String attendanceMethod;
        
        public StudentAttendance(int studentId, String studentNumber, String studentName, 
                               String status, String timeIn, String attendanceMethod) {
            this.studentId = studentId;
            this.studentNumber = studentNumber;
            this.studentName = studentName;
            this.status = status;
            this.timeIn = timeIn;
            this.attendanceMethod = attendanceMethod;
        }
        
        // Getters and Setters
        public int getStudentId() { return studentId; }
        public String getStudentNumber() { return studentNumber; }
        public String getStudentName() { return studentName; }
        public String getStatus() { return status; }
        public String getTimeIn() { return timeIn; }
        public String getAttendanceMethod() { return attendanceMethod; }
        
        public void setStatus(String status) { this.status = status; }
        public void setTimeIn(String timeIn) { this.timeIn = timeIn; }
        public void setAttendanceMethod(String attendanceMethod) { this.attendanceMethod = attendanceMethod; }
    }
}
