package admin;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Add Subject Dialog
 * Allows admin to add new subjects to the system
 */
public class AddSubjectDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // Form fields
    private JTextField subjectCodeField;
    private JTextField subjectNameField;
    private JTextArea descriptionArea;
    private JComboBox<String> strandCombo;
    private JComboBox<String> gradeLevelCombo;
    private JTextField unitsField;
    
    // Buttons
    private JButton addButton;
    private JButton cancelButton;
    
    // Panels
    private JPanel headerPanel;
    private JPanel formPanel;
    private JPanel buttonPanel;
    

    
    public AddSubjectDialog(AdminDashboard parent) {
        super(parent, "Add New Subject", true);
    
        
        initComponents();
        setupEventHandlers();
        
        setSize(500, 500);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Add New Subject");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Main form panel
        formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Subject Code
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Subject Code:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        subjectCodeField = new JTextField(20);
        formPanel.add(subjectCodeField, gbc);
        
        // Subject Name
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Subject Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        subjectNameField = new JTextField(20);
        formPanel.add(subjectNameField, gbc);
        
        // Description
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 1.0; gbc.weighty = 1.0;
        descriptionArea = new JTextArea(3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descriptionScroll = new JScrollPane(descriptionArea);
        formPanel.add(descriptionScroll, gbc);
        
        // Strand
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0; gbc.weighty = 0;
        formPanel.add(new JLabel("Strand:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        strandCombo = new JComboBox<>(new String[]{"STEM", "HUMSS", "ABM", "TVL", "General"});
        formPanel.add(strandCombo, gbc);
        
        // Grade Level
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Grade Level:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gradeLevelCombo = new JComboBox<>(new String[]{"Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"});
        formPanel.add(gradeLevelCombo, gbc);
        
        // Units
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Units:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        unitsField = new JTextField(20);
        unitsField.setText("1.0");
        formPanel.add(unitsField, gbc);
        
        add(formPanel, BorderLayout.CENTER);
        
        // Button panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        addButton = new JButton("Add Subject");
        addButton.setBackground(new Color(0, 128, 0));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setPreferredSize(new Dimension(120, 35));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(128, 128, 128));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(addButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addButtonActionPerformed(e);
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonActionPerformed(e);
            }
        });
    }
    
    private void addButtonActionPerformed(ActionEvent evt) {
        // Validate input
        if (subjectCodeField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a subject code.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            subjectCodeField.requestFocus();
            return;
        }
        
        if (subjectNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a subject name.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            subjectNameField.requestFocus();
            return;
        }
        
        // Validate units
        double units;
        try {
            units = Double.parseDouble(unitsField.getText().trim());
            if (units <= 0) {
                JOptionPane.showMessageDialog(this, "Units must be a positive number.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                unitsField.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for units.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            unitsField.requestFocus();
            return;
        }
        
        // Add subject to database
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Check if subject code already exists
                String checkQuery = "SELECT COUNT(*) FROM subjects WHERE subject_code = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                checkStmt.setString(1, subjectCodeField.getText().trim());
                ResultSet rs = checkStmt.executeQuery();
                
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Subject code already exists. Please use a different code.", "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                    subjectCodeField.requestFocus();
                    checkStmt.close();
                    conn.close();
                    return;
                }
                checkStmt.close();
                
                // Insert new subject
                String insertQuery = "INSERT INTO subjects (subject_code, subject_name, description, strand, grade_level, units, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)";
                PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                insertStmt.setString(1, subjectCodeField.getText().trim());
                insertStmt.setString(2, subjectNameField.getText().trim());
                insertStmt.setString(3, descriptionArea.getText().trim());
                insertStmt.setString(4, (String) strandCombo.getSelectedItem());
                insertStmt.setString(5, (String) gradeLevelCombo.getSelectedItem());
                insertStmt.setDouble(6, units);
                
                int rowsAffected = insertStmt.executeUpdate();
                insertStmt.close();
                conn.close();
                
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Subject added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add subject. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            System.err.println("Error adding subject: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void cancelButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
}
