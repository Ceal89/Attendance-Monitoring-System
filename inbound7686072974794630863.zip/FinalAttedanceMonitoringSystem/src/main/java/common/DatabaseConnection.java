package common;import java.sql.*;
import javax.swing.JOptionPane;
import java.util.Properties;

/**
 * Enhanced Database Connection Manager for Attendance Monitoring System
 * Handles MySQL connections with proper error handling and connection pooling
 */
public class DatabaseConnection {
    private static Connection connection = null;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/attendance_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    
    // Connection properties for better performance
    private static final Properties connectionProps = new Properties();
    
    static {
        // Initialize connection properties
        connectionProps.setProperty("useSSL", "false");
        connectionProps.setProperty("serverTimezone", "UTC");
        connectionProps.setProperty("autoReconnect", "true");
        connectionProps.setProperty("characterEncoding", "UTF-8");
        connectionProps.setProperty("useUnicode", "true");
        connectionProps.setProperty("maxReconnects", "3");
        connectionProps.setProperty("initialTimeout", "2");
    }
    
    /**
     * Get database connection with enhanced error handling
     * @return Connection object or null if failed
     */
    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Load MySQL driver
                Class.forName(DRIVER);
                
                // Create connection with properties
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                
                // Set connection properties
                connection.setAutoCommit(true);
                
                System.out.println("✅ Database connected successfully!");
            }
            return connection;
            
        } catch (ClassNotFoundException e) {
            System.err.println("❌ MySQL Driver not found: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Database driver not found. Please ensure MySQL Connector/J is installed.", 
                "Database Error", JOptionPane.ERROR_MESSAGE);
            return null;
            
        } catch (SQLException e) {
            System.err.println("❌ Database connection failed: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Failed to connect to database: " + e.getMessage(), 
                "Database Connection Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    /**
     * Get database connection with custom parameters
     * @param url Database URL
     * @param user Database username
     * @param password Database password
     * @return Connection object or null if failed
     */
    public static Connection getConnection(String url, String user, String password) {
        try {
            if (connection == null || connection.isClosed()) {
                Class.forName(DRIVER);
                connection = DriverManager.getConnection(url, user, password);
                connection.setAutoCommit(true);
                System.out.println("✅ Database connected successfully!");
            }
            return connection;
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("❌ Database connection failed: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Close database connection
     */
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("✅ Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error closing database connection: " + e.getMessage());
        }
    }
    
    /**
     * Test database connection
     * @return true if connection is successful, false otherwise
     */
    public static boolean testConnection() {
        try (Connection testConn = getConnection()) {
            if (testConn != null) {
                try (Statement stmt = testConn.createStatement()) {
                    ResultSet rs = stmt.executeQuery("SELECT 1");
                    rs.close();
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("❌ Connection test failed: " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Execute SELECT query and return ResultSet
     * @param query SQL SELECT query
     * @return ResultSet or null if failed
     */
    public static ResultSet executeQuery(String query) {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                Statement stmt = conn.createStatement();
                return stmt.executeQuery(query);
            }
        } catch (SQLException e) {
            System.err.println("❌ Query execution failed: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Database query failed: " + e.getMessage(), 
                "Query Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    
    /**
     * Execute UPDATE/INSERT/DELETE query
     * @param query SQL query
     * @return number of affected rows, -1 if failed
     */
    public static int executeUpdate(String query) {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                int result;
                try (Statement stmt = conn.createStatement()) {
                    result = stmt.executeUpdate(query);
                }
                return result;
            }
        } catch (SQLException e) {
            System.err.println("❌ Update execution failed: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Database update failed: " + e.getMessage(), 
                "Update Error", JOptionPane.ERROR_MESSAGE);
        }
        return -1;
    }
    
    /**
     * Get prepared statement for parameterized queries
     * @param query SQL query with placeholders
     * @return PreparedStatement or null if failed
     */
    public static PreparedStatement getPreparedStatement(String query) {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                return conn.prepareStatement(query);
            }
        } catch (SQLException e) {
            System.err.println("❌ Prepared statement creation failed: " + e.getMessage());
        }
        return null;
    }
    
    /**
     * Check if database tables exist
     * @return true if all required tables exist, false otherwise
     */
    public static boolean checkTablesExist() {
        String[] requiredTables = {
            "users", "students", "teachers", "subjects", "sections", 
            "teacher_assignments", "attendance_records", "daily_attendance_summary",
            "monthly_attendance_reports", "system_settings", "audit_logs"
        };
        
        try {
            Connection conn = getConnection();
            if (conn != null) {
                DatabaseMetaData metaData = conn.getMetaData();
                
                for (String tableName : requiredTables) {
                    ResultSet tables = metaData.getTables(null, null, tableName, new String[]{"TABLE"});
                    if (!tables.next()) {
                        System.err.println("❌ Table '" + tableName + "' not found!");
                        return false;
                    }
                    tables.close();
                }
                System.out.println("✅ All required tables exist!");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error checking tables: " + e.getMessage());
        }
        return false;
    }
    
    /**
     * Initialize database with sample data if tables are empty
     */
    public static void initializeDatabase() {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                int studentCount;
                try ( // Check if students table is empty
                        Statement stmt = conn.createStatement()) {
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM students");
                    rs.next();
                    studentCount = rs.getInt(1);
                    rs.close();
                }
                
                if (studentCount == 0) {
                    System.out.println("📝 Database appears to be empty. Please run sample_data.sql to populate with test data.");
                    JOptionPane.showMessageDialog(null, 
                        "Database is empty. Please run the sample_data.sql file to populate with test data.", 
                        "Database Initialization", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    System.out.println("✅ Database contains " + studentCount + " students. Ready to use!");
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error initializing database: " + e.getMessage());
        }
    }
    
    /**
     * Get database information
     * @return String with database info
     */
    public static String getDatabaseInfo() {
        try {
            Connection conn = getConnection();
            if (conn != null) {
                DatabaseMetaData metaData = conn.getMetaData();
                return String.format(
                    "Database: %s\nDriver: %s %s\nURL: %s\nUser: %s",
                    metaData.getDatabaseProductName(),
                    metaData.getDriverName(),
                    metaData.getDriverVersion(),
                    metaData.getURL(),
                    metaData.getUserName()
                );
            }
        } catch (SQLException e) {
            System.err.println("❌ Error getting database info: " + e.getMessage());
        }
        return "Database information unavailable";
    }
}
