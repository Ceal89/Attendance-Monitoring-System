package teacher;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Teacher Assigned Sections Form
 * Demonstrates OOP concepts: Encapsulation, Data Structures
 */
public class TeacherAssignedSectionsForm extends JFrame {
    
    // Encapsulation: Private fields
    private int teacherId;
    private String teacherFullName;
    private DefaultTableModel tableModel;
    private JTable sectionsTable;
    private List<AssignedSection> assignedSections; // Data Structure: List for assigned sections
    private String[] columnNames; // Data Structure: Array for column names
    
    // UI Components
    private JButton closeButton;
    private JButton refreshButton;
    private JButton viewStudentsButton;
    private JLabel totalSectionsLabel;
    private JLabel totalStudentsLabel;
    
    /**
     * Inner class to represent assigned section - Demonstrates Encapsulation
     */
    public static class AssignedSection {
        private int assignmentId;
        private String subjectName;
        private String sectionName;
        private String strand;
        private String gradeLevel;
        private String academicYear;
        private String semester;
        private String scheduleDays;
        private String startTime;
        private String endTime;
        private String roomNumber;
        private int studentCount;
        
        // Constructor
        public AssignedSection(int assignmentId, String subjectName, String sectionName, 
                             String strand, String gradeLevel, String academicYear, 
                             String semester, String scheduleDays, String startTime, 
                             String endTime, String roomNumber, int studentCount) {
            this.assignmentId = assignmentId;
            this.subjectName = subjectName;
            this.sectionName = sectionName;
            this.strand = strand;
            this.gradeLevel = gradeLevel;
            this.academicYear = academicYear;
            this.semester = semester;
            this.scheduleDays = scheduleDays;
            this.startTime = startTime;
            this.endTime = endTime;
            this.roomNumber = roomNumber;
            this.studentCount = studentCount;
        }
        
        // Getter methods (Encapsulation)
        public int getAssignmentId() { return assignmentId; }
        public String getSubjectName() { return subjectName; }
        public String getSectionName() { return sectionName; }
        public String getStrand() { return strand; }
        public String getGradeLevel() { return gradeLevel; }
        public String getAcademicYear() { return academicYear; }
        public String getSemester() { return semester; }
        public String getScheduleDays() { return scheduleDays; }
        public String getStartTime() { return startTime; }
        public String getEndTime() { return endTime; }
        public String getRoomNumber() { return roomNumber; }
        public int getStudentCount() { return studentCount; }
        
        // Setter methods (Encapsulation)
        public void setAssignmentId(int assignmentId) { this.assignmentId = assignmentId; }
        public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
        public void setSectionName(String sectionName) { this.sectionName = sectionName; }
        public void setStrand(String strand) { this.strand = strand; }
        public void setGradeLevel(String gradeLevel) { this.gradeLevel = gradeLevel; }
        public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }
        public void setSemester(String semester) { this.semester = semester; }
        public void setScheduleDays(String scheduleDays) { this.scheduleDays = scheduleDays; }
        public void setStartTime(String startTime) { this.startTime = startTime; }
        public void setEndTime(String endTime) { this.endTime = endTime; }
        public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
        public void setStudentCount(int studentCount) { this.studentCount = studentCount; }
        
        public String getFullSectionName() {
            return sectionName + " - " + strand + " " + gradeLevel;
        }
        
        public String getScheduleInfo() {
            return scheduleDays + " " + startTime + "-" + endTime;
        }
        
        @Override
        public String toString() {
            return String.format("AssignedSection{id=%d, subject='%s', section='%s'}", 
                               assignmentId, subjectName, getFullSectionName());
        }
    }
    
    /**
     * Constructor
     * @param teacherId Teacher ID
     * @param teacherFullName Teacher full name
     */
    public TeacherAssignedSectionsForm(int teacherId, String teacherFullName) {
        this.teacherId = teacherId;
        this.teacherFullName = teacherFullName;
        this.assignedSections = new ArrayList<>(); // Data Structure initialization
        this.columnNames = new String[]{"Subject", "Section", "Strand", "Grade", "Schedule", "Room", "Students", "Semester"}; // Data Structure: Array
        
        initComponents();
        setupEventHandlers();
        loadAssignedSections();
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Assigned Sections - " + teacherFullName);
        setResizable(true);
        setSize(1200, 700);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 33, 0));
        headerPanel.setPreferredSize(new Dimension(1200, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("My Assigned Sections");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.setBackground(Color.WHITE);
        
        // Stats panel
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 10));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        statsPanel.setBackground(Color.WHITE);
        
        totalSectionsLabel = new JLabel("Total Sections: 0");
        totalSectionsLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        totalSectionsLabel.setForeground(new Color(33, 33, 0));
        
        totalStudentsLabel = new JLabel("Total Students: 0");
        totalStudentsLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        totalStudentsLabel.setForeground(new Color(33, 33, 0));
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(0, 0, 128));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(100, 30));
        
        viewStudentsButton = new JButton("View Students");
        viewStudentsButton.setBackground(new Color(33, 33, 0));
        viewStudentsButton.setForeground(Color.WHITE);
        viewStudentsButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewStudentsButton.setPreferredSize(new Dimension(120, 30));
        
        statsPanel.add(totalSectionsLabel);
        statsPanel.add(totalStudentsLabel);
        statsPanel.add(refreshButton);
        statsPanel.add(viewStudentsButton);
        
        // Table panel
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        tablePanel.setBackground(Color.WHITE);
        
        // Initialize table model
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        sectionsTable = new JTable(tableModel);
        sectionsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sectionsTable.setRowHeight(25);
        sectionsTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        sectionsTable.getColumnModel().getColumn(0).setPreferredWidth(150);  // Subject
        sectionsTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // Section
        sectionsTable.getColumnModel().getColumn(2).setPreferredWidth(80);   // Strand
        sectionsTable.getColumnModel().getColumn(3).setPreferredWidth(80);   // Grade
        sectionsTable.getColumnModel().getColumn(4).setPreferredWidth(150);  // Schedule
        sectionsTable.getColumnModel().getColumn(5).setPreferredWidth(80);   // Room
        sectionsTable.getColumnModel().getColumn(6).setPreferredWidth(80);   // Students
        sectionsTable.getColumnModel().getColumn(7).setPreferredWidth(100);  // Semester
        
        JScrollPane scrollPane = new JScrollPane(sectionsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        closeButton = new JButton("Close");
        closeButton.setBackground(new Color(158, 158, 158));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        closeButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(closeButton);
        
        // Add panels to content panel
        contentPanel.add(statsPanel, BorderLayout.NORTH);
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Add panels to main frame
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    
    
    /**
     * Setup event handlers
     */
    private void setupEventHandlers() {
        closeButton.addActionListener(e -> closeButtonActionPerformed(e));
        refreshButton.addActionListener(e -> refreshButtonActionPerformed(e));
        viewStudentsButton.addActionListener(e -> viewStudentsButtonActionPerformed(e));
    }
    
    /**
     * Load assigned sections from database
     * Demonstrates Data Structure usage with Lists and Arrays
     */
    private void loadAssignedSections() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT ta.assignment_id, s.subject_name, ta.section as section_name, " +
                              "s.strand, ta.grade_level, ta.academic_year, ta.semester, " +
                              "ta.schedule_days, ta.start_time, ta.end_time, ta.room_number, " +
                              "COUNT(st.student_id) as student_count " +
                              "FROM teacher_assignments ta " +
                              "JOIN subjects s ON ta.subject_id = s.subject_id " +
                              "LEFT JOIN students st ON ta.section = st.section AND st.grade_level = ta.grade_level AND st.is_active = 1 " +
                              "WHERE ta.teacher_id = ? AND ta.is_active = 1 " +
                              "GROUP BY ta.assignment_id, s.subject_name, ta.section, " +
                              "s.strand, ta.grade_level, ta.academic_year, ta.semester, " +
                              "ta.schedule_days, ta.start_time, ta.end_time, ta.room_number " +
                              "ORDER BY s.subject_name, ta.section";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                System.out.println("🔍 Loading assigned sections for teacher ID: " + teacherId);
                System.out.println("🔍 Query: " + query);
                ResultSet rs = stmt.executeQuery();
                
                // Clear existing data
                assignedSections.clear();
                tableModel.setRowCount(0);
                
                // Load data into List and Table
                int count = 0;
                while (rs.next()) {
                    count++;
                    System.out.println("🔍 Found section: " + rs.getString("subject_name") + " - " + rs.getString("section_name"));
                    AssignedSection section = new AssignedSection(
                        rs.getInt("assignment_id"),
                        rs.getString("subject_name"),
                        rs.getString("section_name"),
                        rs.getString("strand"),
                        rs.getString("grade_level"),
                        rs.getString("academic_year"),
                        rs.getString("semester"),
                        rs.getString("schedule_days"),
                        rs.getTime("start_time") != null ? rs.getTime("start_time").toString() : "",
                        rs.getTime("end_time") != null ? rs.getTime("end_time").toString() : "",
                        rs.getString("room_number"),
                        rs.getInt("student_count")
                    );
                    
                    assignedSections.add(section); // Add to List (Data Structure)
                    
                    // Add to table model
                    Object[] rowData = {
                        section.getSubjectName(),
                        section.getFullSectionName(),
                        section.getStrand(),
                        section.getGradeLevel(),
                        section.getScheduleInfo(),
                        section.getRoomNumber(),
                        section.getStudentCount(),
                        section.getSemester()
                    };
                    tableModel.addRow(rowData);
                }
                
                rs.close();
                stmt.close();
                
                // Update statistics
                updateStatistics();
                
                System.out.println("✅ Loaded " + count + " assigned sections");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading assigned sections: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading assigned sections: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Update statistics display
     * Demonstrates Data Structure usage
     */
    private void updateStatistics() {
        int totalSections = assignedSections.size();
        int totalStudents = 0;
        
        // Calculate total students (Data Structure manipulation)
        for (AssignedSection section : assignedSections) {
            totalStudents += section.getStudentCount();
        }
        
        totalSectionsLabel.setText("Total Sections: " + totalSections);
        totalStudentsLabel.setText("Total Students: " + totalStudents);
    }
    
    /**
     * Get selected assigned section
     * @return AssignedSection object or null if no selection
     */
    private AssignedSection getSelectedSection() {
        int selectedRow = sectionsTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < assignedSections.size()) {
            return assignedSections.get(selectedRow); // Access List by index
        }
        return null;
    }
    
    // Event Handlers
    private void closeButtonActionPerformed(ActionEvent evt) {
        this.dispose();
    }
    
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadAssignedSections();
        JOptionPane.showMessageDialog(this, "Assigned sections refreshed!", 
                                    "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void viewStudentsButtonActionPerformed(ActionEvent evt) {
        AssignedSection selectedSection = getSelectedSection();
        if (selectedSection != null) {
            // Open students view for selected section
            JOptionPane.showMessageDialog(this, 
                "Would show students for " + selectedSection.getFullSectionName() + 
                " (" + selectedSection.getStudentCount() + " students)",
                "View Students", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a section first.",
                                        "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    // Getter methods (Encapsulation)
    public int getTeacherId() {
        return teacherId;
    }
    
    public String getTeacherFullName() {
        return teacherFullName;
    }
    
    public List<AssignedSection> getAssignedSections() {
        return new ArrayList<>(assignedSections); // Return copy to maintain encapsulation
    }
    
    // Setter methods (Encapsulation)
    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }
    
    public void setTeacherFullName(String teacherFullName) {
        this.teacherFullName = teacherFullName;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TeacherAssignedSectionsForm form = new TeacherAssignedSectionsForm(1, "Jane Smith");
            form.setVisible(true);
        });
    }
}
