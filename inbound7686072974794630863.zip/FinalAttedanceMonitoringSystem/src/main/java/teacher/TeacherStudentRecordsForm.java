package teacher;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Teacher Student Records Form
 * Demonstrates CRUD operations and data management
 */
public class TeacherStudentRecordsForm extends JDialog {
    
    // UI Components
    private JPanel headerPanel;
    private JPanel contentPanel;
    private JPanel buttonPanel;
    
    // Table components
    private JTable studentTable;
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    
    // Filter components
    private JComboBox<String> sectionComboBox;
    private JComboBox<String> subjectComboBox;
    private JButton refreshButton;
    private JButton closeButton;
    
    // Data structures
    private List<StudentRecord> studentRecords;
    private int teacherId;
    
    /**
     * Constructor
     * @param parent Parent frame
     * @param teacherId Teacher ID
     */
    public TeacherStudentRecordsForm(Frame parent, int teacherId) {
        super(parent, "Student Records", true);
        this.teacherId = teacherId;
        this.studentRecords = new ArrayList<>();
        
        initComponents();
        setupEventHandlers();
        loadTeacherSections();
        
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    /**
     * Initialize UI components
     * Demonstrates UI Component initialization
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        setSize(1000, 600);
        
        // Header Panel
        headerPanel = new JPanel();
        headerPanel.setBackground(new Color(220, 53, 69));
        headerPanel.setPreferredSize(new Dimension(0, 60));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("Student Records Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Content Panel
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Filter Students"));
        
        filterPanel.add(new JLabel("Section:"));
        sectionComboBox = new JComboBox<>();
        sectionComboBox.setPreferredSize(new Dimension(200, 30));
        filterPanel.add(sectionComboBox);
        
        filterPanel.add(new JLabel("Subject:"));
        subjectComboBox = new JComboBox<>();
        subjectComboBox.setPreferredSize(new Dimension(200, 30));
        filterPanel.add(subjectComboBox);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setPreferredSize(new Dimension(100, 30));
        filterPanel.add(refreshButton);
        
        contentPanel.add(filterPanel, BorderLayout.NORTH);
        
        // Table Panel
        String[] columnNames = {"Student #", "Full Name", "Grade Level", "Section", "Subject", "Attendance Rate", "Last Seen"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Read-only table
            }
        };
        
        studentTable = new JTable(tableModel);
        studentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        studentTable.getColumnModel().getColumn(0).setPreferredWidth(100); // Student #
        studentTable.getColumnModel().getColumn(1).setPreferredWidth(200); // Full Name
        studentTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Grade Level
        studentTable.getColumnModel().getColumn(3).setPreferredWidth(100); // Section
        studentTable.getColumnModel().getColumn(4).setPreferredWidth(150); // Subject
        studentTable.getColumnModel().getColumn(5).setPreferredWidth(120); // Attendance Rate
        studentTable.getColumnModel().getColumn(6).setPreferredWidth(120); // Last Seen
        
        scrollPane = new JScrollPane(studentTable);
        scrollPane.setPreferredSize(new Dimension(0, 300));
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(contentPanel, BorderLayout.CENTER);
        
        // Button Panel
        buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        closeButton = new JButton("Close");
        closeButton.setPreferredSize(new Dimension(100, 35));
        buttonPanel.add(closeButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers
     * Demonstrates Event Handling
     */
    private void setupEventHandlers() {
        sectionComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadSectionSubjects();
            }
        });
        
        subjectComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadStudentRecords();
            }
        });
        
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadStudentRecords();
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
    
    /**
     * Load teacher's assigned sections
     * Demonstrates Data Structure: List usage
     */
    private void loadTeacherSections() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT DISTINCT ta.section as section_name, ta.grade_level " +
                              "FROM teacher_assignments ta " +
                              "WHERE ta.teacher_id = ? AND ta.is_active = 1 " +
                              "ORDER BY ta.section";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                System.out.println("🔍 Loading teacher sections for student records, teacher ID: " + teacherId);
                ResultSet rs = stmt.executeQuery();
                
                sectionComboBox.removeAllItems();
                sectionComboBox.addItem("Select Section");
                
                while (rs.next()) {
                    String sectionName = rs.getString("section_name") + " - Grade " + rs.getString("grade_level");
                    sectionComboBox.addItem(sectionName);
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Loaded teacher sections for student records");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading teacher sections: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading sections: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Load subjects for selected section
     * Demonstrates Data Structure: List usage
     */
    private void loadSectionSubjects() {
        String selectedSection = (String) sectionComboBox.getSelectedItem();
        if (selectedSection == null || selectedSection.equals("Select Section")) {
            subjectComboBox.removeAllItems();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Extract section name from "Section - Grade X" format
                String sectionName = selectedSection.split(" - Grade ")[0];
                
                String query = "SELECT s.subject_name " +
                              "FROM teacher_assignments ta " +
                              "JOIN subjects s ON ta.subject_id = s.subject_id " +
                              "WHERE ta.teacher_id = ? AND ta.section = ? AND ta.is_active = 1 " +
                              "ORDER BY s.subject_name";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                stmt.setString(2, sectionName);
                ResultSet rs = stmt.executeQuery();
                
                subjectComboBox.removeAllItems();
                subjectComboBox.addItem("Select Subject");
                
                while (rs.next()) {
                    subjectComboBox.addItem(rs.getString("subject_name"));
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Loaded subjects for section: " + sectionName);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading section subjects: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading subjects: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Load student records with attendance data
     * Demonstrates Complex Data Structure usage
     */
    private void loadStudentRecords() {
        String selectedSection = (String) sectionComboBox.getSelectedItem();
        String selectedSubject = (String) subjectComboBox.getSelectedItem();
        
        if (selectedSection == null || selectedSection.equals("Select Section") ||
            selectedSubject == null || selectedSubject.equals("Select Subject")) {
            JOptionPane.showMessageDialog(this, "Please select both section and subject.",
                "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Extract section name from "Section - Grade X" format
                String sectionName = selectedSection.split(" - Grade ")[0];
                
                String query = "SELECT st.student_id, st.student_number, " +
                              "CONCAT(st.first_name, ' ', st.last_name) as full_name, " +
                              "st.grade_level, st.section, s.subject_name, " +
                              "COUNT(ar.attendance_id) as total_records, " +
                              "SUM(CASE WHEN ar.status = 'Present' THEN 1 ELSE 0 END) as present_count, " +
                              "MAX(ar.attendance_date) as last_attendance " +
                              "FROM students st " +
                              "JOIN teacher_assignments ta ON st.section = ta.section AND st.grade_level = ta.grade_level " +
                              "JOIN subjects s ON ta.subject_id = s.subject_id " +
                              "LEFT JOIN attendance_records ar ON st.student_id = ar.student_id AND s.subject_id = ar.subject_id " +
                              "WHERE ta.teacher_id = ? AND ta.section = ? AND s.subject_name = ? AND st.is_active = 1 " +
                              "GROUP BY st.student_id, st.student_number, st.first_name, st.last_name, " +
                              "st.grade_level, st.section, s.subject_name " +
                              "ORDER BY st.last_name, st.first_name";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                stmt.setString(2, sectionName);
                stmt.setString(3, selectedSubject);
                System.out.println("🔍 Loading student records for section: " + sectionName + ", subject: " + selectedSubject);
                ResultSet rs = stmt.executeQuery();
                
                // Clear existing data
                studentRecords.clear();
                tableModel.setRowCount(0);
                
                // Load data into List and Table
                int count = 0;
                while (rs.next()) {
                    count++;
                    int totalRecords = rs.getInt("total_records");
                    int presentCount = rs.getInt("present_count");
                    double attendanceRate = totalRecords > 0 ? (double) presentCount / totalRecords * 100 : 0;
                    
                    StudentRecord record = new StudentRecord(
                        rs.getInt("student_id"),
                        rs.getString("student_number"),
                        rs.getString("full_name"),
                        rs.getString("grade_level"),
                        rs.getString("section"),
                        rs.getString("subject_name"),
                        attendanceRate,
                        rs.getDate("last_attendance")
                    );
                    
                    studentRecords.add(record); // Add to List (Data Structure)
                    
                    // Add to table model
                    Object[] rowData = {
                        record.getStudentNumber(),
                        record.getFullName(),
                        record.getGradeLevel(),
                        record.getSection(),
                        record.getSubjectName(),
                        String.format("%.1f%%", record.getAttendanceRate()),
                        record.getLastAttendance() != null ? record.getLastAttendance().toString() : "Never"
                    };
                    tableModel.addRow(rowData);
                }
                
                rs.close();
                stmt.close();
                conn.close();
                
                System.out.println("✅ Loaded " + count + " student records");
                
                if (count == 0) {
                    JOptionPane.showMessageDialog(this, "No students found for the selected section and subject.",
                        "No Data", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading student records: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading student records: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Student Record data class
     * Demonstrates Encapsulation
     */
    public class StudentRecord {
        private int studentId;
        private String studentNumber;
        private String fullName;
        private String gradeLevel;
        private String section;
        private String subjectName;
        private double attendanceRate;
        private java.sql.Date lastAttendance;
        
        public StudentRecord(int studentId, String studentNumber, String fullName, 
                           String gradeLevel, String section, String subjectName, 
                           double attendanceRate, java.sql.Date lastAttendance) {
            this.studentId = studentId;
            this.studentNumber = studentNumber;
            this.fullName = fullName;
            this.gradeLevel = gradeLevel;
            this.section = section;
            this.subjectName = subjectName;
            this.attendanceRate = attendanceRate;
            this.lastAttendance = lastAttendance;
        }
        
        // Getters
        public int getStudentId() { return studentId; }
        public String getStudentNumber() { return studentNumber; }
        public String getFullName() { return fullName; }
        public String getGradeLevel() { return gradeLevel; }
        public String getSection() { return section; }
        public String getSubjectName() { return subjectName; }
        public double getAttendanceRate() { return attendanceRate; }
        public java.sql.Date getLastAttendance() { return lastAttendance; }
    }
}
