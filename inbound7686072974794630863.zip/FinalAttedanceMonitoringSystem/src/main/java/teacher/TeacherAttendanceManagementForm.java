package teacher;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Teacher Attendance Management Form
 * Demonstrates OOP concepts: Encapsulation, Data Structures
 */
public class TeacherAttendanceManagementForm extends JFrame {
    
    // Encapsulation: Private fields
    private int teacherId;
    private String teacherFullName;
    private DefaultTableModel tableModel;
    private JTable studentsTable;
    private List<StudentAttendance> studentAttendanceList; // Data Structure: List for student attendance
    private String[] columnNames; // Data Structure: Array for column names
    private String currentSection;
    private int currentSubjectId;
    
    // UI Components
    private JButton refreshButton;
    private JButton markAllPresentButton;
    private JButton markAllAbsentButton;
    private JButton saveAttendanceButton;
    private JButton viewQRAttendanceButton;
    private JButton generateQRButton;
    private JComboBox<String> sectionComboBox;
    private JComboBox<String> subjectComboBox;
    private JLabel dateLabel;
    private JLabel classInfoLabel;
    
    /**
     * Inner class to represent student attendance - Demonstrates Encapsulation
     */
    public static class StudentAttendance {
        private int studentId;
        private String studentNumber;
        private String studentName;
        private String status;
        private String attendanceMethod; // "Manual" or "QR Code"
        private boolean isModified;
        
        // Constructor
        public StudentAttendance(int studentId, String studentNumber, String studentName, String status, String attendanceMethod) {
            this.studentId = studentId;
            this.studentNumber = studentNumber;
            this.studentName = studentName;
            this.status = status;
            this.attendanceMethod = attendanceMethod;
            this.isModified = false;
        }
        
        // Getter methods (Encapsulation)
        public int getStudentId() { return studentId; }
        public String getStudentNumber() { return studentNumber; }
        public String getStudentName() { return studentName; }
        public String getStatus() { return status; }
        public String getAttendanceMethod() { return attendanceMethod; }
        public boolean isModified() { return isModified; }
        
        // Setter methods (Encapsulation)
        public void setStudentId(int studentId) { this.studentId = studentId; }
        public void setStudentNumber(String studentNumber) { this.studentNumber = studentNumber; }
        public void setStudentName(String studentName) { this.studentName = studentName; }
        public void setStatus(String status) { 
            this.status = status; 
            this.isModified = true;
        }
        public void setAttendanceMethod(String attendanceMethod) { 
            this.attendanceMethod = attendanceMethod; 
            this.isModified = true;
        }
        public void setModified(boolean modified) { this.isModified = modified; }
        
        @Override
        public String toString() {
            return String.format("StudentAttendance{id=%d, name='%s', status='%s'}", 
                               studentId, studentName, status);
        }
    }
    
    /**
     * Constructor
     * @param teacherId Teacher ID
     * @param teacherFullName Teacher full name
     */
    public TeacherAttendanceManagementForm(int teacherId, String teacherFullName) {
        this.teacherId = teacherId;
        this.teacherFullName = teacherFullName;
        this.studentAttendanceList = new ArrayList<>(); // Data Structure initialization
        this.columnNames = new String[]{"Student #", "Student Name", "Status", "Method"}; // Data Structure: Array
        this.currentSection = null;
        this.currentSubjectId = -1;
        
        initComponents();
        setupEventHandlers();
        loadTeacherSections();
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Attendance Management - " + teacherFullName);
        setResizable(true);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 33, 0));
        headerPanel.setPreferredSize(new Dimension(1000, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Attendance Management");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.setBackground(Color.WHITE);
        
        // Controls panel
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 15));
        controlsPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        controlsPanel.setBackground(Color.WHITE);
        
        JLabel dateLabelText = new JLabel("Date:");
        dateLabelText.setFont(new Font("Segoe UI", Font.BOLD, 12));
        dateLabel = new JLabel(java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        dateLabel.setForeground(new Color(33, 33, 0));
        
        JLabel sectionLabel = new JLabel("Section:");
        sectionLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        sectionComboBox = new JComboBox<>();
        sectionComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sectionComboBox.setPreferredSize(new Dimension(200, 25));
        
        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        subjectComboBox = new JComboBox<>();
        subjectComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subjectComboBox.setPreferredSize(new Dimension(200, 25));
        
        classInfoLabel = new JLabel("Select section and subject to load students");
        classInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        classInfoLabel.setForeground(new Color(100, 100, 100));
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(0, 0, 128));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(100, 30));
        
        controlsPanel.add(dateLabelText);
        controlsPanel.add(dateLabel);
        controlsPanel.add(sectionLabel);
        controlsPanel.add(sectionComboBox);
        controlsPanel.add(subjectLabel);
        controlsPanel.add(subjectComboBox);
        controlsPanel.add(classInfoLabel);
        controlsPanel.add(refreshButton);
        
        // Table panel
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        tablePanel.setBackground(Color.WHITE);
        
        // Initialize table model
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column >= 2; // Only Status and Remarks columns are editable
            }
        };
        
        studentsTable = new JTable(tableModel);
        studentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentsTable.setRowHeight(25);
        studentsTable.getTableHeader().setReorderingAllowed(false);
        
        JScrollPane scrollPane = new JScrollPane(studentsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Attendance panel
        JPanel attendancePanel = new JPanel();
        attendancePanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        attendancePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        attendancePanel.setBackground(Color.WHITE);
        
        markAllPresentButton = new JButton("Mark All Present");
        markAllPresentButton.setBackground(new Color(0, 128, 0));
        markAllPresentButton.setForeground(Color.WHITE);
        markAllPresentButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        markAllPresentButton.setPreferredSize(new Dimension(140, 35));
        
        markAllAbsentButton = new JButton("Mark All Absent");
        markAllAbsentButton.setBackground(new Color(0, 0, 128));
        markAllAbsentButton.setForeground(Color.WHITE);
        markAllAbsentButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        markAllAbsentButton.setPreferredSize(new Dimension(140, 35));
        
        saveAttendanceButton = new JButton("Save Attendance");
        saveAttendanceButton.setBackground(new Color(33, 33, 0));
        saveAttendanceButton.setForeground(Color.WHITE);
        saveAttendanceButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        saveAttendanceButton.setPreferredSize(new Dimension(120, 35));
        
        viewQRAttendanceButton = new JButton("View QR Attendance");
        viewQRAttendanceButton.setBackground(new Color(70, 130, 180));
        viewQRAttendanceButton.setForeground(Color.WHITE);
        viewQRAttendanceButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewQRAttendanceButton.setPreferredSize(new Dimension(150, 35));
        
        generateQRButton = new JButton("Generate QR Code");
        generateQRButton.setBackground(new Color(255, 140, 0));
        generateQRButton.setForeground(Color.WHITE);
        generateQRButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        generateQRButton.setPreferredSize(new Dimension(140, 35));
        
        attendancePanel.add(markAllPresentButton);
        attendancePanel.add(markAllAbsentButton);
        attendancePanel.add(saveAttendanceButton);
        attendancePanel.add(viewQRAttendanceButton);
        attendancePanel.add(generateQRButton);
        
        // Add panels to content panel
        contentPanel.add(controlsPanel, BorderLayout.NORTH);
        contentPanel.add(tablePanel, BorderLayout.CENTER);
        contentPanel.add(attendancePanel, BorderLayout.SOUTH);
        
        // Add panels to main frame
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    
    
    
    
    /**
     * Setup event handlers
     */
    private void setupEventHandlers() {
        refreshButton.addActionListener(e -> refreshButtonActionPerformed(e));
        markAllPresentButton.addActionListener(e -> markAllPresentButtonActionPerformed(e));
        markAllAbsentButton.addActionListener(e -> markAllAbsentButtonActionPerformed(e));
        saveAttendanceButton.addActionListener(e -> saveAttendanceButtonActionPerformed(e));
        viewQRAttendanceButton.addActionListener(e -> viewQRAttendanceButtonActionPerformed(e));
        generateQRButton.addActionListener(e -> generateQRButtonActionPerformed(e));
        
        // Section selection handler
        sectionComboBox.addActionListener(e -> sectionSelectionChanged());
        
        // Subject selection handler
        subjectComboBox.addActionListener(e -> subjectSelectionChanged());
    }
    
    /**
     * Load teacher's assigned sections
     * Demonstrates Data Structure usage
     */
    private void loadTeacherSections() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT DISTINCT ta.section as section_name, s.strand, ta.grade_level " +
                              "FROM teacher_assignments ta " +
                              "JOIN subjects s ON ta.subject_id = s.subject_id " +
                              "WHERE ta.teacher_id = ? AND ta.is_active = 1 " +
                              "ORDER BY ta.section";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                System.out.println("🔍 Loading teacher sections for teacher ID: " + teacherId);
                ResultSet rs = stmt.executeQuery();
                
                sectionComboBox.removeAllItems();
                sectionComboBox.addItem("Select Section");
                
                while (rs.next()) {
                    String sectionName = rs.getString("section_name") + " - " + 
                                       rs.getString("strand") + " " + rs.getString("grade_level");
                    sectionComboBox.addItem(sectionName);
                }
                
                rs.close();
                stmt.close();
                
                System.out.println("✅ Loaded teacher sections");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading teacher sections: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading sections: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Handle section selection change
     */
    private void sectionSelectionChanged() {
        String selectedSection = (String) sectionComboBox.getSelectedItem();
        if (selectedSection != null && !selectedSection.equals("Select Section")) {
            // Extract section name from formatted text like "Section A - General Grade 11"
            currentSection = selectedSection.split(" - ")[0];
            System.out.println("🔍 Section selected: " + selectedSection);
            System.out.println("🔍 Extracted section name: " + currentSection);
            loadSectionSubjects();
            updateClassInfo();
        }
    }
    
    /**
     * Load subjects for selected section
     */
    private void loadSectionSubjects() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String selectedSection = (String) sectionComboBox.getSelectedItem();
            if (selectedSection == null || selectedSection.equals("Select Section")) {
                subjectComboBox.removeAllItems();
                return;
            }
            
            // Extract section name from formatted text like "Section A - General Grade 11"
            String sectionName = selectedSection.split(" - ")[0];
            System.out.println("🔍 Loading subjects for section: " + sectionName);
            
            String query = "SELECT ta.subject_id, s.subject_name " +
                          "FROM teacher_assignments ta " +
                          "JOIN subjects s ON ta.subject_id = s.subject_id " +
                          "WHERE ta.teacher_id = ? AND ta.section = ? AND ta.is_active = 1 " +
                          "ORDER BY s.subject_name";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, teacherId);
            stmt.setString(2, sectionName);
            System.out.println("🔍 Query: " + query);
            System.out.println("🔍 Teacher ID: " + teacherId + ", Section: " + sectionName);
            ResultSet rs = stmt.executeQuery();
            
            subjectComboBox.removeAllItems();
            subjectComboBox.addItem("Select Subject");
            
            int count = 0;
            while (rs.next()) {
                count++;
                String subjectName = rs.getString("subject_name");
                int subjectId = rs.getInt("subject_id");
                System.out.println("🔍 Found subject: " + subjectName + " (ID: " + subjectId + ")");
                subjectComboBox.addItem(subjectName + "|" + subjectId);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
            System.out.println("✅ Loaded " + count + " subjects for section: " + sectionName);
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading section subjects: " + e.getMessage());
        }
    }
    
    /**
     * Handle subject selection change
     */
    private void subjectSelectionChanged() {
        String selectedSubject = (String) subjectComboBox.getSelectedItem();
        if (selectedSubject != null && !selectedSubject.equals("Select Subject")) {
            String[] parts = selectedSubject.split("\\|");
            if (parts.length == 2) {
                currentSubjectId = Integer.parseInt(parts[1]);
                loadSectionStudents();
                updateClassInfo();
            }
        }
    }
    
    /**
     * Load students for selected section
     * Demonstrates Data Structure usage
     */
    private void loadSectionStudents() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            System.out.println("🔍 Loading students for section: " + currentSection);
            System.out.println("🔍 Current subject ID: " + currentSubjectId);
            
            String query = "SELECT s.student_id, s.student_number, " +
                          "CONCAT(s.first_name, ' ', COALESCE(s.middle_name, ''), ' ', s.last_name) as full_name " +
                          "FROM students s " +
                          "WHERE s.section = ? AND s.is_active = 1 " +
                          "ORDER BY s.last_name, s.first_name";
            
            System.out.println("🔍 Query: " + query);
            System.out.println("🔍 Section parameter: " + currentSection);
            
            // First, let's check what sections exist in the students table
            String debugQuery = "SELECT DISTINCT section FROM students WHERE is_active = 1";
            PreparedStatement debugStmt = conn.prepareStatement(debugQuery);
            ResultSet debugRs = debugStmt.executeQuery();
            System.out.println("🔍 Available sections in students table:");
            while (debugRs.next()) {
                System.out.println("  - " + debugRs.getString("section"));
            }
            debugRs.close();
            debugStmt.close();
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, currentSection);
            ResultSet rs = stmt.executeQuery();
            
            // Clear existing data
            studentAttendanceList.clear();
            tableModel.setRowCount(0);
            
            // Load students into List and Table
            int count = 0;
            while (rs.next()) {
                count++;
                System.out.println("🔍 Found student: " + rs.getString("student_number") + " - " + rs.getString("full_name"));
                StudentAttendance student = new StudentAttendance(
                    rs.getInt("student_id"),
                    rs.getString("student_number"),
                    rs.getString("full_name").replace("  ", " ").trim(),
                    "Present", // Default status
                    "Manual" // Default attendance method
                );
                
                studentAttendanceList.add(student); // Add to List (Data Structure)
                
                // Add to table model
                Object[] rowData = {
                    student.getStudentNumber(),
                    student.getStudentName(),
                    student.getStatus(),
                    student.getAttendanceMethod()
                };
                tableModel.addRow(rowData);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
            System.out.println("✅ Loaded " + count + " students from database");
            System.out.println("✅ Added " + studentAttendanceList.size() + " students to list");
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading section students: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading students: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Update class information display
     */
    private void updateClassInfo() {
        String sectionName = "";
        String subjectName = "";
        
        if (currentSection != null) {
            sectionName = currentSection;
        }
        
        if (currentSubjectId > 0) {
            String selectedSubject = (String) subjectComboBox.getSelectedItem();
            if (selectedSubject != null && !selectedSubject.equals("Select Subject")) {
                subjectName = selectedSubject.split("\\|")[0];
            }
        }
        
        if (!sectionName.isEmpty() && !subjectName.isEmpty()) {
            classInfoLabel.setText(subjectName + " - " + sectionName + " (" + studentAttendanceList.size() + " students)");
        } else {
            classInfoLabel.setText("Select section and subject to load students");
        }
    }
    
    // Event Handlers
    
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadTeacherSections();
        
        // If section and subject are selected, reload students
        if (currentSection != null && currentSubjectId > 0) {
            loadSectionStudents();
            updateClassInfo();
        }
        
        JOptionPane.showMessageDialog(this, "Data refreshed successfully!", 
                                    "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void markAllPresentButtonActionPerformed(ActionEvent evt) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt("Present", i, 2);
            tableModel.setValueAt("Manual", i, 3); // Set attendance method to Manual
            if (i < studentAttendanceList.size()) {
                studentAttendanceList.get(i).setStatus("Present");
                studentAttendanceList.get(i).setAttendanceMethod("Manual");
            }
        }
    }
    
    private void markAllAbsentButtonActionPerformed(ActionEvent evt) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt("Absent", i, 2);
            tableModel.setValueAt("Manual", i, 3); // Set attendance method to Manual
            if (i < studentAttendanceList.size()) {
                studentAttendanceList.get(i).setStatus("Absent");
                studentAttendanceList.get(i).setAttendanceMethod("Manual");
            }
        }
    }
    
    private void saveAttendanceButtonActionPerformed(ActionEvent evt) {
        if (currentSection == null || currentSubjectId <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a section and subject first.",
                                        "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (studentAttendanceList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No students to save attendance for.",
                                        "No Students", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String currentDate = LocalDate.now().toString();
            String currentTime = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
            
            int savedCount = 0;
            
            for (StudentAttendance student : studentAttendanceList) { // Iterate through List (Data Structure)
                // Check if attendance already exists for today
                String checkQuery = "SELECT COUNT(*) FROM attendance_records " +
                                  "WHERE student_id = ? AND subject_id = ? AND attendance_date = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                checkStmt.setInt(1, student.getStudentId());
                checkStmt.setInt(2, currentSubjectId);
                checkStmt.setDate(3, Date.valueOf(currentDate));
                ResultSet checkRs = checkStmt.executeQuery();
                
                boolean exists = false;
                if (checkRs.next()) {
                    exists = checkRs.getInt(1) > 0;
                }
                checkRs.close();
                checkStmt.close();
                
                String query;
                PreparedStatement stmt;
                
                if (exists) {
                    // Update existing record
                    query = "UPDATE attendance_records SET status = ?, " +
                           "time_in = ?, recorded_by = ? " +
                           "WHERE student_id = ? AND subject_id = ? AND attendance_date = ?";
                    stmt = conn.prepareStatement(query);
                    stmt.setString(1, student.getStatus());
                    stmt.setTime(2, Time.valueOf(currentTime));
                    stmt.setInt(3, teacherId);
                    stmt.setInt(4, student.getStudentId());
                    stmt.setInt(5, currentSubjectId);
                    stmt.setDate(6, Date.valueOf(currentDate));
                } else {
                    // Insert new record
                    query = "INSERT INTO attendance_records (student_id, subject_id, attendance_date, " +
                           "time_in, status, recorded_by) VALUES (?, ?, ?, ?, ?, ?)";
                    stmt = conn.prepareStatement(query);
                    stmt.setInt(1, student.getStudentId());
                    stmt.setInt(2, currentSubjectId);
                    stmt.setDate(3, Date.valueOf(currentDate));
                    stmt.setTime(4, Time.valueOf(currentTime));
                    stmt.setString(5, student.getStatus());
                    stmt.setInt(6, teacherId);
                }
                
                int result = stmt.executeUpdate();
                if (result > 0) {
                    savedCount++;
                }
                stmt.close();
            }
            
            JOptionPane.showMessageDialog(this, 
                "Successfully saved attendance for " + savedCount + " students!",
                "Save Successful", JOptionPane.INFORMATION_MESSAGE);
            
            // Reset modified flags
            for (StudentAttendance student : studentAttendanceList) {
                student.setModified(false);
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error saving attendance: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error saving attendance: " + e.getMessage(),
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void viewQRAttendanceButtonActionPerformed(ActionEvent evt) {
        if (currentSection == null || currentSubjectId <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a section and subject first.",
                                        "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Show QR attendance information
        showQRAttendanceInfo();
    }
    
    private void generateQRButtonActionPerformed(ActionEvent evt) {
        if (currentSection == null || currentSubjectId <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a section and subject first.",
                                        "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Open QR Code Generator form
        SwingUtilities.invokeLater(() -> {
            try {
                TeacherQRGeneratorForm qrGeneratorForm = new TeacherQRGeneratorForm(this, teacherId, teacherFullName);
                qrGeneratorForm.setVisible(true);
            } catch (Exception e) {
                System.err.println("❌ Error opening QR generator form: " + e.getMessage());
                JOptionPane.showMessageDialog(this, "Error opening QR generator: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
    
    /**
     * Show QR attendance information dialog
     */
    private void showQRAttendanceInfo() {
        String message = "QR CODE ATTENDANCE SYSTEM\n\n" +
                        "HOW IT WORKS:\n" +
                        "1. Students scan their QR code to mark attendance\n" +
                        "2. System automatically records time-in and status\n" +
                        "3. Teachers can override manual attendance if needed\n\n" +
                        "MANUAL OVERRIDE:\n" +
                        "• Use 'Mark All Present' for manual attendance\n" +
                        "• Use 'Mark All Absent' for absent students\n" +
                        "• Individual status changes are allowed\n" +
                        "• Manual changes override QR attendance\n\n" +
                        "CURRENT SESSION:\n" +
                        "• Section: " + currentSection + "\n" +
                        "• Subject ID: " + currentSubjectId + "\n" +
                        "• Date: " + java.time.LocalDate.now() + "\n\n" +
                        "Note: QR attendance is automatically saved to database.";
        
        JOptionPane.showMessageDialog(this, message, 
            "QR Attendance Information", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Getter methods (Encapsulation)
    public int getTeacherId() {
        return teacherId;
    }
    
    public String getTeacherFullName() {
        return teacherFullName;
    }
    
    public List<StudentAttendance> getStudentAttendanceList() {
        return new ArrayList<>(studentAttendanceList); // Return copy to maintain encapsulation
    }
    
    // Setter methods (Encapsulation)
    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }
    
    public void setTeacherFullName(String teacherFullName) {
        this.teacherFullName = teacherFullName;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TeacherAttendanceManagementForm form = new TeacherAttendanceManagementForm(1, "Jane Smith");
            form.setVisible(true);
        });
    }
}
