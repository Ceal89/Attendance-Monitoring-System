package student;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.sql.*;

/**
 * Student QR Code Form - Generate and display student's QR code
 * Demonstrates OOP concepts: Encapsulation, Inheritance, and Data Structures
 */
public class StudentQRCodeForm extends JFrame {
    
    // Encapsulation: Private fields
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    private int studentId;
    private String studentNumber;
    private String studentFullName;
    private String qrCodeData;
    
    // UI Components
    private JLabel qrCodeLabel;
    private JLabel studentInfoLabel;
    private JLabel qrCodeDataLabel;
    private JButton generateButton;
    private JButton saveButton;
    private JButton closeButton;
    private JButton refreshButton;
    
    /**
     * Constructor
     * @param studentId Student ID
     * @param studentNumber Student number
     * @param studentFullName Student full name
     */
    public StudentQRCodeForm(int studentId, String studentNumber, String studentFullName) {
        this.studentId = studentId;
        this.studentNumber = studentNumber;
        this.studentFullName = studentFullName;
        
        initComponents();
        setupEventHandlers();
        loadQRCodeData();
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Student QR Code - " + studentFullName);
        setResizable(false);
        setSize(500, 600);
        setLocationRelativeTo(null);
        
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(500, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Student QR Code");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.setBackground(Color.WHITE);
        
        // Student info panel
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridBagLayout());
        infoPanel.setBackground(Color.WHITE);
        infoPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)), 
            "Student Information", 
            0, 0, 
            new Font("Segoe UI", Font.BOLD, 14)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Student info labels
        gbc.gridx = 0; gbc.gridy = 0;
        infoPanel.add(new JLabel("Student Number:"), gbc);
        gbc.gridx = 1;
        JLabel studentNumLabel = new JLabel(studentNumber);
        studentNumLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        infoPanel.add(studentNumLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        infoPanel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        studentInfoLabel = new JLabel(studentFullName);
        studentInfoLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        infoPanel.add(studentInfoLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        infoPanel.add(new JLabel("QR Code Data:"), gbc);
        gbc.gridx = 1;
        qrCodeDataLabel = new JLabel("Generating...");
        qrCodeDataLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        qrCodeDataLabel.setForeground(new Color(100, 100, 100));
        infoPanel.add(qrCodeDataLabel, gbc);
        
        // QR Code display panel
        JPanel qrPanel = new JPanel();
        qrPanel.setLayout(new BorderLayout());
        qrPanel.setBackground(Color.WHITE);
        qrPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)), 
            "QR Code", 
            0, 0, 
            new Font("Segoe UI", Font.BOLD, 14)
        ));
        
        qrCodeLabel = new JLabel();
        qrCodeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        qrCodeLabel.setVerticalAlignment(SwingConstants.CENTER);
        qrCodeLabel.setPreferredSize(new Dimension(300, 300));
        qrCodeLabel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        qrCodeLabel.setText("QR Code will appear here");
        qrCodeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        qrCodeLabel.setForeground(new Color(150, 150, 150));
        
        qrPanel.add(qrCodeLabel, BorderLayout.CENTER);
        
        // Instructions panel
        JPanel instructionsPanel = new JPanel();
        instructionsPanel.setLayout(new BorderLayout());
        instructionsPanel.setBackground(new Color(248, 248, 248));
        instructionsPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        
        JTextArea instructionsText = new JTextArea();
        instructionsText.setEditable(false);
        instructionsText.setBackground(new Color(248, 248, 248));
        instructionsText.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        instructionsText.setText(
            "Instructions:\n" +
            "• This QR code contains your student information\n" +
            "• Teachers can scan this code to mark your attendance\n" +
            "• Keep this code safe and do not share it with others\n" +
            "• If you lose access, contact your teacher immediately"
        );
        
        instructionsPanel.add(instructionsText, BorderLayout.CENTER);
        
        // Add panels to content panel
        contentPanel.add(infoPanel, BorderLayout.NORTH);
        contentPanel.add(qrPanel, BorderLayout.CENTER);
        contentPanel.add(instructionsPanel, BorderLayout.SOUTH);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(new Color(240, 240, 240));
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(0, 0, 128));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(100, 35));
        
        generateButton = new JButton("Generate QR");
        generateButton.setBackground(PRIMARY_COLOR);
        generateButton.setForeground(Color.WHITE);
        generateButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        generateButton.setPreferredSize(new Dimension(100, 35));
        
        saveButton = new JButton("Save QR");
        saveButton.setBackground(new Color(0, 128, 0));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        saveButton.setPreferredSize(new Dimension(100, 35));
        
        closeButton = new JButton("Close");
        closeButton.setBackground(new Color(80, 80, 80));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        closeButton.setPreferredSize(new Dimension(100, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(generateButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(closeButton);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    /**
     * Setup event handlers
     */
    private void setupEventHandlers() {
        refreshButton.addActionListener(e -> refreshButtonActionPerformed(e));
        generateButton.addActionListener(e -> generateButtonActionPerformed(e));
        saveButton.addActionListener(e -> saveButtonActionPerformed(e));
        closeButton.addActionListener(e -> closeButtonActionPerformed(e));
    }
    
    /**
     * Load QR code data from database
     */
    private void loadQRCodeData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Get student information for QR code
                String query = "SELECT student_number, grade_level, section FROM students WHERE student_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    String studentNum = rs.getString("student_number");
                    String gradeLevel = rs.getString("grade_level");
                    String section = rs.getString("section");
                    
                    // Create QR code data string
                    qrCodeData = String.format("STUDENT:%s:%s:%s:%s", 
                        studentNum, studentFullName, gradeLevel, section);
                    
                    qrCodeDataLabel.setText(qrCodeData);
                    
                    // Generate QR code immediately
                    generateQRCode();
                }
                
                rs.close();
                stmt.close();
                
                System.out.println("✅ QR code data loaded successfully");
            }
        } catch (Exception e) {
            System.err.println("❌ Error loading QR code data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading QR code data: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Generate QR code image (simplified version)
     */
    private void generateQRCode() {
        if (qrCodeData == null || qrCodeData.isEmpty()) {
            qrCodeLabel.setText("No QR data available");
            return;
        }
        
        try {
            // For this demo, we'll create a simple placeholder
            // In a real application, you would use a QR code library like ZXing
            
            // Create a simple pattern as placeholder
            BufferedImage qrImage = createPlaceholderQRCode(qrCodeData);
            
            if (qrImage != null) {
                ImageIcon icon = new ImageIcon(qrImage.getScaledInstance(250, 250, Image.SCALE_SMOOTH));
                qrCodeLabel.setIcon(icon);
                qrCodeLabel.setText("");
            } else {
                qrCodeLabel.setText("QR Code Generated\n(Placeholder)");
                qrCodeLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
                qrCodeLabel.setForeground(PRIMARY_COLOR);
            }
            
            System.out.println("✅ QR code generated successfully");
            
        } catch (Exception e) {
            System.err.println("❌ Error generating QR code: " + e.getMessage());
            qrCodeLabel.setText("Error generating QR code");
        }
    }
    
    /**
     * Create a placeholder QR code image (for demo purposes)
     * In a real application, use a proper QR code library
     */
    private BufferedImage createPlaceholderQRCode(String data) {
        int size = 250;
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        
        // Set background
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, size, size);
        
        // Create a simple pattern (not a real QR code)
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(2));
        
        // Draw a simple grid pattern
        for (int i = 0; i < size; i += 10) {
            for (int j = 0; j < size; j += 10) {
                if ((i + j) % 20 == 0) {
                    g2d.fillRect(i, j, 8, 8);
                }
            }
        }
        
        // Add corner markers (like real QR codes)
        g2d.fillRect(10, 10, 60, 60);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(25, 25, 30, 30);
        g2d.setColor(Color.BLACK);
        g2d.fillRect(35, 35, 10, 10);
        
        // Repeat for other corners
        g2d.fillRect(size - 70, 10, 60, 60);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(size - 55, 25, 30, 30);
        g2d.setColor(Color.BLACK);
        g2d.fillRect(size - 45, 35, 10, 10);
        
        g2d.fillRect(10, size - 70, 60, 60);
        g2d.setColor(Color.WHITE);
        g2d.fillRect(25, size - 55, 30, 30);
        g2d.setColor(Color.BLACK);
        g2d.fillRect(35, size - 45, 10, 10);
        
        g2d.dispose();
        return image;
    }
    
    // Event Handlers
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadQRCodeData();
        JOptionPane.showMessageDialog(this, "QR code data refreshed!", 
                                    "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void generateButtonActionPerformed(ActionEvent evt) {
        generateQRCode();
        JOptionPane.showMessageDialog(this, "QR code generated successfully!", 
                                    "Generate", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void saveButtonActionPerformed(ActionEvent evt) {
        JOptionPane.showMessageDialog(this, 
            "Save QR Code functionality would be implemented here.\n" +
            "This would allow students to save their QR code as an image file.",
            "Save QR Code", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void closeButtonActionPerformed(ActionEvent evt) {
        this.dispose();
    }
    
    /**
     * Get QR code data (for external access)
     * @return QR code data string
     */
    public String getQRCodeData() {
        return qrCodeData;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentQRCodeForm qrForm = new StudentQRCodeForm(1, "STU001", "John Doe");
            qrForm.setVisible(true);
        });
    }
}
