package student;

import common.DatabaseConnection;
import login.LoginForm;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Student Dashboard - Main interface for students
 * Demonstrates OOP concepts: Encapsulation, Inheritance, and Data Structures
 */
public class StudentDashboard extends JFrame {
    
    // Encapsulation: Private fields with getters/setters
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    private int studentId;
    private String studentUsername;
    private String studentFullName;
    private String studentNumber;
    private String strand;
    private String gradeLevel;
    private String section;
    private List<String> attendanceHistory; // Data Structure: List for attendance records
    
    // UI Components
    private JPanel headerPanel;
    private JPanel sidebarPanel;
    private JPanel contentPanel;
    private JLabel welcomeLabel;
    private JButton logoutButton;
    private JButton dashboardButton;
    private JButton profileButton;
    private JButton attendanceHistoryButton;
    private JButton qrCodeButton;
    
    /**
     * Constructor - Demonstrates Encapsulation
     * @param studentId Student ID
     * @param username Student username
     * @param fullName Student full name
     */
    public StudentDashboard(int studentId, String username, String fullName) {
        this.studentId = studentId;
        this.studentUsername = username;
        this.studentFullName = fullName;
        this.attendanceHistory = new ArrayList<>(); // Data Structure initialization
        
        initComponents();
        setupEventHandlers();
        loadStudentData(); // Load data first
        showDashboardContent(); // Then show dashboard content
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Student Dashboard - Attendance Monitoring System");
        setResizable(true);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Initialize panels and components
        headerPanel = new JPanel();
        sidebarPanel = new JPanel();
        contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(new Color(240, 240, 240));
        
        setupHeaderPanel();
        setupSidebarPanel();
        
        // Set layout
        setLayout(new BorderLayout());
        add(headerPanel, BorderLayout.NORTH);
        add(sidebarPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    /**
     * Setup header panel with student info
     */
    private void setupHeaderPanel() {
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(1200, 80));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("STUDENT DASHBOARD");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel subtitleLabel = new JLabel("ATTENDANCE MONITORING SYSTEM");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        logoutButton = new JButton(" LOGOUT ");
        logoutButton.setBackground(PRIMARY_COLOR);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        headerPanel.add(logoutButton, BorderLayout.EAST);
    }
    
    /**
     * Setup sidebar panel with navigation buttons
     */
    private void setupSidebarPanel() {
        sidebarPanel.setBackground(new Color(240, 240, 240));
        sidebarPanel.setPreferredSize(new Dimension(250, 600));
        sidebarPanel.setLayout(new BorderLayout());
        
        // Navigation buttons panel (single vertical column)
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.Y_AXIS));
        buttonsPanel.setBackground(new Color(240, 240, 240));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        
        dashboardButton = createNavButton("Dashboard");
        profileButton = createNavButton("Profile");
        attendanceHistoryButton = createNavButton("Attendance History");
        qrCodeButton = createNavButton("QR Code");
        
        addSidebarButton(buttonsPanel, dashboardButton);
        addSidebarButton(buttonsPanel, profileButton);
        addSidebarButton(buttonsPanel, attendanceHistoryButton);
        addSidebarButton(buttonsPanel, qrCodeButton);
        
        sidebarPanel.add(buttonsPanel, BorderLayout.CENTER);
    }
    
    /**
     * Create navigation button with consistent styling
     * @param text Button text
     * @return Styled JButton
     */
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setPreferredSize(new Dimension(200, 45));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Helper to add a sidebar button with spacing to a vertical panel
     */
    private void addSidebarButton(JPanel container, JButton button) {
        container.add(button);
        container.add(Box.createVerticalStrut(12));
    }
    
    
    /**
     * Load student data from database
     * Demonstrates Data Structure usage with Lists and Arrays
     */
    private void loadStudentData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Get student information
                String query = "SELECT s.student_number, s.grade_level, s.section, subj.strand " +
                              "FROM students s " +
                              "LEFT JOIN teacher_assignments ta ON s.section = ta.section AND s.grade_level = ta.grade_level " +
                              "LEFT JOIN subjects subj ON ta.subject_id = subj.subject_id " +
                              "WHERE s.student_id = ? " +
                              "LIMIT 1";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, studentId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    this.studentNumber = rs.getString("student_number");
                    this.gradeLevel = rs.getString("grade_level");
                    this.section = rs.getString("section");
                    this.strand = rs.getString("strand") != null ? rs.getString("strand") : "N/A";
                }
                rs.close();
                stmt.close();
                
                // Update welcome message (only if welcomeLabel is initialized)
                if (welcomeLabel != null) {
                welcomeLabel.setText("Welcome, " + studentFullName + "!");
                }
                
                // Load attendance summary
                loadAttendanceSummary();
                
                System.out.println("✅ Student data loaded successfully for: " + studentFullName);
            }
        } catch (Exception e) {
            System.err.println("❌ Error loading student data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading student data: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Load attendance summary for the student
     * Demonstrates Data Structure: List usage
     */
    private void loadAttendanceSummary() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // Get today's attendance
            String todayQuery = "SELECT COUNT(*) FROM attendance_records WHERE student_id = ? AND attendance_date = CURDATE()";
            PreparedStatement stmt = conn.prepareStatement(todayQuery);
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            int todayAttendance = 0;
            if (rs.next()) {
                todayAttendance = rs.getInt(1);
            }
            rs.close();
            stmt.close();
            
            // Get monthly attendance summary
            String monthlyQuery = "SELECT COUNT(*) as total, " +
                                "SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present, " +
                                "SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent, " +
                                "SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) as late " +
                                "FROM attendance_records WHERE student_id = ? AND " +
                                "attendance_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')";
            
            stmt = conn.prepareStatement(monthlyQuery);
            stmt.setInt(1, studentId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                int totalDays = rs.getInt("total");
                int presentDays = rs.getInt("present");
                int absentDays = rs.getInt("absent");
                int lateDays = rs.getInt("late");
                
                // Store in List (Data Structure)
                attendanceHistory.clear();
                attendanceHistory.add("Total Days: " + totalDays);
                attendanceHistory.add("Present: " + presentDays);
                attendanceHistory.add("Absent: " + absentDays);
                attendanceHistory.add("Late: " + lateDays);
                attendanceHistory.add("Today's Status: " + (todayAttendance > 0 ? "Present" : "Not Marked"));
            }
            rs.close();
            stmt.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading attendance summary: " + e.getMessage());
        }
    }
    
    /**
     * Setup event handlers for all buttons
     */
    private void setupEventHandlers() {
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logoutButtonActionPerformed(e);
            }
        });
        
        dashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dashboardButtonActionPerformed(e);
            }
        });
        
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                profileButtonActionPerformed(e);
            }
        });
        
        attendanceHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attendanceHistoryButtonActionPerformed(e);
            }
        });
        
        qrCodeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                qrCodeButtonActionPerformed(e);
            }
        });
    }
    
    // Event Handlers
    private void logoutButtonActionPerformed(ActionEvent evt) {
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Logout Confirmation",
            JOptionPane.YES_NO_OPTION);
            
        if (choice == JOptionPane.YES_OPTION) {
            // Log the logout activity
            logActivity("LOGOUT", "student", "Student logged out");
            
            // Close current window and return to login
            this.dispose();
            
            // Show login form
            SwingUtilities.invokeLater(() -> {
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true);
            });
        }
    }
    
    private void dashboardButtonActionPerformed(ActionEvent evt) {
        // Show dashboard content
        showDashboardContent();
        loadStudentData();
    }
    
    private void profileButtonActionPerformed(ActionEvent evt) {
        // Open Student Profile form
        SwingUtilities.invokeLater(() -> {
            StudentProfileForm profileForm = new StudentProfileForm(studentId, studentFullName);
            profileForm.setVisible(true);
        });
        logActivity("ACCESS", "profile", "Accessed Student Profile");
    }
    
    private void attendanceHistoryButtonActionPerformed(ActionEvent evt) {
        // Open Attendance History form
        SwingUtilities.invokeLater(() -> {
            StudentAttendanceHistoryForm historyForm = new StudentAttendanceHistoryForm(studentId, studentFullName);
            historyForm.setVisible(true);
        });
        logActivity("ACCESS", "attendance", "Accessed Attendance History");
    }
    
    private void qrCodeButtonActionPerformed(ActionEvent evt) {
        // Open QR Code Scanner form
        SwingUtilities.invokeLater(() -> {
            try {
                StudentQRScannerForm qrScannerForm = new StudentQRScannerForm(this, studentId, studentFullName);
                qrScannerForm.setVisible(true);
            } catch (Exception e) {
                System.err.println("❌ Error opening QR scanner form: " + e.getMessage());
                JOptionPane.showMessageDialog(this, "Error opening QR scanner: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        logActivity("ACCESS", "qr_scanner", "Accessed QR Scanner");
    }
    
    /**
     * Show dashboard content in the main panel
     */
    private void showDashboardContent() {
        contentPanel.removeAll();
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        headerPanel.setLayout(new BorderLayout());
        
        welcomeLabel = new JLabel("Welcome, " + studentFullName + "!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        
        JLabel dateLabel = new JLabel("Today: " + java.time.LocalDate.now().toString());
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(dateLabel, BorderLayout.SOUTH);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content Panel
        JPanel contentMainPanel = new JPanel();
        contentMainPanel.setLayout(new GridLayout(2, 2, 20, 20));
        contentMainPanel.setBackground(Color.WHITE);
        contentMainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Student Info Card
        JPanel infoCard = createInfoCard("Student Information", 
            new String[]{"Student Number", "Grade Level", "Section", "Strand"},
            new String[]{studentNumber, gradeLevel, section, strand});
        contentMainPanel.add(infoCard);
        
        // Today's Attendance Card
        JPanel attendanceCard = createAttendanceCard();
        contentMainPanel.add(attendanceCard);
        
        // Recent Activity Card
        JPanel activityCard = createActivityCard();
        contentMainPanel.add(activityCard);
        
        // Quick Actions Card
        JPanel actionsCard = createActionsCard();
        contentMainPanel.add(actionsCard);
        
        mainPanel.add(contentMainPanel, BorderLayout.CENTER);
        
        contentPanel.add(mainPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Create info card
     */
    private JPanel createInfoCard(String title, String[] labels, String[] values) {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(labels.length, 2, 10, 8));
        infoPanel.setBackground(Color.WHITE);
        
        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(labels[i] + ":");
            label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            infoPanel.add(label);
            
            JLabel value = new JLabel(values[i] != null ? values[i] : "N/A");
            value.setFont(new Font("Segoe UI", Font.BOLD, 12));
            value.setForeground(new Color(70, 130, 180));
            infoPanel.add(value);
        }
        
        card.add(infoPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Create attendance card
     */
    private JPanel createAttendanceCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Today's Attendance");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel attendancePanel = new JPanel();
        attendancePanel.setLayout(new GridBagLayout());
        attendancePanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Load today's attendance data
        String todayStatus = loadTodayAttendance();
        String todayTime = loadTodayTimeIn();
        
        gbc.gridx = 0; gbc.gridy = 0;
        attendancePanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1;
        JLabel statusLabel = new JLabel(todayStatus);
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        if ("Present".equals(todayStatus)) {
            statusLabel.setForeground(new Color(0, 128, 0));
        } else if ("Absent".equals(todayStatus)) {
            statusLabel.setForeground(new Color(220, 53, 69));
        } else {
            statusLabel.setForeground(new Color(255, 140, 0));
        }
        attendancePanel.add(statusLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        attendancePanel.add(new JLabel("Time In:"), gbc);
        gbc.gridx = 1;
        JLabel timeLabel = new JLabel(todayTime);
        timeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        timeLabel.setForeground(new Color(70, 130, 180));
        attendancePanel.add(timeLabel, gbc);
        
        card.add(attendancePanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Create activity card
     */
    private JPanel createActivityCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Recent Attendance");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel activityPanel = new JPanel();
        activityPanel.setLayout(new BorderLayout());
        activityPanel.setBackground(Color.WHITE);
        
        // Load recent attendance
        String[] recentData = loadRecentAttendance();
        
        JTextArea activityArea = new JTextArea(recentData[0]);
        activityArea.setEditable(false);
        activityArea.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        activityArea.setBackground(new Color(248, 248, 248));
        activityArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(activityArea);
        scrollPane.setPreferredSize(new Dimension(0, 100));
        activityPanel.add(scrollPane, BorderLayout.CENTER);
        
        card.add(activityPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Create actions card
     */
    private JPanel createActionsCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Quick Actions");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel actionsPanel = new JPanel();
        actionsPanel.setLayout(new GridLayout(2, 1, 10, 10));
        actionsPanel.setBackground(Color.WHITE);
        
        JButton viewHistoryBtn = new JButton("View Attendance History");
        viewHistoryBtn.setBackground(new Color(70, 130, 180));
        viewHistoryBtn.setForeground(Color.WHITE);
        viewHistoryBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewHistoryBtn.addActionListener(e -> attendanceHistoryButtonActionPerformed(e));
        
        JButton scanQRBtn = new JButton("Scan QR Code");
        scanQRBtn.setBackground(new Color(0, 128, 0));
        scanQRBtn.setForeground(Color.WHITE);
        scanQRBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        scanQRBtn.addActionListener(e -> qrCodeButtonActionPerformed(e));
        
        actionsPanel.add(viewHistoryBtn);
        actionsPanel.add(scanQRBtn);
        
        card.add(actionsPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Load today's attendance status
     */
    private String loadTodayAttendance() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT ar.status FROM attendance_records ar " +
                              "JOIN teacher_assignments ta ON ar.subject_id = ta.subject_id " +
                              "WHERE ar.student_id = ? AND ar.attendance_date = CURDATE() " +
                              "AND ta.section = ? LIMIT 1";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, studentId);
                stmt.setString(2, section);
                
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String status = rs.getString("status");
                    rs.close();
                    stmt.close();
                    conn.close();
                    return status;
                }
                
                rs.close();
                stmt.close();
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading today's attendance: " + e.getMessage());
        }
        return "Not Marked";
    }
    
    /**
     * Load today's time in
     */
    private String loadTodayTimeIn() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT ar.time_in FROM attendance_records ar " +
                              "JOIN teacher_assignments ta ON ar.subject_id = ta.subject_id " +
                              "WHERE ar.student_id = ? AND ar.attendance_date = CURDATE() " +
                              "AND ta.section = ? LIMIT 1";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, studentId);
                stmt.setString(2, section);
                
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    java.sql.Time timeIn = rs.getTime("time_in");
                    rs.close();
                    stmt.close();
                    conn.close();
                    return timeIn != null ? timeIn.toString() : "N/A";
                }
                
                rs.close();
                stmt.close();
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading today's time in: " + e.getMessage());
        }
        return "N/A";
    }
    
    /**
     * Load recent attendance
     */
    private String[] loadRecentAttendance() {
        StringBuilder activityText = new StringBuilder();
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String query = "SELECT ar.attendance_date, s.subject_name, ar.status, ar.time_in " +
                              "FROM attendance_records ar " +
                              "JOIN subjects s ON ar.subject_id = s.subject_id " +
                              "JOIN teacher_assignments ta ON ar.subject_id = ta.subject_id " +
                              "WHERE ar.student_id = ? AND ta.section = ? " +
                              "ORDER BY ar.attendance_date DESC LIMIT 5";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, studentId);
                stmt.setString(2, section);
                
                ResultSet rs = stmt.executeQuery();
                int count = 0;
                while (rs.next()) {
                    count++;
                    String date = rs.getDate("attendance_date").toString();
                    String subject = rs.getString("subject_name");
                    String status = rs.getString("status");
                    String timeIn = rs.getTime("time_in") != null ? rs.getTime("time_in").toString() : "N/A";
                    
                    activityText.append(date).append(" - ").append(subject)
                              .append(" (").append(status).append(")\n");
                    if (!"N/A".equals(timeIn)) {
                        activityText.append("  Time: ").append(timeIn).append("\n");
                    }
                    activityText.append("\n");
                }
                
                if (count == 0) {
                    activityText.append("No recent attendance records found.");
                }
                
                rs.close();
                stmt.close();
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading recent attendance: " + e.getMessage());
            activityText.append("Error loading attendance data.");
        }
        
        return new String[]{activityText.toString()};
    }
    
    
    
    /**
     * Log activity to audit trail
     * @param actionType Type of action
     * @param tableName Table affected
     * @param description Action description
     */
    private void logActivity(String actionType, String tableName, String description) {
        // Activity logging disabled - activity_logs table not available in current database
        System.out.println("Activity: " + actionType + " - " + description + " (User: " + studentUsername + ")");
    }
    
    /**
     * Get client IP address (simplified)
     * @return IP address string
     */

    
    // Getter methods (Encapsulation)
    public int getStudentId() {
        return studentId;
    }
    
    public String getStudentUsername() {
        return studentUsername;
    }
    
    public String getStudentFullName() {
        return studentFullName;
    }
    
    public String getStudentNumber() {
        return studentNumber;
    }
    
    public String getStrand() {
        return strand;
    }
    
    public String getGradeLevel() {
        return gradeLevel;
    }
    
    public String getSection() {
        return section;
    }
    
    public List<String> getAttendanceHistory() {
        return new ArrayList<>(attendanceHistory); // Return copy to maintain encapsulation
    }
    
    // Setter methods (Encapsulation)
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    
    public void setStudentUsername(String studentUsername) {
        this.studentUsername = studentUsername;
    }
    
    public void setStudentFullName(String studentFullName) {
        this.studentFullName = studentFullName;
    }
    
    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }
    
    public void setStrand(String strand) {
        this.strand = strand;
    }
    
    public void setGradeLevel(String gradeLevel) {
        this.gradeLevel = gradeLevel;
    }
    
    public void setSection(String section) {
        this.section = section;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentDashboard dashboard = new StudentDashboard(1, "student001", "John Doe");
            dashboard.setVisible(true);
        });
    }
}
