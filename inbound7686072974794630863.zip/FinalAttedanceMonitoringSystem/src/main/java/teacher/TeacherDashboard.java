package teacher;

import common.DatabaseConnection;
import login.LoginForm;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Teacher Dashboard - Main interface for teachers
 * Demonstrates OOP concepts: Encapsulation, Inheritance, and Data Structures
 */
public class TeacherDashboard extends JFrame {
    
    // Encapsulation: Private fields with getters/setters
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    private int teacherId;
    private String teacherUsername;
    private String teacherFullName;
    private String teacherNumber;
    private String department;
    private String specialization;
    private List<String> assignedSections; // Data Structure: List for assigned sections
    private List<String> dailyStats; // Data Structure: List for daily statistics
    
    // UI Components
    private JPanel headerPanel;
    private JPanel sidebarPanel;
    private JPanel contentPanel;
    private JLabel welcomeLabel;
    private JButton logoutButton;
    private JButton dashboardButton;
    private JButton assignedSectionsButton;
    private JButton attendanceManagementButton;
    private JButton studentRecordsButton;
    
    /**
     * Constructor - Demonstrates Encapsulation
     * @param teacherId Teacher ID
     * @param username Teacher username
     * @param fullName Teacher full name
     */
    public TeacherDashboard(int teacherId, String username, String fullName) {
        this.teacherId = teacherId;
        this.teacherUsername = username;
        this.teacherFullName = fullName;
        this.assignedSections = new ArrayList<>(); // Data Structure initialization
        this.dailyStats = new ArrayList<>(); // Data Structure initialization
        
        initComponents();
        loadTeacherData();
        setupEventHandlers();
        showDashboardContent(); // Show dashboard after data is loaded
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Teacher Dashboard - Attendance Monitoring System");
        setResizable(true);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Initialize panels and components
        headerPanel = new JPanel();
        sidebarPanel = new JPanel();
        contentPanel = new JPanel();
        
        setupHeaderPanel();
        setupSidebarPanel();
        setupContentPanel();
        
        // Set layout
        setLayout(new BorderLayout());
        add(headerPanel, BorderLayout.NORTH);
        add(sidebarPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    /**
     * Setup header panel with teacher info
     */
    private void setupHeaderPanel() {
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(1200, 80));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("TEACHER DASHBOARD");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel subtitleLabel = new JLabel("ATTENDANCE MONITORING SYSTEM");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        logoutButton = new JButton(" LOGOUT ");
        logoutButton.setBackground(PRIMARY_COLOR);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        headerPanel.add(logoutButton, BorderLayout.EAST);
    }
    
    /**
     * Setup sidebar panel with navigation buttons
     */
    private void setupSidebarPanel() {
        sidebarPanel.setBackground(new Color(240, 240, 240));
        sidebarPanel.setPreferredSize(new Dimension(250, 600));
        sidebarPanel.setLayout(new BorderLayout());
        
        // Navigation buttons panel (single vertical column)
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.Y_AXIS));
        buttonsPanel.setBackground(new Color(240, 240, 240));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        
        dashboardButton = createNavButton("Dashboard");
        assignedSectionsButton = createNavButton("Assigned Sections");
        attendanceManagementButton = createNavButton("Attendance Management");
        studentRecordsButton = createNavButton("Student Records");
        
        addSidebarButton(buttonsPanel, dashboardButton);
        addSidebarButton(buttonsPanel, assignedSectionsButton);
        addSidebarButton(buttonsPanel, attendanceManagementButton);
        addSidebarButton(buttonsPanel, studentRecordsButton);
        
        sidebarPanel.add(buttonsPanel, BorderLayout.CENTER);
    }
    
    /**
     * Create navigation button with consistent styling
     * @param text Button text
     * @return Styled JButton
     */
    private JButton createNavButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setPreferredSize(new Dimension(200, 45));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Helper to add a sidebar button with spacing to a vertical panel
     */
    private void addSidebarButton(JPanel container, JButton button) {
        container.add(button);
        container.add(Box.createVerticalStrut(12));
    }
    
    /**
     * Setup content panel with dashboard information
     */
    private void setupContentPanel() {
        contentPanel.setBackground(new Color(240, 240, 240));
        contentPanel.setLayout(new BorderLayout());
        
        // Dashboard content will be shown after data is loaded
    }
    
    /**
     * Show dashboard content in the main panel
     */
    private void showDashboardContent() {
        contentPanel.removeAll();
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        headerPanel.setLayout(new BorderLayout());
        
        welcomeLabel = new JLabel("Welcome, " + teacherFullName + "!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        
        JLabel dateLabel = new JLabel("Today: " + java.time.LocalDate.now().toString());
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(dateLabel, BorderLayout.SOUTH);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Content Panel
        JPanel contentMainPanel = new JPanel();
        contentMainPanel.setLayout(new GridLayout(2, 2, 20, 20));
        contentMainPanel.setBackground(Color.WHITE);
        contentMainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Teacher Info Card
        JPanel infoCard = createTeacherInfoCard();
        contentMainPanel.add(infoCard);
        
        // Today's Statistics Card
        JPanel statsCard = createTodayStatsCard();
        contentMainPanel.add(statsCard);
        
        // Assigned Sections Card
        JPanel sectionsCard = createSectionsCard();
        contentMainPanel.add(sectionsCard);
        
        // Quick Actions Card
        JPanel actionsCard = createTeacherActionsCard();
        contentMainPanel.add(actionsCard);
        
        mainPanel.add(contentMainPanel, BorderLayout.CENTER);
        
        contentPanel.add(mainPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Create teacher info card
     */
    private JPanel createTeacherInfoCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Teacher Information");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(4, 2, 10, 8));
        infoPanel.setBackground(Color.WHITE);
        
        String[] labels = {"Teacher Number", "Department", "Specialization", "Employment Status"};
        String[] values = {
            teacherNumber != null ? teacherNumber : "N/A",
            department != null ? department : "N/A", 
            specialization != null ? specialization : "N/A",
            "Active"
        };
        
        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(labels[i] + ":");
            label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            infoPanel.add(label);
            
            JLabel value = new JLabel(values[i]);
            value.setFont(new Font("Segoe UI", Font.BOLD, 12));
            value.setForeground(new Color(70, 130, 180));
            infoPanel.add(value);
        }
        
        card.add(infoPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Create today's statistics card
     */
    private JPanel createTodayStatsCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Today's Statistics");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel statsPanel = new JPanel();
        statsPanel.setLayout(new GridBagLayout());
        statsPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        
        // Load today's statistics
        int[] todayStats = loadTodayStatistics();
        
        gbc.gridx = 0; gbc.gridy = 0;
        statsPanel.add(new JLabel("Attendance Records:"), gbc);
        gbc.gridx = 1;
        JLabel attendanceLabel = new JLabel(String.valueOf(todayStats[0]));
        attendanceLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        attendanceLabel.setForeground(new Color(0, 128, 0));
        statsPanel.add(attendanceLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        statsPanel.add(new JLabel("Total Students:"), gbc);
        gbc.gridx = 1;
        JLabel studentsLabel = new JLabel(String.valueOf(todayStats[1]));
        studentsLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        studentsLabel.setForeground(new Color(70, 130, 180));
        statsPanel.add(studentsLabel, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        statsPanel.add(new JLabel("Assigned Sections:"), gbc);
        gbc.gridx = 1;
        JLabel sectionsLabel = new JLabel(String.valueOf(todayStats[2]));
        sectionsLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sectionsLabel.setForeground(new Color(255, 140, 0));
        statsPanel.add(sectionsLabel, gbc);
        
        card.add(statsPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Create assigned sections card
     */
    private JPanel createSectionsCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Assigned Sections");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel sectionsPanel = new JPanel();
        sectionsPanel.setLayout(new BorderLayout());
        sectionsPanel.setBackground(Color.WHITE);
        
        // Load assigned sections
        String sectionsText = loadAssignedSectionsText();
        
        JTextArea sectionsArea = new JTextArea(sectionsText);
        sectionsArea.setEditable(false);
        sectionsArea.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sectionsArea.setBackground(new Color(248, 248, 248));
        sectionsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(sectionsArea);
        scrollPane.setPreferredSize(new Dimension(0, 100));
        sectionsPanel.add(scrollPane, BorderLayout.CENTER);
        
        card.add(sectionsPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Create teacher actions card
     */
    private JPanel createTeacherActionsCard() {
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel("Quick Actions");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(new Color(70, 130, 180));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JPanel actionsPanel = new JPanel();
        actionsPanel.setLayout(new GridLayout(2, 1, 10, 10));
        actionsPanel.setBackground(Color.WHITE);
        
        JButton attendanceBtn = new JButton("Manage Attendance");
        attendanceBtn.setBackground(new Color(70, 130, 180));
        attendanceBtn.setForeground(Color.WHITE);
        attendanceBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        attendanceBtn.addActionListener(e -> attendanceManagementButtonActionPerformed(e));
        
        JButton recordsBtn = new JButton("View Student Records");
        recordsBtn.setBackground(new Color(0, 128, 0));
        recordsBtn.setForeground(Color.WHITE);
        recordsBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        recordsBtn.addActionListener(e -> studentRecordsButtonActionPerformed(e));
        
        actionsPanel.add(attendanceBtn);
        actionsPanel.add(recordsBtn);
        
        card.add(actionsPanel, BorderLayout.CENTER);
        return card;
    }
    
    /**
     * Load today's statistics
     */
    private int[] loadTodayStatistics() {
        int[] stats = {0, 0, 0}; // attendance, students, sections
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Today's attendance records
                String query = "SELECT COUNT(*) as attendance_count " +
                              "FROM attendance_records ar " +
                              "JOIN teacher_assignments ta ON ar.subject_id = ta.subject_id " +
                              "WHERE ta.teacher_id = ? AND ar.attendance_date = CURDATE()";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    stats[0] = rs.getInt("attendance_count");
                }
                rs.close();
                stmt.close();
                
                // Total students in assigned sections
                query = "SELECT COUNT(DISTINCT s.student_id) as student_count " +
                       "FROM students s " +
                       "JOIN teacher_assignments ta ON s.section = ta.section AND s.grade_level = ta.grade_level " +
                       "WHERE ta.teacher_id = ? AND s.is_active = 1";
                
                stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                rs = stmt.executeQuery();
                
                if (rs.next()) {
                    stats[1] = rs.getInt("student_count");
                }
                rs.close();
                stmt.close();
                
                // Assigned sections count
                stats[2] = assignedSections.size();
                
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading today's statistics: " + e.getMessage());
        }
        
        return stats;
    }
    
    /**
     * Load assigned sections text
     */
    private String loadAssignedSectionsText() {
        StringBuilder sectionsText = new StringBuilder();
        
        if (assignedSections.isEmpty()) {
            sectionsText.append("No assigned sections found.");
        } else {
            for (String section : assignedSections) {
                sectionsText.append("• ").append(section).append("\n");
            }
        }
        
        return sectionsText.toString();
    }
    
    /**
     * Load teacher data from database
     * Demonstrates Data Structure usage with Lists and Arrays
     */
    private void loadTeacherData() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Get teacher information
                String query = "SELECT teacher_number, department, specialization FROM teachers WHERE teacher_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, teacherId);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    this.teacherNumber = rs.getString("teacher_number");
                    this.department = rs.getString("department");
                    this.specialization = rs.getString("specialization");
                }
                rs.close();
                stmt.close();
                
                // Update welcome message (only if welcomeLabel is initialized)
                if (welcomeLabel != null) {
                    welcomeLabel.setText("Welcome, " + teacherFullName + "!");
                }
                
                // Load assigned sections
                loadAssignedSections();
                
                // Load daily statistics
                loadDailyStatistics();
                
                System.out.println("✅ Teacher data loaded successfully for: " + teacherFullName);
            }
        } catch (Exception e) {
            System.err.println("❌ Error loading teacher data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error loading teacher data: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Load assigned sections for the teacher
     * Demonstrates Data Structure: List usage
     */
    private void loadAssignedSections() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            String query = "SELECT ta.section as section_name, sub.strand, ta.grade_level, sub.subject_name " +
                          "FROM teacher_assignments ta " +
                          "JOIN subjects sub ON ta.subject_id = sub.subject_id " +
                          "WHERE ta.teacher_id = ? AND ta.is_active = 1";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, teacherId);
            ResultSet rs = stmt.executeQuery();
            
            assignedSections.clear(); // Clear existing sections
            while (rs.next()) {
                String sectionInfo = rs.getString("section_name") + " - " + 
                                   rs.getString("strand") + " " + 
                                   rs.getString("grade_level") + " (" + 
                                   rs.getString("subject_name") + ")";
                assignedSections.add(sectionInfo); // Add to List
            }
            
            rs.close();
            stmt.close();
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading assigned sections: " + e.getMessage());
        }
    }
    
    /**
     * Load daily statistics for the teacher
     * Demonstrates Data Structure: List usage
     */
    private void loadDailyStatistics() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            
            // Get today's attendance count for teacher's sections
            String query = "SELECT COUNT(*) as total_attendance " +
                          "FROM attendance_records ar " +
                          "JOIN teacher_assignments ta ON ar.subject_id = ta.subject_id " +
                          "WHERE ta.teacher_id = ? AND ar.attendance_date = CURDATE()";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, teacherId);
            ResultSet rs = stmt.executeQuery();
            
            dailyStats.clear(); // Clear existing stats
            if (rs.next()) {
                int todayAttendance = rs.getInt("total_attendance");
                dailyStats.add("Today's Attendance Records: " + todayAttendance);
            }
            rs.close();
            stmt.close();
            
            // Get total students in assigned sections
            query = "SELECT COUNT(DISTINCT s.student_id) as total_students " +
                   "FROM students s " +
                   "JOIN teacher_assignments ta ON s.section = ta.section AND s.grade_level = ta.grade_level " +
                   "WHERE ta.teacher_id = ? AND s.is_active = 1";
            
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, teacherId);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                int totalStudents = rs.getInt("total_students");
                dailyStats.add("Total Students in Assigned Sections: " + totalStudents);
            }
            rs.close();
            stmt.close();
            
            // Get assigned sections count
            dailyStats.add("Assigned Sections: " + assignedSections.size());
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading daily statistics: " + e.getMessage());
        }
    }
    
    /**
     * Setup event handlers for all buttons
     */
    private void setupEventHandlers() {
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logoutButtonActionPerformed(e);
            }
        });
        
        dashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dashboardButtonActionPerformed(e);
            }
        });
        
        assignedSectionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                assignedSectionsButtonActionPerformed(e);
            }
        });
        
        attendanceManagementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attendanceManagementButtonActionPerformed(e);
            }
        });
        
        studentRecordsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                studentRecordsButtonActionPerformed(e);
            }
        });
        
    }
    
    // Event Handlers
    private void logoutButtonActionPerformed(ActionEvent evt) {
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Logout Confirmation",
            JOptionPane.YES_NO_OPTION);
            
        if (choice == JOptionPane.YES_OPTION) {
            // Log the logout activity
            logActivity("LOGOUT", "teacher", "Teacher logged out");
            
            // Close current window and return to login
            this.dispose();
            
            // Show login form
            SwingUtilities.invokeLater(() -> {
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true);
            });
        }
    }
    
    private void dashboardButtonActionPerformed(ActionEvent evt) {
        // Show dashboard content
        showDashboardContent();
        // Refresh data
        loadTeacherData();
    }
    
    private void assignedSectionsButtonActionPerformed(ActionEvent evt) {
        // Open Assigned Sections form
        SwingUtilities.invokeLater(() -> {
            TeacherAssignedSectionsForm sectionsForm = new TeacherAssignedSectionsForm(teacherId, teacherFullName);
            sectionsForm.setVisible(true);
        });
        logActivity("ACCESS", "assigned_sections", "Accessed Assigned Sections");
    }
    
    private void attendanceManagementButtonActionPerformed(ActionEvent evt) {
        // Open Attendance Management form
        SwingUtilities.invokeLater(() -> {
            TeacherAttendanceManagementForm attendanceForm = new TeacherAttendanceManagementForm(teacherId, teacherFullName);
            attendanceForm.setVisible(true);
        });
        logActivity("ACCESS", "attendance_management", "Accessed Attendance Management");
    }
    
    private void studentRecordsButtonActionPerformed(ActionEvent evt) {
        // Open Student Records form
        SwingUtilities.invokeLater(() -> {
            try {
                TeacherStudentRecordsForm studentRecordsForm = new TeacherStudentRecordsForm(this, teacherId);
                studentRecordsForm.setVisible(true);
            } catch (Exception e) {
                System.err.println("❌ Error opening student records form: " + e.getMessage());
                JOptionPane.showMessageDialog(this, "Error opening student records form: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        logActivity("ACCESS", "student_records", "Accessed Student Records");
    }
    
    
    /**
     * Log activity to audit trail
     * @param actionType Type of action
     * @param tableName Table affected
     * @param description Action description
     */
    private void logActivity(String actionType, String tableName, String description) {
        // Activity logging disabled - activity_logs table not available in current database
        System.out.println("Activity: " + actionType + " - " + description + " (User: " + teacherUsername + ")");
    }
    
    /**
     * Get client IP address (simplified)
     * @return IP address string
     */

    
    // Getter methods (Encapsulation)
    public int getTeacherId() {
        return teacherId;
    }
    
    public String getTeacherUsername() {
        return teacherUsername;
    }
    
    public String getTeacherFullName() {
        return teacherFullName;
    }
    
    public String getTeacherNumber() {
        return teacherNumber;
    }
    
    public String getDepartment() {
        return department;
    }
    
    public String getSpecialization() {
        return specialization;
    }
    
    public List<String> getAssignedSections() {
        return new ArrayList<>(assignedSections); // Return copy to maintain encapsulation
    }
    
    public List<String> getDailyStats() {
        return new ArrayList<>(dailyStats); // Return copy to maintain encapsulation
    }
    
    // Setter methods (Encapsulation)
    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }
    
    public void setTeacherUsername(String teacherUsername) {
        this.teacherUsername = teacherUsername;
    }
    
    public void setTeacherFullName(String teacherFullName) {
        this.teacherFullName = teacherFullName;
    }
    
    public void setTeacherNumber(String teacherNumber) {
        this.teacherNumber = teacherNumber;
    }
    
    public void setDepartment(String department) {
        this.department = department;
    }
    
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TeacherDashboard dashboard = new TeacherDashboard(1, "teacher001", "Jane Smith");
            dashboard.setVisible(true);
        });
    }
}
