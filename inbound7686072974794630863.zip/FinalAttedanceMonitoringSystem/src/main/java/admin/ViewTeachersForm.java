package admin;

import common.DatabaseConnection;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * ViewTeachersForm - Form for viewing all teachers in the system
 * Demonstrates Object-Oriented Programming principles
 */
public class ViewTeachersForm extends JFrame {
    
    // UI Components - Encapsulation
    private JTable teachersTable;
    private DefaultTableModel tableModel;
    private JButton refreshButton;
    private JButton closeButton;
    private JLabel statusLabel;
    
    // Table columns
    private static final String[] COLUMN_NAMES = {
        "Teacher ID", "Teacher Number", "Full Name", "Department", 
        "Specialization", "Employment Status", "Username", "Created At"
    };
    
    /**
     * Constructor - Demonstrates Encapsulation and Polymorphism
     */
    public ViewTeachersForm() {
        initComponents();
        setupEventHandlers();
        
        setTitle("View Teachers");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        loadTeachers();
    }
    
    /**
     * Initialize UI components - Demonstrates Encapsulation
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 33, 0));
        headerPanel.setPreferredSize(new Dimension(1000, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Teachers List");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Initialize table model
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        teachersTable = new JTable(tableModel);
        teachersTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        teachersTable.setRowHeight(25);
        teachersTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        teachersTable.getColumnModel().getColumn(0).setPreferredWidth(80);   // Teacher ID
        teachersTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // Teacher Number
        teachersTable.getColumnModel().getColumn(2).setPreferredWidth(200);  // Full Name
        teachersTable.getColumnModel().getColumn(3).setPreferredWidth(120);  // Department
        teachersTable.getColumnModel().getColumn(4).setPreferredWidth(150);  // Specialization
        teachersTable.getColumnModel().getColumn(5).setPreferredWidth(120);  // Employment Status
        teachersTable.getColumnModel().getColumn(6).setPreferredWidth(120);  // Username
        teachersTable.getColumnModel().getColumn(7).setPreferredWidth(150);  // Created At
        
        // Content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.setBackground(Color.WHITE);
        
        JScrollPane scrollPane = new JScrollPane(teachersTable);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 20, 10, 20),
            BorderFactory.createLineBorder(new Color(200, 200, 200))
        ));
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(243, 150, 33));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(120, 35));
        
        closeButton = new JButton("Close");
        closeButton.setBackground(new Color(158, 158, 158));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        closeButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);
        
        // Add panels to frame
        add(headerPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        statusLabel = new JLabel("Loading teachers...");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(100, 100, 100));
    }
    
    
    /**
     * Setup event handlers - Demonstrates Event-Driven Programming
     */
    private void setupEventHandlers() {
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshButtonActionPerformed(e);
            }
        });
        
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeButtonActionPerformed(e);
            }
        });
    }
    
    /**
     * Load teachers from database - Demonstrates Database Operations
     */
    private void loadTeachers() {
        statusLabel.setText("Loading teachers...");
        
        // Clear existing data
        tableModel.setRowCount(0);
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT t.teacher_id, t.teacher_number, t.first_name, t.last_name, t.middle_name, " +
                          "t.department, t.specialization, t.employment_status, u.username, t.created_at " +
                          "FROM teachers t " +
                          "JOIN users u ON t.user_id = u.user_id " +
                          "WHERE t.is_active = 1 " +
                          "ORDER BY t.teacher_number";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            int count = 0;
            while (rs.next()) {
                // Build full name
                String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
                if (rs.getString("middle_name") != null && !rs.getString("middle_name").trim().isEmpty()) {
                    fullName = rs.getString("first_name") + " " + rs.getString("middle_name") + " " + rs.getString("last_name");
                }
                
                // Get specialization (handle null)
                String specialization = rs.getString("specialization");
                if (specialization == null) {
                    specialization = "N/A";
                }
                
                // Format created date
                String createdDate = rs.getTimestamp("created_at").toString();
                if (createdDate.contains(".")) {
                    createdDate = createdDate.substring(0, createdDate.indexOf("."));
                }
                
                // Add row to table
                Object[] row = {
                    rs.getInt("teacher_id"),
                    rs.getString("teacher_number"),
                    fullName,
                    rs.getString("department"),
                    specialization,
                    rs.getString("employment_status"),
                    rs.getString("username"),
                    createdDate
                };
                
                tableModel.addRow(row);
                count++;
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
            statusLabel.setText("Loaded " + count + " teachers");
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading teachers: " + e.getMessage());
            statusLabel.setText("Error loading teachers");
            JOptionPane.showMessageDialog(this, 
                "Error loading teachers: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Handle Refresh button click - Demonstrates Event Handling
     */
    private void refreshButtonActionPerformed(ActionEvent evt) {
        loadTeachers();
        System.out.println("Teachers list refreshed");
    }
    
    /**
     * Handle Close button click - Demonstrates Event Handling
     */
    private void closeButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
    
    /**
     * Get selected teacher data - Demonstrates Data Access
     */
    public Object[] getSelectedTeacherData() {
        int selectedRow = teachersTable.getSelectedRow();
        if (selectedRow >= 0) {
            Object[] data = new Object[tableModel.getColumnCount()];
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                data[i] = tableModel.getValueAt(selectedRow, i);
            }
            return data;
        }
        return null;
    }
    
    /**
     * Get teacher count - Demonstrates Data Analysis
     */
    public int getTeacherCount() {
        return tableModel.getRowCount();
    }
}
