package admin;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Simple Update Student Dialog
 * Allows admin to update student information
 */
public class UpdateStudentDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // Form fields
    private JComboBox<String> studentCombo;
    private JTextField studentNumberField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField middleNameField;
    private JComboBox<String> gradeLevelCombo;
    private JTextField sectionField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    
    // Buttons
    private JButton loadButton;
    private JButton updateButton;
    private JButton cancelButton;
    
    // Current student data
    private int currentStudentId = -1;
    private int currentUserId = -1;
    
    // Parent reference
    private AdminDashboard parent;
    
    public UpdateStudentDialog(AdminDashboard parent) {
        super(parent, "Update Student", true);
        this.parent = parent;
        
        initComponents();
        setupEventHandlers();
        loadStudents();
        
        setSize(600, 700);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(600, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Update Student Information");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Student selection
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Student:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        studentCombo = new JComboBox<>();
        studentCombo.setPreferredSize(new Dimension(300, 30));
        formPanel.add(studentCombo, gbc);
        
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        loadButton = new JButton("Load");
        loadButton.setBackground(PRIMARY_COLOR);
        loadButton.setForeground(Color.WHITE);
        loadButton.setPreferredSize(new Dimension(80, 30));
        formPanel.add(loadButton, gbc);
        
        // Separator
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 3; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        formPanel.add(new JSeparator(), gbc);
        
        // Student Number
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Student Number *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        studentNumberField = new JTextField(20);
        formPanel.add(studentNumberField, gbc);
        
        // First Name
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("First Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Last Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField, gbc);
        
        // Middle Name
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Middle Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        middleNameField = new JTextField(20);
        formPanel.add(middleNameField, gbc);
        
        // Grade Level
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Grade Level *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gradeLevelCombo = new JComboBox<>(new String[]{"Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"});
        formPanel.add(gradeLevelCombo, gbc);
        
        // Section
        gbc.gridx = 0; gbc.gridy = 7; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Section *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        sectionField = new JTextField(20);
        formPanel.add(sectionField, gbc);
        
        // Username
        gbc.gridx = 0; gbc.gridy = 8; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Username *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 9; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Password (leave blank to keep current):"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 10; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(20);
        formPanel.add(confirmPasswordField, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        updateButton = new JButton("Update Student");
        updateButton.setBackground(PRIMARY_COLOR);
        updateButton.setForeground(Color.WHITE);
        updateButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        updateButton.setPreferredSize(new Dimension(140, 35));
        updateButton.setEnabled(false);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(Color.GRAY);
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadStudentData();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateStudent();
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }
    
    private void loadStudents() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT student_id, student_number, first_name, last_name " +
                          "FROM students WHERE is_active = 1 ORDER BY student_number";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            studentCombo.removeAllItems();
            
            while (rs.next()) {
                String displayText = rs.getString("student_number") + " - " + 
                                   rs.getString("first_name") + " " + rs.getString("last_name");
                studentCombo.addItem(displayText);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading students: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void loadStudentData() {
        if (studentCombo.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, 
                "Please select a student to load", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            String selectedText = (String) studentCombo.getSelectedItem();
            String studentNumber = selectedText.split(" - ")[0];
            
            Connection conn = DatabaseConnection.getConnection();
            String query = "SELECT s.*, u.username FROM students s " +
                          "LEFT JOIN users u ON s.user_id = u.user_id " +
                          "WHERE s.student_number = ? AND s.is_active = 1";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, studentNumber);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                currentStudentId = rs.getInt("student_id");
                currentUserId = rs.getInt("user_id");
                
                // Populate form fields
                studentNumberField.setText(rs.getString("student_number"));
                firstNameField.setText(rs.getString("first_name"));
                lastNameField.setText(rs.getString("last_name"));
                middleNameField.setText(rs.getString("middle_name") != null ? rs.getString("middle_name") : "");
                
                // Set grade level combo
                String gradeLevel = rs.getString("grade_level");
                for (int i = 0; i < gradeLevelCombo.getItemCount(); i++) {
                    if (gradeLevelCombo.getItemAt(i).equals(gradeLevel)) {
                        gradeLevelCombo.setSelectedIndex(i);
                        break;
                    }
                }
                
                sectionField.setText(rs.getString("section"));
                usernameField.setText(rs.getString("username"));
                passwordField.setText(""); // Clear password field
                
                updateButton.setEnabled(true);
            }
            
            rs.close();
            stmt.close();
            conn.close();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Error loading student data: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void updateStudent() {
        // Validate required fields
        if (studentNumberField.getText().trim().isEmpty() ||
            firstNameField.getText().trim().isEmpty() ||
            lastNameField.getText().trim().isEmpty() ||
            sectionField.getText().trim().isEmpty() ||
            usernameField.getText().trim().isEmpty()) {
            
            JOptionPane.showMessageDialog(this, 
                "Please fill in all required fields (*)", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate passwords if provided
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        if (!password.isEmpty() || !confirmPassword.isEmpty()) {
            if (password.isEmpty() || confirmPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Both password fields must be filled if you want to change the password", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, 
                    "Passwords do not match!", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                confirmPasswordField.requestFocus();
                return;
            }
            
            if (password.length() < 6) {
                JOptionPane.showMessageDialog(this, 
                    "Password must be at least 6 characters long", 
                    "Validation Error", 
                    JOptionPane.ERROR_MESSAGE);
                passwordField.requestFocus();
                return;
            }
        }
        
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            
            // Check if student number already exists (excluding current student)
            String checkStudentQuery = "SELECT COUNT(*) FROM students WHERE student_number = ? AND student_id != ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkStudentQuery);
            checkStmt.setString(1, studentNumberField.getText().trim());
            checkStmt.setInt(2, currentStudentId);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next() && rs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Student number already exists!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Check if username already exists (excluding current user)
            String checkUserQuery = "SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?";
            PreparedStatement checkUserStmt = conn.prepareStatement(checkUserQuery);
            checkUserStmt.setString(1, usernameField.getText().trim());
            checkUserStmt.setInt(2, currentUserId);
            ResultSet userRs = checkUserStmt.executeQuery();
            
            if (userRs.next() && userRs.getInt(1) > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Username already exists!", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Start transaction
            conn.setAutoCommit(false);
            
            // Update user record
            String userQuery;
            PreparedStatement userStmt;
            
            if (passwordField.getPassword().length > 0) {
                // Update with new password
                userQuery = "UPDATE users SET username = ?, password = ?, full_name = ? WHERE user_id = ?";
                userStmt = conn.prepareStatement(userQuery);
                userStmt.setString(1, usernameField.getText().trim());
                userStmt.setString(2, new String(passwordField.getPassword()));
                userStmt.setString(3, firstNameField.getText().trim() + " " + lastNameField.getText().trim());
                userStmt.setInt(4, currentUserId);
            } else {
                // Update without changing password
                userQuery = "UPDATE users SET username = ?, full_name = ? WHERE user_id = ?";
                userStmt = conn.prepareStatement(userQuery);
                userStmt.setString(1, usernameField.getText().trim());
                userStmt.setString(2, firstNameField.getText().trim() + " " + lastNameField.getText().trim());
                userStmt.setInt(3, currentUserId);
            }
            
            userStmt.executeUpdate();
            
            // Update student record
            String studentQuery = "UPDATE students SET student_number = ?, first_name = ?, last_name = ?, " +
                                 "middle_name = ?, grade_level = ?, section = ?, qr_code = ? WHERE student_id = ?";
            PreparedStatement studentStmt = conn.prepareStatement(studentQuery);
            studentStmt.setString(1, studentNumberField.getText().trim());
            studentStmt.setString(2, firstNameField.getText().trim());
            studentStmt.setString(3, lastNameField.getText().trim());
            studentStmt.setString(4, middleNameField.getText().trim());
            studentStmt.setString(5, (String) gradeLevelCombo.getSelectedItem());
            studentStmt.setString(6, sectionField.getText().trim());
            studentStmt.setString(7, "QR_" + studentNumberField.getText().trim());
            studentStmt.setInt(8, currentStudentId);
            
            studentStmt.executeUpdate();
            
            // Commit transaction
            conn.commit();
            
            JOptionPane.showMessageDialog(this, 
                "Student updated successfully!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
            // Refresh student list
            loadStudents();
            clearForm();
            updateButton.setEnabled(false);
            
            // Refresh parent dashboard if needed
            if (parent != null) {
                parent.loadDashboardData();
            }
            
        } catch (SQLException e) {
            try {
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            
            JOptionPane.showMessageDialog(this, 
                "Error updating student: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void clearForm() {
        studentNumberField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        middleNameField.setText("");
        gradeLevelCombo.setSelectedIndex(0);
        sectionField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        currentStudentId = -1;
        currentUserId = -1;
    }
}
