package admin;

import common.DatabaseConnection;
import login.LoginForm;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Admin Dashboard - Main interface for administrators
 * Demonstrates OOP concepts: Encapsulation, Inheritance, and Data Structures
 */
public class AdminDashboard extends JFrame {
    
    // Encapsulation: Private fields with getters/setters
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51); // Dark teal matching teacher dashboard
    private static final Color WELCOME_BANNER_COLOR = new Color(91, 155, 213); // Light blue welcome banner
    private static final Color CARD_TITLE_COLOR = new Color(91, 155, 213); // Blue for card titles
    private String adminUsername;
    private String adminFullName;
    private List<String> recentActivities; // Data Structure: List for activities
    
    // UI Components
    private JPanel headerPanel;
    private JPanel sidebarPanel;
    private JPanel contentPanel;
    private JButton logoutButton;
    
    // Main navigation buttons
    private JButton dashboardButton;
    private JButton manageStudentsButton;
    private JButton manageTeachersButton;
    private JButton manageSubjectsButton;
    private JButton manageAssignmentsButton;
    
    /**
     * Constructor - Demonstrates Encapsulation
     * @param username Admin username
     * @param fullName Admin full name
     */
    public AdminDashboard(String username, String fullName) {
        this.adminUsername = username;
        this.adminFullName = fullName;
        this.recentActivities = new ArrayList<>(); // Data Structure initialization
        
        try {
            initComponents();
            setupEventHandlers();
            // Load data after UI is fully set up
            SwingUtilities.invokeLater(() -> {
                loadDashboardData();
            });
            System.out.println("✅ AdminDashboard initialization completed successfully");
        } catch (Exception e) {
            System.err.println("❌ Error initializing AdminDashboard: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Error initializing dashboard: " + e.getMessage(),
                "Initialization Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        System.out.println("🔄 Initializing AdminDashboard components...");
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Admin Dashboard - Attendance Monitoring System");
        setResizable(true);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        System.out.println("✅ Basic JFrame setup completed");
        
        // Initialize panels and components
        headerPanel = new JPanel();
        sidebarPanel = new JPanel();
        contentPanel = new JPanel();
        
        System.out.println("✅ Panels initialized");
        
        setupHeaderPanel();
        System.out.println("✅ Header panel setup completed");
        
        setupSidebarPanel();
        System.out.println("✅ Sidebar panel setup completed");
        
        setupContentPanel();
        System.out.println("✅ Content panel setup completed");
        
        // Set layout
        setLayout(new BorderLayout());
        add(headerPanel, BorderLayout.NORTH);
        add(sidebarPanel, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
        
        System.out.println("✅ Layout setup completed");
    }
    
    /**
     * Setup header panel with admin info
     */
    private void setupHeaderPanel() {
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(1200, 80));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel titleLabel = new JLabel("ADMIN DASHBOARD");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel subtitleLabel = new JLabel("ATTENDANCE MONITORING SYSTEM");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        logoutButton = new JButton(" LOGOUT ");
        logoutButton.setBackground(PRIMARY_COLOR);
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        headerPanel.add(logoutButton, BorderLayout.EAST);
    }
    
    /**
     * Setup sidebar panel with organized navigation buttons
     */
    private void setupSidebarPanel() {
        sidebarPanel.setBackground(new Color(240, 240, 240));
        sidebarPanel.setPreferredSize(new Dimension(280, 600));
        sidebarPanel.setLayout(new BorderLayout());
        
        // Main navigation panel
        JPanel mainNavPanel = new JPanel();
        mainNavPanel.setLayout(new BoxLayout(mainNavPanel, BoxLayout.Y_AXIS));
        mainNavPanel.setBackground(new Color(240, 240, 240));
        mainNavPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        
        // Create main navigation buttons
        dashboardButton = createMainNavButton("Dashboard");
        manageStudentsButton = createMainNavButton("Manage Students");
        manageTeachersButton = createMainNavButton("Manage Teachers");
        manageSubjectsButton = createMainNavButton("Manage Subjects");
        manageAssignmentsButton = createMainNavButton("Manage Assignments");
        
        // Add main navigation buttons
        addSidebarButton(mainNavPanel, dashboardButton);
        addSidebarButton(mainNavPanel, createSeparator());
        addSidebarButton(mainNavPanel, manageStudentsButton);
        addSidebarButton(mainNavPanel, createSeparator());
        addSidebarButton(mainNavPanel, manageTeachersButton);
        addSidebarButton(mainNavPanel, createSeparator());
        addSidebarButton(mainNavPanel, manageSubjectsButton);
        addSidebarButton(mainNavPanel, createSeparator());
        addSidebarButton(mainNavPanel, manageAssignmentsButton);
        
        sidebarPanel.add(mainNavPanel, BorderLayout.CENTER);
    }
    
    /**
     * Create main navigation button with consistent styling
     * @param text Button text
     * @return Styled JButton
     */
    private JButton createMainNavButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(240, 50));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFocusPainted(false);
        return button;
    }
    
    /**
     * Create a separator component
     * @return JPanel separator
     */
    private JPanel createSeparator() {
        JPanel separator = new JPanel();
        separator.setPreferredSize(new Dimension(240, 1));
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        separator.setBackground(new Color(180, 180, 180));
        separator.setAlignmentX(Component.CENTER_ALIGNMENT);
        return separator;
    }

    /**
     * Helper to add a sidebar button with spacing to a vertical panel
     */
    private void addSidebarButton(JPanel container, JButton button) {
        container.add(button);
        container.add(Box.createVerticalStrut(12));
    }
    
    /**
     * Helper to add a sidebar component with spacing to a vertical panel
     */
    private void addSidebarButton(JPanel container, JComponent component) {
        container.add(component);
        container.add(Box.createVerticalStrut(12));
    }
    
    /**
     * Setup content panel with dashboard information
     */
    private void setupContentPanel() {
        contentPanel.setBackground(new Color(240, 240, 240));
        contentPanel.setLayout(new BorderLayout());

        // Show dashboard content by default
        showDashboardContent();
    }
    
    /**
     * Show dashboard content in the main panel
     */
    private void showDashboardContent() {
        contentPanel.removeAll();
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        
        // Header Panel - Welcome Banner
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(WELCOME_BANNER_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        headerPanel.setLayout(new BorderLayout());
        
        JLabel welcomeLabel = new JLabel("Welcome, Administrator!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        
        JLabel dateLabel = new JLabel("Today: " + java.time.LocalDate.now().toString());
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(dateLabel, BorderLayout.SOUTH);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Load and display actual statistics
        String[] stats = getSystemStatistics();
        
        // Main content panel with proper spacing
        JPanel contentMainPanel = new JPanel();
        contentMainPanel.setLayout(new GridLayout(2, 2, 20, 20));
        contentMainPanel.setBackground(Color.WHITE);
        contentMainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // First row - Main statistics
        contentMainPanel.add(createStatCard("Total Students", extractNumber(stats[0])));
        contentMainPanel.add(createStatCard("Active Teachers", extractNumber(stats[1])));
        contentMainPanel.add(createStatCard("Total Subjects", extractNumber(stats[2])));
        contentMainPanel.add(createStatCard("Active Assignments", extractNumber(stats[3])));
        
        mainPanel.add(contentMainPanel, BorderLayout.CENTER);
        
        // Second row - Attendance statistics with proper spacing
        JPanel attendancePanel = new JPanel();
        attendancePanel.setLayout(new GridLayout(1, 3, 20, 0));
        attendancePanel.setBackground(Color.WHITE);
        attendancePanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 30, 20));
        
        attendancePanel.add(createStatCard("Today's Present", extractNumber(stats[4])));
        attendancePanel.add(createStatCard("Today's Late", extractNumber(stats[5])));
        attendancePanel.add(createStatCard("Today's Absent", extractNumber(stats[6])));
        
        // Add attendance panel below main content
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.add(attendancePanel, BorderLayout.CENTER);
        
        // Create a wrapper for all content
        JPanel allContentPanel = new JPanel(new BorderLayout());
        allContentPanel.setBackground(Color.WHITE);
        allContentPanel.add(contentMainPanel, BorderLayout.CENTER);
        allContentPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        mainPanel.add(allContentPanel, BorderLayout.CENTER);
        
        contentPanel.add(mainPanel, BorderLayout.CENTER);
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    /**
     * Extract number from statistics string
     */
    private String extractNumber(String statString) {
        if (statString == null) return "0";
        String[] parts = statString.split(": ");
        return parts.length > 1 ? parts[1] : "0";
    }

  
    
    private JPanel createStatCard(String title, String value){
        JPanel card = new JPanel();
        card.setLayout(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(CARD_TITLE_COLOR);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(titleLabel, BorderLayout.NORTH);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        valueLabel.setForeground(PRIMARY_COLOR);
        valueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }

    private int getCount(String sql){
        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)){
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                int count = rs.getInt(1);
                System.out.println("✅ Query result for '" + sql + "': " + count);
                return count;
            }
        }catch(Exception e){
            System.err.println("❌ Error executing query '" + sql + "': " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * Load dashboard data from database
     * Demonstrates Data Structure usage with Arrays and Lists
     */
    public void loadDashboardData() {
        System.out.println("🔄 Loading dashboard data...");
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                System.out.println("✅ Database connection established");
                // Get system statistics
                String[] stats = getSystemStatistics(); // Data Structure: Array
                System.out.println("✅ Statistics loaded: " + java.util.Arrays.toString(stats));
                
                // Dashboard data loaded successfully
                System.out.println("✅ Dashboard data loaded successfully");
            } else {
                System.err.println("❌ Database connection is null");
            }
        } catch (Exception e) {
            System.err.println("❌ Error loading dashboard data: " + e.getMessage());
            e.printStackTrace();
            // Don't show error dialog during initialization to avoid blocking UI
            System.out.println("⚠️ Continuing with default data due to error");
        }
    }
    
    /**
     * Get system statistics
     * @return Array of statistics
     */
    private String[] getSystemStatistics() {
        String[] stats = new String[7]; // Data Structure: Array
        try {
            // Get student count
            int studentCount = getCount("SELECT COUNT(*) FROM students WHERE is_active = 1");
            stats[0] = "Students: " + studentCount;
            
            // Get teacher count
            int teacherCount = getCount("SELECT COUNT(*) FROM teachers WHERE is_active = 1");
            stats[1] = "Teachers: " + teacherCount;
            
            // Get subjects count
            int subjectCount = getCount("SELECT COUNT(*) FROM subjects WHERE is_active = 1");
            stats[2] = "Subjects: " + subjectCount;
            
            // Get assignments count
            int assignmentCount = getCount("SELECT COUNT(*) FROM teacher_assignments WHERE is_active = 1");
            stats[3] = "Assignments: " + assignmentCount;
            
            // Get today's present count
            int presentCount = getCount("SELECT COUNT(*) FROM attendance_records WHERE attendance_date = CURDATE() AND status = 'Present'");
            stats[4] = "Today's Present: " + presentCount;
            
            // Get today's late count
            int lateCount = getCount("SELECT COUNT(*) FROM attendance_records WHERE attendance_date = CURDATE() AND status = 'Late'");
            stats[5] = "Today's Late: " + lateCount;
            
            // Get today's absent count
            int absentCount = getCount("SELECT COUNT(*) FROM attendance_records WHERE attendance_date = CURDATE() AND status = 'Absent'");
            stats[6] = "Today's Absent: " + absentCount;
            
            System.out.println("✅ Statistics loaded successfully:");
            System.out.println("  - Students: " + studentCount);
            System.out.println("  - Teachers: " + teacherCount);
            System.out.println("  - Subjects: " + subjectCount);
            System.out.println("  - Assignments: " + assignmentCount);
            System.out.println("  - Today's Present: " + presentCount);
            System.out.println("  - Today's Late: " + lateCount);
            System.out.println("  - Today's Absent: " + absentCount);
            
        } catch (Exception e) {
            System.err.println("❌ Error getting statistics: " + e.getMessage());
            e.printStackTrace();
            // Set default values if there's an error
            stats[0] = "Students: 0";
            stats[1] = "Teachers: 0";
            stats[2] = "Subjects: 0";
            stats[3] = "Assignments: 0";
            stats[4] = "Today's Present: 0";
            stats[5] = "Today's Late: 0";
            stats[6] = "Today's Absent: 0";
        }
        
        return stats;
    }
    
    
    /**
     * Setup event handlers for all buttons
     */
    private void setupEventHandlers() {
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logoutButtonActionPerformed(e);
            }
        });
        
        dashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dashboardButtonActionPerformed(e);
            }
        });
        
        manageStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manageStudentsButtonActionPerformed(e);
            }
        });
        
        manageTeachersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manageTeachersButtonActionPerformed(e);
            }
        });
        
        manageSubjectsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manageSubjectsButtonActionPerformed(e);
            }
        });
        
        manageAssignmentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                manageAssignmentsButtonActionPerformed(e);
            }
        });
    }
    
    // Event Handlers
    private void logoutButtonActionPerformed(ActionEvent evt) {
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?",
            "Logout Confirmation",
            JOptionPane.YES_NO_OPTION);
            
        if (choice == JOptionPane.YES_OPTION) {
            // Close current window and return to login
            this.dispose();
            
            // Show login form
            SwingUtilities.invokeLater(() -> {
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true);
            });
        }
    }
    
    private void dashboardButtonActionPerformed(ActionEvent evt) {
        // Show dashboard content
        showDashboardContent();
    }
    
    private void manageStudentsButtonActionPerformed(ActionEvent evt) {
        // Show student management options
        String[] options = {"Add Student", "View Students", "Update Student", "Remove Student"};
        int choice = JOptionPane.showOptionDialog(this,
            "Choose a student management option:",
            "Manage Students",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
        
        switch (choice) {
            case 0: 
        SwingUtilities.invokeLater(() -> {
            AddStudentDialog addStudentDialog = new AddStudentDialog(this);
            addStudentDialog.setVisible(true);
        });
                break;
            case 1: 
        SwingUtilities.invokeLater(() -> {
                    ViewStudentsForm viewStudentsForm = new ViewStudentsForm();
                    viewStudentsForm.setVisible(true);
                });
                break;
            case 2: 
        SwingUtilities.invokeLater(() -> {
            UpdateStudentDialog updateStudentDialog = new UpdateStudentDialog(this);
            updateStudentDialog.setVisible(true);
        });
                break;
            case 3: 
            SwingUtilities.invokeLater(() -> {
                    RemoveStudentDialog removeStudentDialog = new RemoveStudentDialog(this);
                    removeStudentDialog.setVisible(true);
                });
                break;
        }
    }
    
    private void manageTeachersButtonActionPerformed(ActionEvent evt) {
        // Show teacher management options
        String[] options = {"Add Teacher", "View Teachers", "Update Teacher", "Remove Teacher"};
        int choice = JOptionPane.showOptionDialog(this,
            "Choose a teacher management option:",
            "Manage Teachers",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
        
        switch (choice) {
            case 0: 
        SwingUtilities.invokeLater(() -> {
            AddTeacherDialog addTeacherDialog = new AddTeacherDialog(this);
            addTeacherDialog.setVisible(true);
        });
                break;
            case 1: 
                SwingUtilities.invokeLater(() -> {
                    ViewTeachersForm viewTeachersForm = new ViewTeachersForm();
                    viewTeachersForm.setVisible(true);
                });
                break;
            case 2: 
                SwingUtilities.invokeLater(() -> {
                    UpdateTeacherDialog updateTeacherDialog = new UpdateTeacherDialog(this);
                    updateTeacherDialog.setVisible(true);
                });
                break;
            case 3: 
        SwingUtilities.invokeLater(() -> {
            RemoveTeacherDialog removeTeacherDialog = new RemoveTeacherDialog(this);
            removeTeacherDialog.setVisible(true);
        });
                break;
        }
    }
    
    private void manageSubjectsButtonActionPerformed(ActionEvent evt) {
        // Show subject management options
        String[] options = {"Add Subject", "View Subjects", "Update Subject", "Remove Subject"};
        int choice = JOptionPane.showOptionDialog(this,
            "Choose a subject management option:",
            "Manage Subjects",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            options,
            options[0]);
        
        switch (choice) {
            case 0: 
                SwingUtilities.invokeLater(() -> {
                    AddSubjectDialog addSubjectDialog = new AddSubjectDialog(this);
                    addSubjectDialog.setVisible(true);
                });
                break;
            case 1: 
                SwingUtilities.invokeLater(() -> {
                    ViewSubjectsForm viewSubjectsForm = new ViewSubjectsForm();
                    viewSubjectsForm.setVisible(true);
                });
                break;
            case 2: 
        SwingUtilities.invokeLater(() -> {
                    UpdateSubjectDialog updateSubjectDialog = new UpdateSubjectDialog(this);
                    updateSubjectDialog.setVisible(true);
                });
                break;
            case 3: 
        SwingUtilities.invokeLater(() -> {
                    RemoveSubjectDialog removeSubjectDialog = new RemoveSubjectDialog(this);
                    removeSubjectDialog.setVisible(true);
        });
                break;
        }
    }
    
    private void manageAssignmentsButtonActionPerformed(ActionEvent evt) {
        // Open Manage Assignments form
        SwingUtilities.invokeLater(() -> {
            ManageAssignmentsForm manageAssignmentsForm = new ManageAssignmentsForm();
            manageAssignmentsForm.setVisible(true);
        });
        System.out.println("Admin accessed Manage Assignments function");
    }
    
    
    // Getter methods (Encapsulation)
    public String getAdminUsername() {
        return adminUsername;
    }
    
    public String getAdminFullName() {
        return adminFullName;
    }
    
    public List<String> getRecentActivities() {
        return new ArrayList<>(recentActivities); // Return copy to maintain encapsulation
    }
    
    // Setter methods (Encapsulation)
    public void setAdminUsername(String adminUsername) {
        this.adminUsername = adminUsername;
    }
    
    public void setAdminFullName(String adminFullName) {
        this.adminFullName = adminFullName;
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AdminDashboard dashboard = new AdminDashboard("admin", "System Administrator");
            dashboard.setVisible(true);
        });
    }
}
