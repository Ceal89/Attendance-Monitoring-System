package admin;

import common.DatabaseConnection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * RemoveStudentDialog - Dialog for removing students with table view
 */
public class RemoveStudentDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // UI Components
    private JTable studentsTable;
    private DefaultTableModel tableModel;
    private JTextArea reasonArea;
    private JButton removeButton;
    private JButton refreshButton;
    private JButton cancelButton;
    
 
    
    // Table columns
    private static final String[] COLUMN_NAMES = {
        "Student ID", "Student Number", "Full Name", "Grade Level", "Section", "Username", "Created At"
    };
    
    public RemoveStudentDialog(AdminDashboard parent) {
        super(parent, "Remove Student", true);
     
        
        initComponents();
        setupEventHandlers();
        loadStudents();
        
        setSize(800, 600);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(800, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Remove Student");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        tablePanel.setBackground(Color.WHITE);
        
        // Add title and instructions for table
        JPanel titlePanel = new JPanel(new BorderLayout());
        JLabel tableTitleLabel = new JLabel("Students List");
        tableTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableTitleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
        
        JLabel instructionLabel = new JLabel("Select a student from the table below to remove:");
        instructionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        instructionLabel.setForeground(new Color(100, 100, 100));
        
        titlePanel.add(tableTitleLabel, BorderLayout.NORTH);
        titlePanel.add(instructionLabel, BorderLayout.SOUTH);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        tablePanel.add(titlePanel, BorderLayout.NORTH);
        
        // Initialize table model
        tableModel = new DefaultTableModel(COLUMN_NAMES, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        
        studentsTable = new JTable(tableModel);
        studentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentsTable.setRowHeight(25);
        studentsTable.getTableHeader().setReorderingAllowed(false);
        
        // Set column widths
        studentsTable.getColumnModel().getColumn(0).setPreferredWidth(80);   // Student ID
        studentsTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // Student Number
        studentsTable.getColumnModel().getColumn(2).setPreferredWidth(150);  // Full Name
        studentsTable.getColumnModel().getColumn(3).setPreferredWidth(100);  // Grade Level
        studentsTable.getColumnModel().getColumn(4).setPreferredWidth(100);  // Section
        studentsTable.getColumnModel().getColumn(5).setPreferredWidth(100);  // Username
        studentsTable.getColumnModel().getColumn(6).setPreferredWidth(150);  // Created At
        
        JScrollPane scrollPane = new JScrollPane(studentsTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Reason panel
        JPanel reasonPanel = new JPanel(new BorderLayout());
        reasonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        reasonPanel.setBackground(Color.WHITE);
        
        JLabel reasonLabel = new JLabel("Reason for Removal:");
        reasonLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        reasonPanel.add(reasonLabel, BorderLayout.NORTH);
        
        reasonArea = new JTextArea(3, 50);
        reasonArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        reasonArea.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        reasonPanel.add(new JScrollPane(reasonArea), BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        refreshButton = new JButton("Refresh");
        refreshButton.setBackground(new Color(33, 150, 243));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshButton.setPreferredSize(new Dimension(100, 35));
        
        removeButton = new JButton("Remove Student");
        removeButton.setBackground(new Color(244, 67, 54));
        removeButton.setForeground(Color.WHITE);
        removeButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        removeButton.setPreferredSize(new Dimension(140, 35));
        removeButton.setEnabled(false);
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(158, 158, 158));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        cancelButton.setPreferredSize(new Dimension(100, 35));
        
        buttonPanel.add(refreshButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(cancelButton);
        
        // Create main content panel
        JPanel mainContentPanel = new JPanel(new BorderLayout());
        mainContentPanel.setBackground(Color.WHITE);
        mainContentPanel.add(tablePanel, BorderLayout.CENTER);
        mainContentPanel.add(reasonPanel, BorderLayout.SOUTH);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(mainContentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadStudents();
            }
        });
        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeStudent();
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        
        // Enable/disable remove button based on selection
        studentsTable.getSelectionModel().addListSelectionListener(e -> {
            boolean hasSelection = studentsTable.getSelectedRow() >= 0;
            removeButton.setEnabled(hasSelection);
        });
    }
    
    private void loadStudents() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database. Please check your database connection.", 
                    "Database Connection Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String query = "SELECT s.student_id, s.student_number, s.first_name, s.last_name, s.middle_name, " +
                          "s.grade_level, s.section, u.username, s.created_at " +
                          "FROM students s " +
                          "LEFT JOIN users u ON s.user_id = u.user_id " +
                          "WHERE s.is_active = 1 ORDER BY s.student_number";
            
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                
                while (rs.next()) {
                    String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
                    if (rs.getString("middle_name") != null && !rs.getString("middle_name").trim().isEmpty()) {
                        fullName = rs.getString("first_name") + " " + rs.getString("middle_name") + " " + rs.getString("last_name");
                    }
                    
                    Object[] row = {
                        rs.getInt("student_id"),
                        rs.getString("student_number"),
                        fullName,
                        rs.getString("grade_level"),
                        rs.getString("section"),
                        rs.getString("username"),
                        rs.getTimestamp("created_at")
                    };
                    
                    tableModel.addRow(row);
                }
                
                System.out.println("✅ Loaded " + tableModel.getRowCount() + " students successfully");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading students: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Error loading students: " + e.getMessage(),
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void removeStudent() {
        int selectedRow = studentsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, 
                "Please select a student to remove", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get student information
        int studentId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String studentNumber = (String) tableModel.getValueAt(selectedRow, 1);
        String fullName = (String) tableModel.getValueAt(selectedRow, 2);
        String reason = reasonArea.getText().trim();
        
        if (reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please provide a reason for removal", 
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Confirm removal
        int choice = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove this student?\n\n" +
            "Student Number: " + studentNumber + "\n" +
            "Name: " + fullName + "\n" +
            "Reason: " + reason + "\n\n" +
            "This action will deactivate the student account!",
            "Confirm Student Removal",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (choice == JOptionPane.YES_OPTION) {
            try (Connection conn = DatabaseConnection.getConnection()) {
                if (conn == null) {
                    JOptionPane.showMessageDialog(this, 
                        "Cannot connect to database", 
                        "Database Error", 
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                conn.setAutoCommit(false);
                
                try {
                    // Soft delete student
                    String studentQuery = "UPDATE students SET is_active = 0 WHERE student_id = ?";
                    try (PreparedStatement studentStmt = conn.prepareStatement(studentQuery)) {
                        studentStmt.setInt(1, studentId);
                        int studentResult = studentStmt.executeUpdate();
                        
                        if (studentResult == 0) {
                            throw new SQLException("Failed to remove student");
                        }
                    }
                    
                    // Deactivate user account
                    String userQuery = "UPDATE users SET is_active = 0 WHERE user_id = (SELECT user_id FROM students WHERE student_id = ?)";
                    try (PreparedStatement userStmt = conn.prepareStatement(userQuery)) {
                        userStmt.setInt(1, studentId);
                        userStmt.executeUpdate();
                    }
                    
                    conn.commit();
                    
                    JOptionPane.showMessageDialog(this, 
                        "Student removed successfully!", 
                        "Success", 
                        JOptionPane.INFORMATION_MESSAGE);
                    
                    // Refresh the table
                    loadStudents();
                    reasonArea.setText("");
                    removeButton.setEnabled(false);
                    
                } catch (SQLException e) {
                    conn.rollback();
                    throw e;
                } finally {
                    conn.setAutoCommit(true);
                }
                
            } catch (SQLException e) {
                System.err.println("❌ Error removing student: " + e.getMessage());
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, 
                    "Error removing student: " + e.getMessage(),
                    "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}