package login;

import common.DatabaseConnection;
import admin.AdminDashboard;
import student.StudentDashboard;
import teacher.TeacherDashboard;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Enhanced Login Form with Role-based Authentication
 * Demonstrates OOP concepts: Encapsulation, Inheritance, Polymorphism
 * Demonstrates Data Structures: Arrays, Lists
 */
public class LoginForm extends JFrame {
    
    // Encapsulation: Private fields
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton LoginButton;
    private JButton BackButton;
    private JCheckBox ShowPasswordCheckBox;
    private JLabel statusLabel;
    private List<String> loginHistory; // Data Structure: List for login history
    
   
    
    /**
     * Constructor
     */
    public LoginForm() {
        this.loginHistory = new ArrayList<>(); // Data Structure initialization
        
        initComponents();
        setupEventHandlers();
        loadLoginHistory();
    }
    
    /**
     * Initialize UI components
     */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Attendance Monitoring System - Login");
        setResizable(false);
        setSize(500, 600);
        setLocationRelativeTo(null);
        
        // Initialize NetBeans form components
        initForm();
    }
    
    /**
     * Initialize NetBeans form components
     */
    private void initForm() {
        // Create components that are defined in the .form file
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        LoginButton = new JButton("Login");
        BackButton = new JButton("Back");
        ShowPasswordCheckBox = new JCheckBox("Show Password");
        statusLabel = new JLabel("Ready to login");
        
        // Set up the form layout manually since NetBeans form isn't auto-initializing
        setupFormLayout();
    }
    
    /**
     * Setup form layout manually
     */
    private void setupFormLayout() {
        setLayout(new BorderLayout());
        
        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(240, 240, 240));
        
        // Header panel with icon and title
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setPreferredSize(new Dimension(500, 80));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        JLabel titleLabel = new JLabel("ATTENDANCE MONITORING SYSTEM");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JLabel subtitleLabel = new JLabel("Please login to continue");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BorderLayout());
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel, BorderLayout.NORTH);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(new Color(240, 240, 240));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Sign In title
        JLabel signInLabel = new JLabel("Sign In");
        signInLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        signInLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(signInLabel, gbc);
        
        // Username field
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.WEST;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        formPanel.add(usernameLabel, gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        usernameField.setPreferredSize(new Dimension(254, 30));
        formPanel.add(usernameField, gbc);
        
        // Password field
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        formPanel.add(passwordLabel, gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        passwordField.setPreferredSize(new Dimension(254, 30));
        formPanel.add(passwordField, gbc);
        
        // Show password checkbox
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.fill = GridBagConstraints.NONE;
        ShowPasswordCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        formPanel.add(ShowPasswordCheckBox, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 20));
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        LoginButton.setBackground(PRIMARY_COLOR);
        LoginButton.setForeground(Color.WHITE);
        LoginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        LoginButton.setPreferredSize(new Dimension(120, 40));
        LoginButton.setFocusPainted(false);
        
        BackButton.setBackground(PRIMARY_COLOR);
        BackButton.setForeground(Color.WHITE);
        BackButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        BackButton.setPreferredSize(new Dimension(120, 40));
        BackButton.setFocusPainted(false);
        
        buttonPanel.add(BackButton);
        buttonPanel.add(LoginButton);
        
        // Status panel
        JPanel statusPanel = new JPanel();
        statusPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        statusPanel.setBackground(new Color(240, 240, 240));
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(100, 100, 100));
        statusPanel.add(statusLabel);
        
        // Create a container panel for button and status
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.setBackground(new Color(240, 240, 240));
        bottomPanel.add(buttonPanel, BorderLayout.CENTER);
        bottomPanel.add(statusPanel, BorderLayout.SOUTH);
        
        // Add panels to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
    }
    
    
    /**
     * Setup event handlers
     */
    private void setupEventHandlers() {
        if (LoginButton != null) {
            LoginButton.addActionListener(e -> LoginButtonActionPerformed(e));
        }
        if (BackButton != null) {
            BackButton.addActionListener(e -> BackButtonActionPerformed(e));
        }
        
        // Enter key listener for login
        ActionListener loginAction = e -> LoginButtonActionPerformed(e);
        usernameField.addActionListener(loginAction);
        passwordField.addActionListener(loginAction);
        
        // Show password checkbox listener
        if (ShowPasswordCheckBox != null) {
            ShowPasswordCheckBox.addActionListener(e -> ShowPasswordCheckBoxActionPerformed(e));
        }
    }
    
    /**
     * Load login history from database
     * Demonstrates Data Structure: List usage
     */
    private void loadLoginHistory() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                // Activity logs disabled - activity_logs table not available in current database
                String query = "SELECT username, created_at FROM users " +
                              "WHERE user_type IN ('admin', 'teacher', 'student') " +
                              "ORDER BY created_at DESC LIMIT 5";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();
                
                loginHistory.clear(); // Clear existing history
                while (rs.next()) {
                    String historyEntry = rs.getString("username") + " - " + rs.getTimestamp("created_at");
                    loginHistory.add(historyEntry); // Add to List
                }
                
                rs.close();
                stmt.close();
                
                System.out.println("✅ Loaded " + loginHistory.size() + " recent logins");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error loading login history: " + e.getMessage());
            // Initialize empty history if table doesn't exist
            loginHistory.clear();
        }
    }
    
    /**
     * Authenticate user credentials
     * Demonstrates Data Structure manipulation
     * @param username Username
     * @param password Password
     * @return Authentication result
     */
    private AuthenticationResult authenticateUser(String username, String password) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                System.out.println("🔄 Authenticating user: " + username);
                
                // First, get user info without password comparison
                String query = "SELECT u.user_id, u.username, u.password, u.full_name, u.user_type, u.is_active, " +
                              "COALESCE(s.student_id, t.teacher_id, NULL) as specific_id " +
                              "FROM users u " +
                              "LEFT JOIN students s ON u.user_id = s.user_id " +
                              "LEFT JOIN teachers t ON u.user_id = t.user_id " +
                              "WHERE u.username = ? AND u.is_active = 1";
                
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    String storedPassword = rs.getString("password");
                    System.out.println("✅ User found: " + username + ", Role: " + rs.getString("user_type"));
                    System.out.println("🔍 Comparing passwords...");
                    
                    // Compare passwords (assuming plain text for now)
                    if (password.equals(storedPassword)) {
                        String role = rs.getString("user_type");
                        System.out.println("✅ Password match! Role: " + role);
                        
                        // Log successful login
                        logLoginAttempt(username, role, true);
                        
                        // Add to login history (Data Structure)
                        String historyEntry = username + " (" + role + ") - " + new java.util.Date();
                        loginHistory.add(0, historyEntry); // Add to beginning of List
                        if (loginHistory.size() > 10) {
                            loginHistory.remove(loginHistory.size() - 1); // Remove last entry if more than 10
                        }
                        
                        int specificId = rs.getInt("specific_id");
                        System.out.println("🔍 Authentication result - User ID: " + rs.getInt("user_id") + 
                                         ", Specific ID: " + specificId + ", Role: " + role);
                        
                        return new AuthenticationResult(true, rs.getString("full_name"), username,
                                                      rs.getInt("user_id"), 
                                                      specificId, role);
                    } else {
                        System.out.println("❌ Password mismatch");
                        logLoginAttempt(username, "unknown", false);
                        return new AuthenticationResult(false, null, null, -1, -1, null);
                    }
                } else {
                    System.out.println("❌ User not found or inactive: " + username);
                    logLoginAttempt(username, "unknown", false);
                    return new AuthenticationResult(false, null, null, -1, -1, null);
                }
                
            }
        } catch (SQLException e) {
            System.err.println("❌ Authentication error: " + e.getMessage());
            e.printStackTrace();
            return new AuthenticationResult(false, null, null, -1, -1, null);
        }
        
        return new AuthenticationResult(false, null, null, -1, -1, null);
    }
    
    /**
     * Log login attempt to audit trail
     * @param username Username
     * @param role User role
     * @param success Whether login was successful
     */
    private void logLoginAttempt(String username, String role, boolean success) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            // Activity logging disabled - activity_logs table not available in current database
            String query = "SELECT 1"; // Dummy query to avoid errors
            
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.executeQuery(); // Execute dummy query
            stmt.close();
            
            // Log to console instead
            System.out.println("Login attempt: " + username + " (" + role + ") - " + 
                             (success ? "SUCCESS" : "FAILED"));
            
        } catch (SQLException e) {
            System.err.println("❌ Error logging login attempt: " + e.getMessage());
            // Don't fail authentication if logging fails
        }
    }
    
 
    // Event Handlers
    private void LoginButtonActionPerformed(ActionEvent evt) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Please enter username and password");
            statusLabel.setForeground(Color.RED);
            return;
        }
        
        statusLabel.setText("Authenticating...");
        statusLabel.setForeground(Color.BLUE);
        
        // Authenticate user
        AuthenticationResult result = authenticateUser(username, password);
        
        if (result.isSuccess()) {
            statusLabel.setText("Login successful!");
            statusLabel.setForeground(Color.GREEN);
            
            // Hide login form
            this.setVisible(false);
            
            // Open appropriate dashboard based on role
            openDashboard(result);
            
        } else {
            statusLabel.setText("Invalid credentials");
            statusLabel.setForeground(Color.RED);
            passwordField.setText("");
            usernameField.requestFocus();
        }
    }
    
    private void BackButtonActionPerformed(ActionEvent evt) {
        usernameField.setText("");
        passwordField.setText("");
        statusLabel.setText("Ready to login");
        statusLabel.setForeground(new Color(100, 100, 100));
        usernameField.requestFocus();
    }
    
  
    
    private void ShowPasswordCheckBoxActionPerformed(ActionEvent evt) {
        // Handle show password checkbox
        if (ShowPasswordCheckBox != null && ShowPasswordCheckBox.isSelected()) {
            passwordField.setEchoChar((char) 0); // Show password
        } else {
            passwordField.setEchoChar('*'); // Hide password
        }
    }
    
 
    /**
     * Open appropriate dashboard based on user role
     * Demonstrates Polymorphism - different dashboards for different roles
     * @param result Authentication result
     */
    private void openDashboard(AuthenticationResult result) {
        SwingUtilities.invokeLater(() -> {
            switch (result.getRole()) {
                case "admin":
                    // Use getUserId() for admin operations and logging
                    System.out.println("Admin login - User ID: " + result.getUserId());
                    System.out.println("🔄 Creating AdminDashboard...");
                    AdminDashboard adminDashboard = new AdminDashboard(result.getUsername(), result.getFullName());
                    System.out.println("✅ AdminDashboard created, setting visible...");
                    adminDashboard.setVisible(true);
                    System.out.println("✅ AdminDashboard should now be visible");
                    break;
                    
                case "teacher":
                    // Use getUserId() for teacher operations and logging
                    System.out.println("Teacher login - User ID: " + result.getUserId() + ", Teacher ID: " + result.getSpecificId());
                    TeacherDashboard teacherDashboard = new TeacherDashboard(result.getSpecificId(), result.getUsername(), result.getFullName());
                    teacherDashboard.setVisible(true);
                    break;
                    
                case "student":
                    // Use getUserId() for student operations and logging
                    System.out.println("Student login - User ID: " + result.getUserId() + ", Student ID: " + result.getSpecificId());
                    StudentDashboard studentDashboard = new StudentDashboard(result.getSpecificId(), result.getUsername(), result.getFullName());
                    studentDashboard.setVisible(true);
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(this, "Unknown role: " + result.getRole(),
                                                "Error", JOptionPane.ERROR_MESSAGE);
                    this.setVisible(true);
                    break;
            }
        });
    }
    
    /**
     * Get login history (for external access)
     * @return Copy of login history
     */
    public List<String> getLoginHistory() {
        return new ArrayList<>(loginHistory); // Return copy to maintain encapsulation
    }
    
    /**
     * Inner class to represent authentication result - Demonstrates Encapsulation
     */
    private static class AuthenticationResult {
        private boolean success;
        private String fullName;
        private String username;
        private int userId;
        private int specificId;
        private String role;
        
        public AuthenticationResult(boolean success, String fullName, String username, int userId, int specificId, String role) {
            this.success = success;
            this.fullName = fullName;
            this.username = username;
            this.userId = userId;
            this.specificId = specificId;
            this.role = role;
        }
        
        // Getter methods (Encapsulation)
        public boolean isSuccess() { return success; }
        public String getFullName() { return fullName; }
        public String getUsername() { return username; }
        public int getUserId() { return userId; }
        public int getSpecificId() { return specificId; }
        public String getRole() { return role; }
    }
    
    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        });
    }
}
