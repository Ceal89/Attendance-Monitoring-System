package admin;

import common.DatabaseConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Update Subject Dialog
 * Allows admin to update existing subjects
 */
public class UpdateSubjectDialog extends JDialog {
    
    private static final Color PRIMARY_COLOR = new Color(0, 51, 51);
    
    // Form fields
    private JComboBox<String> subjectCombo;
    private JTextField subjectCodeField;
    private JTextField subjectNameField;
    private JTextArea descriptionArea;
    private JComboBox<String> strandCombo;
    private JComboBox<String> gradeLevelCombo;
    private JTextField unitsField;
    
    // Buttons
    private JButton updateButton;
    private JButton cancelButton;
    
    // Panels
    private JPanel headerPanel;
    private JPanel formPanel;
    private JPanel buttonPanel;
    

    
    public UpdateSubjectDialog(AdminDashboard parent) {
        super(parent, "Update Subject", true);
      
        
        initComponents();
        setupEventHandlers();
        loadSubjects();
        
        setSize(600, 600);
        setLocationRelativeTo(parent);
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        headerPanel = new JPanel();
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Update Subject");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        add(headerPanel, BorderLayout.NORTH);
        
        // Main form panel
        formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Subject Selection
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Select Subject:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        subjectCombo = new JComboBox<>();
        subjectCombo.setPreferredSize(new Dimension(300, 25));
        formPanel.add(subjectCombo, gbc);
        
        // Subject Code
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Subject Code:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        subjectCodeField = new JTextField(20);
        formPanel.add(subjectCodeField, gbc);
        
        // Subject Name
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Subject Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        subjectNameField = new JTextField(20);
        formPanel.add(subjectNameField, gbc);
        
        // Description
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.BOTH; gbc.weightx = 1.0; gbc.weighty = 1.0;
        descriptionArea = new JTextArea(3, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        JScrollPane descriptionScroll = new JScrollPane(descriptionArea);
        formPanel.add(descriptionScroll, gbc);
        
        // Strand
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0; gbc.weighty = 0;
        formPanel.add(new JLabel("Strand:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        strandCombo = new JComboBox<>(new String[]{"STEM", "HUMSS", "ABM", "TVL", "General"});
        formPanel.add(strandCombo, gbc);
        
        // Grade Level
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Grade Level:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        gradeLevelCombo = new JComboBox<>(new String[]{"Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"});
        formPanel.add(gradeLevelCombo, gbc);
        
        // Units
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Units:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        unitsField = new JTextField(20);
        formPanel.add(unitsField, gbc);
        
        add(formPanel, BorderLayout.CENTER);
        
        // Button panel
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);
        
        updateButton = new JButton("Update Subject");
        updateButton.setBackground(new Color(0, 128, 0));
        updateButton.setForeground(Color.WHITE);
        updateButton.setFocusPainted(false);
        updateButton.setPreferredSize(new Dimension(120, 35));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(128, 128, 128));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(cancelButton);
        buttonPanel.add(updateButton);
        
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        subjectCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadSelectedSubjectData();
            }
        });
        
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateButtonActionPerformed(e);
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonActionPerformed(e);
            }
        });
    }
    
    private void loadSubjects() {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Connection Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String query = "SELECT subject_id, subject_code, subject_name FROM subjects WHERE is_active = 1 ORDER BY subject_code";
            
            try (PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                
                subjectCombo.removeAllItems();
                subjectCombo.addItem("-- Select Subject --");
                
                while (rs.next()) {
                    String displayText = rs.getString("subject_code") + " - " + rs.getString("subject_name");
                    subjectCombo.addItem(displayText);
                }
                
                System.out.println("✅ Loaded " + (subjectCombo.getItemCount() - 1) + " subjects successfully");
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading subjects: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading subjects: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadSelectedSubjectData() {
        if (subjectCombo.getSelectedIndex() <= 0) {
            clearFields();
            return;
        }
        
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Connection Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String selectedText = (String) subjectCombo.getSelectedItem();
            String subjectCode = selectedText.split(" - ")[0];
            
            String query = "SELECT subject_code, subject_name, description, strand, grade_level, units FROM subjects WHERE subject_code = ? AND is_active = 1";
            
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, subjectCode);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        subjectCodeField.setText(rs.getString("subject_code"));
                        subjectNameField.setText(rs.getString("subject_name"));
                        descriptionArea.setText(rs.getString("description") != null ? rs.getString("description") : "");
                        strandCombo.setSelectedItem(rs.getString("strand"));
                        gradeLevelCombo.setSelectedItem(rs.getString("grade_level"));
                        unitsField.setText(rs.getString("units"));
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error loading subject data: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Error loading subject data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearFields() {
        subjectCodeField.setText("");
        subjectNameField.setText("");
        descriptionArea.setText("");
        strandCombo.setSelectedIndex(0);
        gradeLevelCombo.setSelectedIndex(0);
        unitsField.setText("1.0");
    }
    
    private void updateButtonActionPerformed(ActionEvent evt) {
        if (subjectCombo.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a subject to update.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validate input
        if (subjectCodeField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a subject code.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            subjectCodeField.requestFocus();
            return;
        }
        
        if (subjectNameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a subject name.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            subjectNameField.requestFocus();
            return;
        }
        
        // Validate units
        double units;
        try {
            units = Double.parseDouble(unitsField.getText().trim());
            if (units <= 0) {
                JOptionPane.showMessageDialog(this, "Units must be a positive number.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                unitsField.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for units.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            unitsField.requestFocus();
            return;
        }
        
        // Update subject in database
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                String selectedText = (String) subjectCombo.getSelectedItem();
                String originalSubjectCode = selectedText.split(" - ")[0];
                String newSubjectCode = subjectCodeField.getText().trim();
                
                // Check if new subject code already exists (if changed)
                if (!originalSubjectCode.equals(newSubjectCode)) {
                    String checkQuery = "SELECT COUNT(*) FROM subjects WHERE subject_code = ? AND is_active = 1";
                    try (PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {
                        checkStmt.setString(1, newSubjectCode);
                        try (ResultSet rs = checkStmt.executeQuery()) {
                            if (rs.next() && rs.getInt(1) > 0) {
                                JOptionPane.showMessageDialog(this, "Subject code already exists. Please use a different code.", "Duplicate Error", JOptionPane.ERROR_MESSAGE);
                                subjectCodeField.requestFocus();
                                return;
                            }
                        }
                    }
                }
                
                // Update subject
                String updateQuery = "UPDATE subjects SET subject_code = ?, subject_name = ?, description = ?, strand = ?, grade_level = ?, units = ? WHERE subject_code = ? AND is_active = 1";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                    updateStmt.setString(1, newSubjectCode);
                    updateStmt.setString(2, subjectNameField.getText().trim());
                    updateStmt.setString(3, descriptionArea.getText().trim());
                    updateStmt.setString(4, (String) strandCombo.getSelectedItem());
                    updateStmt.setString(5, (String) gradeLevelCombo.getSelectedItem());
                    updateStmt.setDouble(6, units);
                    updateStmt.setString(7, originalSubjectCode);
                    
                    int rowsAffected = updateStmt.executeUpdate();
                    
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Subject updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadSubjects(); // Refresh the list
                        clearFields();
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to update subject. Subject may not exist.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Database connection failed.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            System.err.println("Error updating subject: " + e.getMessage());
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void cancelButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
}