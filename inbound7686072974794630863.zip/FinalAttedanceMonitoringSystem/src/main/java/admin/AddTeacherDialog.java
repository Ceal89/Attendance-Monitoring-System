package admin;

import common.DatabaseConnection;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.*;

/**
 * AddTeacherDialog - Dialog for adding new teachers to the system
 * Demonstrates Object-Oriented Programming principles
 */
public class AddTeacherDialog extends JDialog {
    
    // UI Components - Encapsulation
    private JTextField teacherNumberField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField middleNameField;
    private JTextField departmentField;
    private JTextField specializationField;
    private JComboBox<String> employmentStatusCombo;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton addButton;
    private JButton cancelButton;
    

    
    /**
     * Constructor - Demonstrates Encapsulation and Polymorphism
     * @param parent Parent AdminDashboard window
     */
    public AddTeacherDialog(AdminDashboard parent) {
        super(parent, "Add New Teacher", true);
    
        
        System.out.println("🔄 Initializing AddTeacherDialog...");
        initComponents();
        System.out.println("✅ Components initialized");
        setupEventHandlers();
        System.out.println("✅ Event handlers setup completed");
        
        setSize(500, 700);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        System.out.println("✅ AddTeacherDialog initialization completed");
    }
    
    /**
     * Initialize UI components - Demonstrates Encapsulation
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(33, 33, 0));
        headerPanel.setPreferredSize(new Dimension(500, 60));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel titleLabel = new JLabel("Add New Teacher");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(Color.WHITE);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Teacher Number
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Teacher Number *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        teacherNumberField = new JTextField(20);
        formPanel.add(teacherNumberField, gbc);
        
        // First Name
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("First Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Last Name *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField, gbc);
        
        // Middle Name
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Middle Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        middleNameField = new JTextField(20);
        formPanel.add(middleNameField, gbc);
        
        // Department
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Department *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        departmentField = new JTextField(20);
        formPanel.add(departmentField, gbc);
        
        // Specialization
        gbc.gridx = 0; gbc.gridy = 5; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Specialization:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        specializationField = new JTextField(20);
        formPanel.add(specializationField, gbc);
        
        // Employment Status
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Employment Status *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        employmentStatusCombo = new JComboBox<>(new String[]{"Active", "Inactive", "On Leave"});
        employmentStatusCombo.setSelectedIndex(0);
        formPanel.add(employmentStatusCombo, gbc);
        
        // Username
        gbc.gridx = 0; gbc.gridy = 7; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Username *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        usernameField = new JTextField(20);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 8; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Password *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        passwordField = new JPasswordField(20);
        formPanel.add(passwordField, gbc);
        
        // Confirm Password
        gbc.gridx = 0; gbc.gridy = 9; gbc.fill = GridBagConstraints.NONE; gbc.weightx = 0;
        formPanel.add(new JLabel("Confirm Password *:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL; gbc.weightx = 1.0;
        confirmPasswordField = new JPasswordField(20);
        formPanel.add(confirmPasswordField, gbc);
        
        System.out.println("✅ Password fields initialized:");
        System.out.println("  - passwordField: " + passwordField);
        System.out.println("  - confirmPasswordField: " + confirmPasswordField);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        addButton = new JButton("Add Teacher");
        addButton.setBackground(new Color(33, 33, 0));
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        addButton.setPreferredSize(new Dimension(120, 35));
        
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(80, 80, 80));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);
        cancelButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        cancelButton.setPreferredSize(new Dimension(120, 35));
        
        buttonPanel.add(addButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        add(headerPanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        System.out.println("✅ Login credentials fields added to form");
    }
    
    /**
     * Setup event handlers - Demonstrates Event-Driven Programming
     */
    private void setupEventHandlers() {
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addTeacherButtonActionPerformed(e);
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelButtonActionPerformed(e);
            }
        });
    }
    
    
    /**
     * Handle Add Teacher button click - Demonstrates Data Validation and Database Operations
     */
    private void addTeacherButtonActionPerformed(ActionEvent evt) {
        // Validate input fields
        if (!validateInput()) {
            return;
        }
        
        Connection conn = null;
        try {
            System.out.println("🔄 Attempting to connect to database...");
            conn = DatabaseConnection.getConnection();
            if (conn == null) {
                JOptionPane.showMessageDialog(this, 
                    "Cannot connect to database. Please check your database connection.", 
                    "Database Connection Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            System.out.println("✅ Database connection successful");
            conn.setAutoCommit(false); // Start transaction
            
            try {
                // Get password from validation
                String password = new String(passwordField.getPassword());
                
                // Insert user account
                System.out.println("🔄 Inserting teacher user record...");
                String userQuery = "INSERT INTO users (username, password, full_name, user_type, is_active) VALUES (?, ?, ?, 'teacher', 1)";
                PreparedStatement userStmt = conn.prepareStatement(userQuery, PreparedStatement.RETURN_GENERATED_KEYS);
                
                String fullName = firstNameField.getText().trim() + " " + lastNameField.getText().trim();
                userStmt.setString(1, usernameField.getText().trim());
                userStmt.setString(2, password); // In production, hash the password
                userStmt.setString(3, fullName);
                
                int userResult = userStmt.executeUpdate();
                System.out.println("✅ Teacher user insertion result: " + userResult);
                if (userResult == 0) {
                    throw new SQLException("Failed to create user account");
                }
                
                // Get generated user ID
                int userId = 0;
                var generatedKeys = userStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    userId = generatedKeys.getInt(1);
                }
                userStmt.close();
                
                // Insert teacher record
                System.out.println("🔄 Inserting teacher record with user_id: " + userId);
                String teacherQuery = "INSERT INTO teachers (user_id, teacher_number, first_name, last_name, middle_name, department, specialization, employment_status, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)";
                PreparedStatement teacherStmt = conn.prepareStatement(teacherQuery);
                
                teacherStmt.setInt(1, userId);
                teacherStmt.setString(2, teacherNumberField.getText().trim());
                teacherStmt.setString(3, firstNameField.getText().trim());
                teacherStmt.setString(4, lastNameField.getText().trim());
                teacherStmt.setString(5, middleNameField.getText().trim());
                teacherStmt.setString(6, departmentField.getText().trim());
                teacherStmt.setString(7, specializationField.getText().trim());
                teacherStmt.setString(8, (String) employmentStatusCombo.getSelectedItem());
                
                int teacherResult = teacherStmt.executeUpdate();
                System.out.println("✅ Teacher record insertion result: " + teacherResult);
                teacherStmt.close();
                
                if (teacherResult == 0) {
                    throw new SQLException("Failed to create teacher record");
                }
                
                // Commit transaction
                conn.commit();
                
                JOptionPane.showMessageDialog(this, 
                    "Teacher added successfully!", 
                    "Success", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Clear form
                clearForm();
                
            } catch (SQLException e) {
                // Rollback transaction on error
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
                conn.close();
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Error adding teacher: " + e.getMessage());
            JOptionPane.showMessageDialog(this, 
                "Error adding teacher: " + e.getMessage(), 
                "Database Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Validate input fields - Demonstrates Input Validation
     */
    private boolean validateInput() {
        if (teacherNumberField.getText().trim().isEmpty()) {
            showValidationError("Teacher Number is required");
            teacherNumberField.requestFocus();
            return false;
        }
        
        if (firstNameField.getText().trim().isEmpty()) {
            showValidationError("First Name is required");
            firstNameField.requestFocus();
            return false;
        }
        
        if (lastNameField.getText().trim().isEmpty()) {
            showValidationError("Last Name is required");
            lastNameField.requestFocus();
            return false;
        }
        
        if (departmentField.getText().trim().isEmpty()) {
            showValidationError("Department is required");
            departmentField.requestFocus();
            return false;
        }
        
        if (usernameField.getText().trim().isEmpty()) {
            showValidationError("Username is required");
            usernameField.requestFocus();
            return false;
        }
        
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        
        System.out.println("🔍 Password validation:");
        System.out.println("  - Password length: " + password.length());
        System.out.println("  - Confirm password length: " + confirmPassword.length());
        System.out.println("  - Passwords match: " + password.equals(confirmPassword));
        
        if (password.isEmpty()) {
            showValidationError("Password is required");
            passwordField.requestFocus();
            return false;
        }
        
        if (password.length() < 6) {
            showValidationError("Password must be at least 6 characters long");
            passwordField.requestFocus();
            return false;
        }
        
        if (!password.equals(confirmPassword)) {
            showValidationError("Passwords do not match!");
            confirmPasswordField.requestFocus();
            return false;
        }
        
        return true;
    }
    
    /**
     * Show validation error message - Demonstrates Error Handling
     */
    private void showValidationError(String message) {
        JOptionPane.showMessageDialog(this, 
            message, 
            "Validation Error", 
            JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Clear all form fields - Demonstrates Utility Methods
     */
    private void clearForm() {
        teacherNumberField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        middleNameField.setText("");
        departmentField.setText("");
        specializationField.setText("");
        employmentStatusCombo.setSelectedIndex(0);
        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
    }
    
    /**
     * Handle Cancel button click - Demonstrates Event Handling
     */
    private void cancelButtonActionPerformed(ActionEvent evt) {
        dispose();
    }
}
